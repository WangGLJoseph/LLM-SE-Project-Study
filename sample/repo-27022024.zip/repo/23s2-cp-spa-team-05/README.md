[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/XTHBxU7a)
# Team 05

[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-%23FE5196?logo=conventionalcommits&logoColor=white)](https://conventionalcommits.org)

# Project Title

<!-- // ai-gen start (copilot, 1, e) -->
<!-- // prompt: used copilot -->
This is a 🤖 Static Program Analyser (SPA) for the SIMPLE language.
It analyses SIMPLE source code and provides information about the program's structure and properties.
Users provide a source program and a query, and the SPA will return the information requested by the query.

The SPA is composed the following components:
- Source Processor (SP)
- Program Knowledge Base (PKB)
- Query Processing Subsystem (QPS)

<!-- // ai-gen end -->

## Target Environment

| Item         | Version                               |
| ------------ | ------------------------------------- |
| OS           | Windows Visual Studio (CMake Project) |
| Toolchain    | CMake 3.20.2, Make 3.81               |
| C++ Standard | C++17                                 |

### Additional Build Instructions

No additional instructions required.

# Team Members

|           Name | Email                  | Development OS/Toolchain      | Main Component   |
| -------------: | :--------------------- | ----------------------------- |------------------|
|   Sim Jun Heng | e0544384@u.nus.edu     | VS 2019 on Windows with CMake | SP (Leader)      |
| Chua Bing Quan | chuabingquan@u.nus.edu | CLion on MacOS with CMake     | SP               |
|       Ian Hong | ianhong@u.nus.edu      | CLion on MacOS with CMake     | PKB (Docs IC)    |
|  Chai Yew Meng | yewmengchai@u.nus.edu  | VS 2022 on Windows with CMake | PKB              |
|  Toh Zhan Qing | e0544266@u.nus.edu     | VS 2019 on Windows with CMake | QPS              |
|       Alex Teo | alex.teo@u.nus.edu     | VS 2022 on Windows with CMake | QPS (Testing IC) |


