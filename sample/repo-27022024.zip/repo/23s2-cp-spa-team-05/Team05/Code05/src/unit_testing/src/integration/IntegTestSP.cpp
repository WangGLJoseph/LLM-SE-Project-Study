// include "sp/yourClass.h"
// include "sp/yourClass.cpp"

#include "catch.hpp"
using namespace std;

// Integration Tests for SP
TEST_CASE("[IntegTestSP] Replace with your Integration tests") {
    // Initialize Stub for PKB

    SECTION("Use Stub to test a feature") {
        REQUIRE(1 == 1);
    }
}
