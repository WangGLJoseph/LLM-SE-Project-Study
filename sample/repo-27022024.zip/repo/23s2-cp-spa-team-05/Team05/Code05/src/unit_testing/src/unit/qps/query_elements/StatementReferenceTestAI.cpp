//
// Created by tohzh on 10/2/2024.
//


#include "catch.hpp"
using namespace std;

#include "qps/query_elements/constraint_argument/statement_reference/StatementEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/ReadEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/PrintEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/AssignEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/CallEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/IfEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/WhileEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/IntegerArgument.h"
#include "qps/query_elements/constraint_argument/statement_reference/StatementRefWildcard.h"

//named in the form of [feature]_[scenario]_[result]

// ai-gen start(gpt, 1, e)
// prompt: https://platform.openai.com/playground/p/9SCJ5Iuz6Qhdknrd17M6Eh8k?model=gpt-3.5-turbo&mode=chat
TEST_CASE("entity_statementEntityIsTypeStatement_stringStatement") {
    StatementEntity en = StatementEntity("q");
    REQUIRE(en.getEntityType() == TYPE_STATEMENT);
}

TEST_CASE("entity_readEntityIsTypeStatement_stringRead") {
    ReadEntity en = ReadEntity("o");
    REQUIRE(en.getEntityType() == TYPE_READ);
}

TEST_CASE("entity_printEntityIsTypePrint_stringPrint") {
    PrintEntity en = PrintEntity("r");
    REQUIRE(en.getEntityType() == TYPE_PRINT);
}

TEST_CASE("entity_assignEntityIsTypeAssign_stringAssign") {
    AssignEntity en = AssignEntity("a");
    REQUIRE(en.getEntityType() == TYPE_ASSIGN);
}

TEST_CASE("entity_callEntityIsTypeCall_stringCall") {
    CallEntity en = CallEntity("b");
    REQUIRE(en.getEntityType() == TYPE_CALL);
}

TEST_CASE("entity_ifEntityIsTypeIf_stringIf") {
    IfEntity en = IfEntity("c");
    REQUIRE(en.getEntityType() == TYPE_IF);
}

TEST_CASE("entity_whileEntityIsTypeWhile_stringWhile") {
    WhileEntity en = WhileEntity("d");
    REQUIRE(en.getEntityType() == TYPE_WHILE);
}

TEST_CASE("entity_integerArgumentIsTypeInteger_stringInteger") {
    IntegerArgument en = IntegerArgument();
    REQUIRE(en.getEntityType() == TYPE_INTEGER);
}

TEST_CASE("entity_wildCardIsTypeWildcard_stringWildcard") {
    StatementRefWildCard en = StatementRefWildCard();
    REQUIRE(en.getEntityType() == TYPE_WILDCARD);
}

TEST_CASE("Entity_GetIdentifier_Success") {
    // Arrange
    std::string identifier = "test_identifier";
    AssignEntity entity(identifier);

    // Act
    std::string retrievedIdentifier = entity.getIdentifier();

    // Assert
    REQUIRE(retrievedIdentifier == identifier);
}

TEST_CASE("inheritance_check_statementReference_ReadEntity") {
    ReadEntity readEntity("v");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&readEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_PrintEntity") {
    PrintEntity printEntity("p");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&printEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_AssignEntity") {
    AssignEntity assignEntity("f");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&assignEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_CallEntity") {
    CallEntity callEntity("c");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&callEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_IfEntity") {
    IfEntity ifEntity("d");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&ifEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_WhileEntity") {
    WhileEntity whileEntity("e");
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&whileEntity) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_IntegerArgument") {
    IntegerArgument integerArgument;
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&integerArgument) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("inheritance_check_statementReference_WildCard") {
    StatementRefWildCard wildCard;
    bool isInstanceOfStatementReference = dynamic_cast<StatementReference*>(&wildCard) != nullptr;
    REQUIRE(isInstanceOfStatementReference);
}

TEST_CASE("StatementEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, StatementEntity>::value);
}

TEST_CASE("ReadEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, ReadEntity>::value);
}

TEST_CASE("PrintEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, PrintEntity>::value);
}

TEST_CASE("AssignEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, AssignEntity>::value);
}

TEST_CASE("CallEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, CallEntity>::value);
}

TEST_CASE("IfEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, IfEntity>::value);
}

TEST_CASE("WhileEntity_inheritanceCheck_isTrue") {
    REQUIRE(std::is_base_of<Entity, WhileEntity>::value);
}

TEST_CASE("IntegerArgument_inheritanceCheck_isFalse") {
    REQUIRE_FALSE(std::is_base_of<Entity, IntegerArgument>::value);
}

TEST_CASE("WildCard_inheritanceCheck_isFalse") {
    REQUIRE_FALSE(std::is_base_of<Entity, StatementRefWildCard>::value);
}

// ai-gen end