#define CATCH_CONFIG_MAIN  // ThiATCH_CONFIG_MAIN
#include "catch.hpp"
