//
// Created by tohzh on 8/2/2024.
//

#include "CallEntity.h"

std::string CallEntity::getReturnType() {
    return RETURN_INT_RESULT;
}

std::string CallEntity::getEntityType() {
    return TYPE_CALL;
}

CallEntity::CallEntity(std::string s) {
    identifier = std::move(s);
}

std::string CallEntity::toString() {
    return this->identifier + " [CALL]";
}

std::string CallEntity::getArgumentValue() {
    return this->identifier;
}

std::vector<std::vector<std::string>> CallEntity::getEntityTable(QueryPKBVirtual &pkb) {
    return pkb.getCallStmt();
}
