//
// Created by tohzh on 15/2/2024.
//

#include "EntityReference.h"

std::string EntityReference::getReferenceType() {
    return REFERENCE_TYPE_ENTITY;
}
