//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_ASSIGNTABLE_H
#define SPA_ASSIGNTABLE_H

#include "pkb/tables/base/Table.h"

class AssignTable : public Table {
public:
    AssignTable() = default;
};



#endif //SPA_ASSIGNTABLE_H
