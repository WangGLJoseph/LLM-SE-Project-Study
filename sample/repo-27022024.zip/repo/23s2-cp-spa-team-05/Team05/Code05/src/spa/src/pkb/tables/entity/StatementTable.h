//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_STATEMENTTABLE_H
#define SPA_STATEMENTTABLE_H

#include "pkb/tables/base/Table.h"

class StatementTable  : public Table {

public:
    StatementTable() = default;

};


#endif //SPA_STATEMENTTABLE_H
