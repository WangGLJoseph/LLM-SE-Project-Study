//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_IFTABLE_H
#define SPA_IFTABLE_H

#include "pkb/tables/base/Table.h"

class IfTable : public Table {
public:
    IfTable() = default;
};


#endif //SPA_IFTABLE_H
