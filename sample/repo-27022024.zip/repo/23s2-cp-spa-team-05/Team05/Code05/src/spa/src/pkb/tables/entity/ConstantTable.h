//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_CONSTANTTABLE_H
#define SPA_CONSTANTTABLE_H

#include "pkb/tables/base/Table.h"

class ConstantTable : public Table {

public:
    ConstantTable() = default;

};


#endif //SPA_CONSTANTTABLE_H
