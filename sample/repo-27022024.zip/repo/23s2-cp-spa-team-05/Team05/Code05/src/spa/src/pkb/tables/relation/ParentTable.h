//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_PARENTTABLE_H
#define SPA_PARENTTABLE_H

#include "pkb/tables/base/Table.h"

class ParentTable : public Table {

public:
    ParentTable() = default;
};



#endif //SPA_PARENTTABLE_H
