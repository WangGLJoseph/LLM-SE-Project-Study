//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_MODIFIESTABLE_H
#define SPA_MODIFIESTABLE_H

#include "pkb/tables/base/Table.h"

class ModifiesTable : public Table {
public:
    ModifiesTable() = default;
};

#endif //SPA_MODIFIESTABLE_H
