//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_VARIABLETABLE_H
#define SPA_VARIABLETABLE_H

#include "pkb/tables/base/Table.h"

class VariableTable : public Table{
    
public:
    VariableTable() = default;

};

#endif //SPA_VARIABLETABLE_H
