//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_PRINTTABLE_H
#define SPA_PRINTTABLE_H

#include "pkb/tables/base/Table.h"

class PrintTable : public Table {
public:
    PrintTable() = default;

};

#endif //SPA_PRINTTABLE_H
