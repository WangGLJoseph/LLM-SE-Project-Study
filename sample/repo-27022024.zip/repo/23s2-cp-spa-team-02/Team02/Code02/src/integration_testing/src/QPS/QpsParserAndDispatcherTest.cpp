#include "catch.hpp"
#include "QPS/QPS.h"

TEST_CASE("Parse and Dispatch Correctly") {

  PKB pkb;
  PKBManager manager(pkb);
  QPS qps(manager);

  SECTION("No clause") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);

    std::string query = "stmt s1; Select s1 ";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2", "1"});
  }

  SECTION("Follows") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addFollows("1", "2");

    std::string query = "stmt s1, s2; Select s2 such that Follows(s1,s2)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2"});

    query = "stmt s1, s2; Select s1 such that Follows(_,s2)";

    result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2", "1"});
  }

  SECTION("Follows*") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addFollows("1", "2");
    manager.addStatementWithType("3", StatementType::WHILE);
    manager.addFollows("2", "3");
    manager.addFollowsStar("1", "2");
    manager.addFollowsStar("2", "3");
    manager.addFollowsStar("1", "3");

    std::string query = "stmt stmt; Select stmt such that Follows* (1,stmt)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2", "3"});
  }

  SECTION("Parent") {

    manager.addStatementWithType("1", StatementType::WHILE);
    manager.addStatementWithType("2", StatementType::IF);
    manager.addStatementWithType("3", StatementType::ASSIGN);
    manager.addParent("1", "2");
    manager.addParent("2", "3");

    std::string query = "if i; Select i such that Parent(_,i)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2"});

  }

  SECTION("Parent*") {

    manager.addStatementWithType("1", StatementType::WHILE);
    manager.addStatementWithType("2", StatementType::IF);
    manager.addStatementWithType("3", StatementType::ASSIGN);
    manager.addParent("1", "2");
    manager.addParent("2", "3");
    manager.addParentStar("1", "2");
    manager.addParentStar("2", "3");
    manager.addParentStar("1", "3");

    std::string query = "stmt Select; Select Select such that Parent*(_,Select)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2", "3"});

  }

  SECTION("Modifies") {
    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addModifiesStatement("1", "x");
    manager.addModifiesStatement("2", "y");

    std::string query = "variable variable; Select variable such that Modifies(1, variable)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"x"});

    result = qps.processQuery("assign a; Select a such that Modifies(a,_)");

    REQUIRE(result == std::unordered_set<std::string>{"1", "2"});
  }

  SECTION("Uses") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addUsesStatement("1", "one");
    manager.addUsesStatement("1", "two");
    manager.addUsesStatement("2", "one");

    auto result = qps.processQuery("stmt while; Select while such that Uses(while, \"one\")");

    REQUIRE(result == std::unordered_set<std::string>{"1", "2"});

  }

  SECTION("Assign Pattern") {
    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addUsesStatement("1", "one");
    manager.addUsesStatement("1", "two");
    manager.addUsesStatement("2", "one");
    manager.addModifiesStatement("1", "x");
    manager.addModifiesStatement("2", "y");
    manager.addVariableForAssign("one", "1");
    manager.addVariableForAssign("two", "1");
    manager.addVariableForAssign("one", "2");
    manager.addConstantForAssign("12529", "2");

    std::string query = "assign a; Select a pattern a(\"y\", _\"12529\"_)";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2"});

    query = "assign a; Select a pattern a(_, _\"one\"_)";

    result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"2", "1"});
  }

  SECTION("Such that and Pattern") {
    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addUsesStatement("1", "one");
    manager.addUsesStatement("1", "two");
    manager.addUsesStatement("2", "one");
    manager.addModifiesStatement("1", "x");
    manager.addModifiesStatement("2", "y");
    manager.addVariableForAssign("one", "1");
    manager.addVariableForAssign("two", "1");
    manager.addVariableForAssign("one", "2");
    manager.addConstantForAssign("12529", "2");

    std::string query = "assign a; variable v; Select v pattern a(v, _\"12529\"_) such that Modifies(a, \"y\")";

    auto result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"y"});

    query = "assign a; variable v; Select v such that Uses(1, \"two\") pattern a(v, _\"one\"_)";

    result = qps.processQuery(query);

    REQUIRE(result == std::unordered_set<std::string>{"y", "x"});
  }

  SECTION("Syntax Error") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addModifiesStatement("1", "x");
    manager.addModifiesStatement("2", "y");

    // s not capitalised
    std::string query = "variable variable; select variable such that Modifies(1, variable)";

    std::unordered_set<std::string> result;

    REQUIRE_NOTHROW(result = qps.processQuery(query));

    REQUIRE(result == std::unordered_set<std::string>{"SyntaxError"});

  }

  SECTION("Semantic Error") {

    manager.addStatementWithType("1", StatementType::ASSIGN);
    manager.addStatementWithType("2", StatementType::ASSIGN);
    manager.addModifiesStatement("1", "x");
    manager.addModifiesStatement("2", "y");

    // Undeclared hello
    std::string query = "variable variable; Select hello such that Modifies(1, variable)";

    std::unordered_set<std::string> result;

    REQUIRE_NOTHROW(result = qps.processQuery(query));

    REQUIRE(result == std::unordered_set<std::string>{"SemanticError"});

  }

}