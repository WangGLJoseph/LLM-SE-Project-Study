//
// Created by Evan Chng on 11/2/24.
//
#pragma once

#include "TokenSP.h"
#include <iostream>
#include <unordered_map>
#include <vector>

class Tokens {
private:
  std::vector<TokenSP> _tokens;
  int _index;
  size_t _length;

public:
  explicit Tokens(std::vector<TokenSP> tokens);

  ~Tokens();

  [[nodiscard]] int getIndex() const;

  [[nodiscard]] int getLength() const;

  [[nodiscard]] bool isEmpty() const;

  std::vector<TokenSP> getTokens();

  TokenSP at(int idx);

  TokenTypeSP peekHead();

  void increaseIndex(int numberOfTokens);

  int getRightParenthesisIndex(int curr);

  int getRightCurlyBracketIndex(int curr);

  int getSemicolonIndex();

  TokenSP getNextToken();

  std::string getPostFixExpression(int startIdx, int endIdx);

  void ensureNextTokenType(TokenTypeSP t);

  void ensureTokenTypeAt(int index, TokenTypeSP t);

  bool isRelationalAt(int index);

  bool isVariableAt(int index);

  bool checkTypeAt(int index, TokenTypeSP t);
};
