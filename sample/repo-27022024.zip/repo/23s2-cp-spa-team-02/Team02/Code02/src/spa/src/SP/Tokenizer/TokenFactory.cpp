//
// Created by Evan Chng on 6/2/24.
//

#include "TokenFactory.h"
#include "TokenSP.h"

TokenSP TokenFactory::createToken(TokenTypeSP tokenType,
                                  const std::string &value) {
  return {tokenType, value};
}
