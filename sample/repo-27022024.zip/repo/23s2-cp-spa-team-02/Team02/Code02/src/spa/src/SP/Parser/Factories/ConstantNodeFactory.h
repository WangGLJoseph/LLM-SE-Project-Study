//
// Created by yeemi on 2/12/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ConstantNode.h"
#include "SP/Tokenizer/Tokens.h"

class ConstantNodeFactory {
private:
  typedef std::shared_ptr<ConstantNode> Constant;

public:
  ConstantNodeFactory();
  ~ConstantNodeFactory();

  Constant createConstantNode(Tokens &tokens);
};
