#pragma once
#include "Util/StatementType.h"
#include <QPS/Tokenizer/Token.h>

#include <regex>
#include <string>
#include <unordered_map>
#include <unordered_set>
/**
 * Constants for PQL Grammar
 */
namespace pql_constants {
// Used for regex matching before mapping to enum type for type checking
// Symbols
const std::string decDelimiter = ";";
const std::string commaa = ",";
const std::string openParen = "(";
const std::string closeParen = ")";
const std::string doubleQuotation = "\"";
const std::string wildcard = "_";

// Clauses
const std::string selectCl = "Select";
const std::string suchThatCl = "such that";
const std::string patternCl = "pattern";

// Relationships
const std::string followsRel = "Follows";
const std::string followsTRel = "Follows*";
const std::string parentRel = "Parent";
const std::string parentTRel = "Parent*";
// These two have same relRef, just different argument types
const std::string usesRel = "Uses";
const std::string modifiesRel = "Modifies";

const std::string statementDec = "stmt";
const std::string readDec = "read";
const std::string printDec = "print";
const std::string callDec = "call";
const std::string whileDec = "while";
const std::string ifDec = "if";
const std::string assignDec = "assign";
const std::string variableDec = "variable";
const std::string constantDec = "constant";
const std::string procedureDec = "procedure";

const std::unordered_set<std::string> decEntitySet{
    statementDec, readDec,   printDec,    callDec,     whileDec,
    ifDec,        assignDec, variableDec, constantDec, procedureDec};

const std::unordered_set<std::string> relRefSet{
    followsRel, followsTRel, parentRel, parentTRel, usesRel, modifiesRel,
};
const std::unordered_set<std::string> relRefStarSet{followsTRel, parentTRel};

} // namespace pql_constants

// All entity types
enum class EntityType {
  // Possible synonym declarations, can be from quoted expression too
  PROCEDURE, // "name"
  VARIABLE,  // "name"
  CONSTANT,  // todo: when is this used?
  STATEMENT, // declared synonym
  READ,
  PRINT,
  ASSIGNMENT,
  CALL,
  WHILE,
  IF,
  // Non declarations
  NAME,     // any name, var, procedure etc.
  STMT_NUM, // integer
  WILDCARD,
  EXACT_MATCH,
  PARTIAL_MATCH,
  UNDECLARED
};

enum class RelRef {
  // RelRef
  FOLLOWS,
  FOLLOWS_T,
  PARENT,
  PARENT_T,
  // Only difference is argument type
  USES,
  MODIFIES
};

// All possible declaration entities, for synonymMap
const std::unordered_map<std::string, EntityType> tokenValToDecEntity{
    {pql_constants::procedureDec, EntityType::PROCEDURE},
    {pql_constants::variableDec, EntityType::VARIABLE},
    {pql_constants::constantDec, EntityType::CONSTANT},
    {pql_constants::statementDec, EntityType::STATEMENT},
    {pql_constants::readDec, EntityType::READ},
    {pql_constants::printDec, EntityType::PRINT},
    {pql_constants::assignDec, EntityType::ASSIGNMENT},
    {pql_constants::callDec, EntityType::CALL},
    {pql_constants::whileDec, EntityType::WHILE},
    {pql_constants::ifDec, EntityType::IF},
};

// star RelRefs
const std::unordered_map<std::string, RelRef> tokenValToRelRef{
    {pql_constants::followsRel, RelRef::FOLLOWS},
    {pql_constants::followsTRel, RelRef::FOLLOWS_T},
    {pql_constants::parentRel, RelRef::PARENT},
    {pql_constants::parentTRel, RelRef::PARENT_T},
    {pql_constants::usesRel, RelRef::USES},
    {pql_constants::modifiesRel, RelRef::MODIFIES},
};

StatementType entityToStatementType(EntityType entityType);

const std::unordered_set<TokenType> stmtRefTokenTypes{
    TokenType::IDENT, TokenType::UNDERSCORE, TokenType::INTEGER};

const std::unordered_set<TokenType> entRefTokenTypes{
    TokenType::IDENT, TokenType::UNDERSCORE, TokenType::QUOTED_EXPR};

const std::unordered_set<TokenType> bothRefTokenTypes{
    TokenType::IDENT, TokenType::UNDERSCORE, TokenType::INTEGER,
    TokenType::QUOTED_EXPR};

const std::unordered_map<RelRef, std::pair<std::unordered_set<TokenType>,
                                           std::unordered_set<TokenType>>>
    validStArgTokenTypes{
        {RelRef::FOLLOWS, {stmtRefTokenTypes, stmtRefTokenTypes}},
        {RelRef::FOLLOWS_T, {stmtRefTokenTypes, stmtRefTokenTypes}},
        {RelRef::PARENT, {stmtRefTokenTypes, stmtRefTokenTypes}},
        {RelRef::PARENT_T, {stmtRefTokenTypes, stmtRefTokenTypes}},
        {RelRef::USES, {bothRefTokenTypes, entRefTokenTypes}},
        {RelRef::MODIFIES, {bothRefTokenTypes, entRefTokenTypes}},
    };

// All statement types, STMT_NUM, WILDCARD
const std::unordered_set<EntityType> stmtRefEntTypes{
    EntityType::STATEMENT,  EntityType::READ,     EntityType::PRINT,
    EntityType::ASSIGNMENT, EntityType::CALL,     EntityType::WHILE,
    EntityType::IF,         EntityType::STMT_NUM, EntityType::WILDCARD};

// ALl statement types, STMT_NUM, procedure name, no WILDCARD
const std::unordered_set<EntityType> usesModifiesFirstArgEntTypes{
    EntityType::STATEMENT,  EntityType::READ,     EntityType::PRINT,
    EntityType::ASSIGNMENT, EntityType::CALL,     EntityType::WHILE,
    EntityType::IF,         EntityType::STMT_NUM, EntityType::NAME};

const std::unordered_set<EntityType> usesModifiesSecondArgEntTypes{
    EntityType::VARIABLE, EntityType::NAME, EntityType::WILDCARD};

const std::unordered_map<RelRef, std::pair<std::unordered_set<EntityType>,
                                           std::unordered_set<EntityType>>>
    validStArgEntTypes{
        {RelRef::FOLLOWS, {stmtRefEntTypes, stmtRefEntTypes}},
        {RelRef::FOLLOWS_T, {stmtRefEntTypes, stmtRefEntTypes}},
        {RelRef::PARENT, {stmtRefEntTypes, stmtRefEntTypes}},
        {RelRef::PARENT_T, {stmtRefEntTypes, stmtRefEntTypes}},
        {RelRef::USES,
         {usesModifiesFirstArgEntTypes, usesModifiesSecondArgEntTypes}},
        {RelRef::MODIFIES,
         {usesModifiesFirstArgEntTypes, usesModifiesSecondArgEntTypes}},
    };

const std::unordered_set<EntityType> validPatternTypes{
    EntityType::ASSIGNMENT, EntityType::WHILE, EntityType::IF};

const std::unordered_set<EntityType> validPatternFirstArgTypes{
    EntityType::NAME, EntityType::VARIABLE, EntityType::WILDCARD};

const std::unordered_map<EntityType, std::string> entityTypeToString{
    {EntityType::STATEMENT, pql_constants::statementDec},
    {EntityType::READ, pql_constants::readDec},
    {EntityType::PRINT, pql_constants::printDec},
    {EntityType::CALL, pql_constants::callDec},
    {EntityType::WHILE, pql_constants::whileDec},
    {EntityType::IF, pql_constants::ifDec},
    {EntityType::ASSIGNMENT, pql_constants::assignDec},
    {EntityType::VARIABLE, pql_constants::variableDec},
    {EntityType::CONSTANT, pql_constants::constantDec},
    {EntityType::PROCEDURE, pql_constants::procedureDec},
    {EntityType::NAME, "NAME"},
    {EntityType::STMT_NUM, "STMT_NUM"},
    {EntityType::WILDCARD, pql_constants::wildcard},
    {EntityType::EXACT_MATCH, "EXACT_MATCH"},
    {EntityType::PARTIAL_MATCH, "PARTIAL_MATCH"},
    {EntityType::UNDECLARED, "UNDECLARED"}};
