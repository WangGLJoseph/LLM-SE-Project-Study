#pragma once

#include <regex>
#include <string>

class StringUtils {
public:
  static bool isAlpha(const std::string &s) {
    if (s.empty()) {
      return false;
    }
    for (char c: s) {
      if (!std::isalpha(c)) {
        return false;
      }
    }
    return true;
  }

  static bool isAlphanumericNoLeadingNumber(const std::string &s) {
    if (s.empty()) {
      return false;
    }
    if (isdigit(s[0])) {
      return false;
    }
    return isAlphanumeric(s);
  }

  static bool isAlphanumeric(const std::string &s) {
    if (s.empty()) {
      return false;
    }
    for (char c: s) {
      if (!std::isalnum(c)) {
        return false;
      }
    }
    return true;
  }

  static bool isInteger(const std::string &s) {
    if (s.empty()) {
      return false;
    }
    for (char c: s) {
      if (!std::isdigit(c)) {
        return false;
      }
    }
    if (s == "0") {
      return true;
    }
    size_t firstNonZero = s.find_first_not_of('0');
    return firstNonZero == 0;
  }

  static std::string condenseWhitespaces(const std::string &s) {
    // Condenses all whitespaces to 1 whitespace
    return std::regex_replace(s, std::regex("\\s+"), " ");
  }

  static std::string removeWhitespaces(const std::string &s) {
    // Remove all whitespaces
    return std::regex_replace(s, std::regex("\\s+"), "");
  }
};
