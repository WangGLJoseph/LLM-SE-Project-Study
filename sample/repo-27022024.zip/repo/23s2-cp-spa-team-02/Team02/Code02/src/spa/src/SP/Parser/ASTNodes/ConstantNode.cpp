//
// Created by yeemi on 2/10/2024.
//

#include "ConstantNode.h"

#include <utility>

ConstantNode::ConstantNode(ConstantName name) : _name(std::move(name)) {}

ConstantNode::~ConstantNode() = default;

void ConstantNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitConstantNode(*this);
}
ConstantNode::ConstantName ConstantNode::getName() const { return _name; }
