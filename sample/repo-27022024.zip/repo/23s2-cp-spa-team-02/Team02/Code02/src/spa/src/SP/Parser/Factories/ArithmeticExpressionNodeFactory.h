//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "../ASTNodes/ArithmeticExpressionNode.h"
#include "ExpressionNodeFactory.h"

class ArithmeticExpressionNodeFactory : public ExpressionNodeFactory {
private:
  typedef std::string PostFixExpression;
  typedef std::shared_ptr<ExpressionNode> ArithmeticExpression;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;

public:
  ArithmeticExpressionNodeFactory();

  ~ArithmeticExpressionNodeFactory();

  ArithmeticExpression createExpressionNode(Tokens &tokens) override;
};
