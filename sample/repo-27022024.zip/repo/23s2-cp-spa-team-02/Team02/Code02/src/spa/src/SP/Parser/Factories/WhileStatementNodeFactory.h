//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/WhileStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class WhileStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> Statement;
  typedef std::shared_ptr<StatementNode> WhileStatement;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  typedef std::shared_ptr<ExpressionNode> ConditionalExpression;

public:
  WhileStatementNodeFactory();
  ~WhileStatementNodeFactory();

  WhileStatement createStatementNode(Tokens &tokens) override;
};
