#include "QPS.h"

QueryResult QPS::processQuery(const std::string& query) {

  ResultSet result;

  try {

    Query queryFromParser = parser.parseQuery(query);
    result = evaluator_.evaluateQuery(queryFromParser);

  } catch (SyntaxErrorException& syntaxError) {

    std::cerr << syntaxError.what() << std::endl;

    return syntaxErr_;

  } catch (SemanticErrorException& semanticError) {

    std::cerr << semanticError.what() << std::endl;

    return semanticErr_;

  }

  QueryResult ret;

  for (auto& str_vec: result) {

    std::string concat;

    for (auto& str: str_vec) {
      // TODO richard MS2: comply with requirements on how to concat each row for a tuple
      concat.append(str);
    }

    ret.insert(concat);
  }

  return ret;
}