#include "QueryEvaluator.h"

ResultSet QueryEvaluator::evaluateQuery(Query &query) {

  Result result(true);

  for (auto& clause: query.stClauses_) {

    Result dispatchResult = dispatcher_.dispatchClause(clause);

    result = result.combineWith(dispatchResult);
  }

  for (auto& clause: query.patternClauses_) {

    Result dispatchResult = dispatcher_.dispatchClause(clause);

    result = result.combineWith(dispatchResult);
  }

  if (!result.contains(query.selectedSynonym_)) {

    auto vals = dispatcher_.getAllValues(query.selectedSynonym_, query.synonymMap_[query.selectedSynonym_]);

    result = result.combineWith(vals);

  }

  return result.retrieveValues({query.selectedSynonym_});
}