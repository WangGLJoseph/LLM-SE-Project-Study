#pragma once

#include "PKB/API/PKBManager.h"
#include "QPS/Result.h"

template <typename ClauseType, typename... Ts>
class GenericDispatcher {

public:
  GenericDispatcher(PKBManager& pkb) : pkb_(pkb) {};

  template <typename T>
  bool execute_if(const ClauseType& clause, Result& target) {
    if  (T::rel == clause.getRelationship()) {
      target = T()(clause, pkb_);
      return true;
    }

    return false;
  }

  Result execute(const ClauseType& clause) {
    Result res(false);

    // If executes, will replace res with corresponding result
    (execute_if<Ts>(clause, res) || ...);

    return res;
  }

private:
  PKBManager& pkb_;
};