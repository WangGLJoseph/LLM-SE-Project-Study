//
// Created by yeemi on 2/8/2024.
//

#include "UsesExtractor.h"
#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/ASTNodes/ConditionalExpressionNode.h"
#include "SP/Parser/ASTNodes/ConstantNode.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/PrintStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

UsesExtractor::UsesExtractor(PKBManager &pkbManager)
    : BaseExtractor(pkbManager) {}

UsesExtractor::~UsesExtractor() = default;

void UsesExtractor::visitProcedureNode(const ProcedureNode &procedureNode) {
  // TODO: Milestone 2 Uses with Procedure
  visitStatementNodeList(procedureNode.getStatementNodes());
}

void UsesExtractor::visitStatementNodeList(
    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    getGrandParents().push_back(statementNode->getStatementNumber());
    statementNode->accept(shared_from_this());
    getGrandParents().pop_back();
  }
}

void UsesExtractor::visitConstantNode(const ConstantNode &constantNode) {}

void UsesExtractor::visitVariableNode(const VariableNode &variableNode) {}

void UsesExtractor::visitAssignStatementNode(
    const AssignStatementNode &assignStatementNode) {
  visitArithmeticExpressionNode(
      *assignStatementNode.getArithmeticExpressionNode());
}

void UsesExtractor::visitCallStatementNode(
    const CallStatementNode &callStatementNode) {}

void UsesExtractor::visitIfStatementNode(
    const IfStatementNode &ifStatementNode) {
  visitConditionalExpressionNode(
      *ifStatementNode.getConditionalExpressionNode());
  visitStatementNodeList(ifStatementNode.getThenStatementNodes());
  visitStatementNodeList(ifStatementNode.getElseStatementNodes());
}

void UsesExtractor::visitPrintStatementNode(
    const PrintStatementNode &printStatementNode) {
  int statementNumber = printStatementNode.getStatementNumber();
  std::string variableName = printStatementNode.getVariableName();
  getPKBManager().addUsesStatement(std::to_string(statementNumber),
                                   variableName);
  extractGrandParentUses(variableName);
}

void UsesExtractor::visitReadStatementNode(
    const ReadStatementNode &readStatementNode) {}

void UsesExtractor::visitWhileStatementNode(
    const WhileStatementNode &whileStatementNode) {
  visitConditionalExpressionNode(
      *whileStatementNode.getConditionalExpressionNode());
  visitStatementNodeList(whileStatementNode.getStatementNodes());
}

void UsesExtractor::visitArithmeticExpressionNode(
    const ExpressionNode &arithmeticExpressionNode) {
  extractUses(arithmeticExpressionNode);
  extractAssignConstantsAndVariables(arithmeticExpressionNode);
}

void UsesExtractor::visitConditionalExpressionNode(
    const ExpressionNode &conditionalExpressionNode) {
  extractUses(conditionalExpressionNode);
}

void UsesExtractor::visitProgramNode(const ProgramNode &programNode) {}

void UsesExtractor::extractUses(const ExpressionNode &expressionNode) {
  int statementNumber = getGrandParents().back();
  VariableList variableNodes = expressionNode.getVariableNodes();
  for (const auto &variableNode : variableNodes) {
    getPKBManager().addUsesStatement(std::to_string(statementNumber),
                                     variableNode->getName());
    extractGrandParentUses(variableNode->getName());
  }
}

void UsesExtractor::extractAssignConstantsAndVariables(
    const ExpressionNode &expressionNode) {
  std::string statementNumber = std::to_string(getGrandParents().back());
  VariableList variableNodes = expressionNode.getVariableNodes();
  ConstantList constantNodes = expressionNode.getConstantNodes();
  for (const auto &variableNode : variableNodes) {
    getPKBManager().addVariableForAssign(variableNode->getName(),
                                         statementNumber);
  }
  for (const auto &constantNode : constantNodes) {
    getPKBManager().addConstantForAssign(constantNode->getName(),
                                         statementNumber);
  }
}

UsesExtractor::GrandParentStatementNumber &UsesExtractor::getGrandParents() {
  return _grandParents;
}

void UsesExtractor::extractGrandParentUses(const std::string &variableName) {
  for (const auto &grandParent : getGrandParents()) {
    getPKBManager().addUsesStatement(std::to_string(grandParent), variableName);
  }
}