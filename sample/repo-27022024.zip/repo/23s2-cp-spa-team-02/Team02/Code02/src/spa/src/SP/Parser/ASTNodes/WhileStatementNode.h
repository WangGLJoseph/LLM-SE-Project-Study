//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ConditionalExpressionNode.h"
#include "StatementNode.h"
#include <vector>

class WhileStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  typedef std::shared_ptr<ExpressionNode> ConditionalExpression;
  ConditionalExpression _conditionalExpressionNode;
  StatementList _statementNodes;

public:
  explicit WhileStatementNode(int statementNumber,
                              ConditionalExpression conditionalExpressionNode,
                              StatementList statementNodes);
  ~WhileStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] ConditionalExpression getConditionalExpressionNode() const;
  [[nodiscard]] StatementList getStatementNodes() const;
};