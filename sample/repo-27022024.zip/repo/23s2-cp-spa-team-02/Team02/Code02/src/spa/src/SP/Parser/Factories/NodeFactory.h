//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ArithmeticExpressionNodeFactory.h"
#include "AssignStatementNodeFactory.h"
#include "CallStatementNodeFactory.h"
#include "ConditionalExpressionNodeFactory.h"
#include "ConstantNodeFactory.h"
#include "IfStatementNodeFactory.h"
#include "PrintStatementNodeFactory.h"
#include "ProcedureNodeFactory.h"
#include "ReadStatementNodeFactory.h"
#include "SP/Parser/ASTNodes/ExpressionTypes.h"
#include "SP/Parser/ASTNodes/Node.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"
#include "SP/Tokenizer/TokenSP.h"
#include "SP/Tokenizer/Tokens.h"
#include "VariableNodeFactory.h"
#include "WhileStatementNodeFactory.h"

class NodeFactory {
private:
  typedef std::shared_ptr<ConstantNode> Constant;
  typedef std::shared_ptr<VariableNode> Variable;
  typedef std::shared_ptr<StatementNode> Statement;
  typedef std::shared_ptr<ExpressionNode> Expression;
  typedef std::shared_ptr<ProcedureNode> Procedure;
  typedef std::vector<std::shared_ptr<ProcedureNode>> ProcedureList;

  inline static int _statementNumber;

public:
  NodeFactory();

  ~NodeFactory();

  static int getStatementNumber();

  static void initializeFactory();

  static void increaseStatementNumber();

  static void resetStatementNumber();

  static ProgramNode createAST(Tokens &tokens);

  static ProcedureNodeFactory getProcedureNodeFactory();

  static AssignStatementNodeFactory getAssignStatementNodeFactory();

  static CallStatementNodeFactory getCallStatementNodeFactory();

  static IfStatementNodeFactory getIfStatementNodeFactory();

  static ReadStatementNodeFactory getReadStatementNodeFactory();

  static PrintStatementNodeFactory getPrintStatementNodeFactory();

  static WhileStatementNodeFactory getWhileStatementNodeFactory();

  static ArithmeticExpressionNodeFactory getArithmeticExpressionNodeFactory();

  static ConditionalExpressionNodeFactory getConditionalExpressionNodeFactory();

  static ConstantNodeFactory getConstantNodeFactory();

  static VariableNodeFactory getVariableNodeFactory();

  static Statement createStatementNode(Tokens &tokens);

  static Expression createExpressionNode(Tokens &tokens, ExpressionType type);

  static Constant createConstantNode(Tokens &tokens);

  static Variable createVariableNode(Tokens &tokens);
};
