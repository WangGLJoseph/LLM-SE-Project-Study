//
// Created by yeemi on 2/8/2024.
//

#include "BaseExtractor.h"

BaseExtractor::BaseExtractor(PKBManager &pkbManager)
    : _pkbManager(pkbManager) {}

PKBManager &BaseExtractor::getPKBManager() { return _pkbManager; }