#include "QueryTokenizer.h"
#include <iostream>

QueryTokens QueryTokenizer::tokenize(const std::string &query) {
  // Multiple whitespaces should have been converted to a single white space
  std::string trimmedQuery = StringUtils::condenseWhitespaces(query);
  // General tokenizing into alpha, alphanumeric, integer, symbols
  std::regex tokenPatterns(
      "(\\bsuch that\\b)|(\\b[a-zA-Z][a-zA-Z0-9]*\\b)|(\\b0|[1-9][0-9]*\\b)|("
      "\"[^\"]*\")|(;)|(,)|(\\()|(\\))|(_)|(\\*)|( )|([^\\s]+)");

  auto wordsBegin = std::sregex_iterator(trimmedQuery.begin(),
                                         trimmedQuery.end(), tokenPatterns);
  auto wordsEnd = std::sregex_iterator();
  QueryTokens tokens{};

  bool prevIsSpace = false;

  for (std::sregex_iterator i = wordsBegin; i != wordsEnd; ++i) {
    const std::smatch &match = *i;
    TokenType type = determineTokenType(match);
    if (type == TokenType::UNKNOWN) {
      throw SyntaxErrorException("Unknown token " + match.str() +
                                 " encountered");
    } else if (type == TokenType::SPACE) {
      prevIsSpace = true;
      continue;
    } else if (type == TokenType::QUOTED_EXPR) {
      std::string withoutQuotes = StringUtils::removeWhitespaces(match.str().substr(1, match.str().size() - 2));
      tokens.emplace_back(withoutQuotes, type);
    } else if (type == TokenType::STAR) {

      if (prevIsSpace) {
        throw SyntaxErrorException("Space before * encountered");
      }
      tokens.emplace_back(match.str(), type);

    } else {
      tokens.emplace_back(match.str(), type);
    }

    prevIsSpace = false;
  }
  return tokens;
}

TokenType QueryTokenizer::determineTokenType(const std::smatch &match) {
  if (match[1].matched)
    return TokenType::SUCH_THAT;
  else if (match[2].matched)
    return TokenType::IDENT;
  else if (match[3].matched)
    return TokenType::INTEGER;
  else if (match[4].matched)
    return TokenType::QUOTED_EXPR;
  else if (match[5].matched)
    return TokenType::SEMICOLON;
  else if (match[6].matched)
    return TokenType::COMMA;
  else if (match[7].matched)
    return TokenType::PAREN_OPEN;
  else if (match[8].matched)
    return TokenType::PAREN_CLOSE;
  else if (match[9].matched)
    return TokenType::UNDERSCORE;
  else if (match[10].matched)
    return TokenType::STAR;
  else if (match[11].matched)
    return TokenType::SPACE;
  else
    return TokenType::UNKNOWN;
}
