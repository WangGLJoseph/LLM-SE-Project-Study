//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/Factories/StatementNodeFactory.h"
#include <memory>

class AssignStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> AssignStatement;
  typedef std::shared_ptr<VariableNode> Variable;
  typedef std::shared_ptr<ExpressionNode> ArithmeticExpression;

public:
  AssignStatementNodeFactory();
  ~AssignStatementNodeFactory();

  AssignStatement createStatementNode(Tokens &tokens) override;
};