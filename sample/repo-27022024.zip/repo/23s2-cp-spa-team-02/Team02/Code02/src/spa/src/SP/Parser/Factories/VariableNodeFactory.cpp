//
// Created by yeemi on 2/12/2024.
//

#include "VariableNodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"

VariableNodeFactory::VariableNodeFactory() = default;

VariableNodeFactory::~VariableNodeFactory() = default;

VariableNodeFactory::Variable
VariableNodeFactory::createVariableNode(Tokens &tokens) {
  TokenSP variable = tokens.getNextToken();
  if (!variable.isVariable()) {
    throw SyntaxErrorException("expected variable instead of " + variable.getValue());
  }
  return std::make_shared<VariableNode>(variable.getValue());
}
