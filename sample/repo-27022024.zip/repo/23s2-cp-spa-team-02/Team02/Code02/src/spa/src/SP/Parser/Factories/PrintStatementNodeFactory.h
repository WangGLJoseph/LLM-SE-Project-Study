//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/PrintStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class PrintStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> PrintStatement;
  typedef std::shared_ptr<VariableNode> Variable;

public:
  PrintStatementNodeFactory();
  ~PrintStatementNodeFactory();

  PrintStatement createStatementNode(Tokens &tokens) override;
};