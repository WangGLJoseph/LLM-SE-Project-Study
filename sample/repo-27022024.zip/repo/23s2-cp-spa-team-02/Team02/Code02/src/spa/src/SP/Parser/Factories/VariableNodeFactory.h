//
// Created by yeemi on 2/12/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/VariableNode.h"
#include "SP/Tokenizer/Tokens.h"

class VariableNodeFactory {
private:
  typedef std::shared_ptr<VariableNode> Variable;

public:
  VariableNodeFactory();
  ~VariableNodeFactory();

  Variable createVariableNode(Tokens &tokens);
};
