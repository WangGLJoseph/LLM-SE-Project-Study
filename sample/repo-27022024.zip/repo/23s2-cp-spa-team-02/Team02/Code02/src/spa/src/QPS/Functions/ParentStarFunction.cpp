#include "ParentStarFunction.h"

Result ParentStarFunction::operator()(const StClause &clause, PKBManager &pkb) {

  const ClauseArgument& arg1 = clause.getArg1();

  if (arg1.second == EntityType::STMT_NUM) {

    return constantArg1(arg1.first, clause.getArg2(), pkb);

  } else if (arg1.second == EntityType::WILDCARD) {

    return wildcardArg1(clause.getArg2(), pkb);

  } else {

    return synonymArg1(arg1, clause.getArg2(), pkb);

  }
}

Result ParentStarFunction::constantArg1(const std::string &arg1Str, const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(pkb.doesUnderscoreChildOfStmtStarNumber(arg1Str));

  } else if (arg2.second == EntityType::STMT_NUM) {

    return Result(pkb.hasParentStarRelationship(arg1Str, arg2.first));

  } else {
    
    return Result(arg2.first, pkb.getChildWithParentStarNumber(arg1Str, entityToStatementType(arg2.second)));

  }
}

Result ParentStarFunction::wildcardArg1(const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(pkb.parentStarExists());

  } else if (arg2.second == EntityType::STMT_NUM) {

    return Result(pkb.doesUnderscoreParentOfStmtStarNumber(arg2.first));

  } else {

    return Result(arg2.first, pkb.getChildStarWithType(
                                  entityToStatementType(arg2.second)));
  }
}

Result ParentStarFunction::synonymArg1(const ClauseArgument& arg1, const ClauseArgument& arg2, PKBManager& pkb) {

  StatementType arg1StmtType = entityToStatementType(arg1.second);

  if (arg2.second == EntityType::WILDCARD) {

    return Result(arg1.first, pkb.getParentStarWithType(arg1StmtType));

  } else if (arg2.second == EntityType::STMT_NUM) {

    return Result(arg1.first, pkb.getParentStarWithChildNumber(arg2.first, arg1StmtType));

  } else if (arg1.first == arg2.first) {

    // (s, s) is not possible
    return Result(false);

  } else {

    return Result(arg1.first, arg2.first, pkb.getAllParentStarPairsWithTypes(arg1StmtType, entityToStatementType(arg2.second)));

  }
}