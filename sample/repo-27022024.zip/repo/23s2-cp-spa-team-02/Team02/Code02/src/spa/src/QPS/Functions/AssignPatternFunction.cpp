#include "AssignPatternFunction.h"

Result AssignPatternFunction::operator()(const PatternClause &clause, PKBManager &pkb) {

  const ClauseArgument& arg1 = clause.getArg1();

  if (arg1.second == EntityType::WILDCARD) {

    return wildcardArg1(clause.getPatternSyn(), clause.getArg2(), pkb);

  } else if (arg1.second == EntityType::NAME) {

    return nameArg1(clause.getPatternSyn(), arg1.first, clause.getArg2(), pkb);

  } else {

    // Variable
    return synonymArg1(clause.getPatternSyn(), arg1, clause.getArg2(), pkb);

  }
}

Result AssignPatternFunction::wildcardArg1(const std::string &assignSyn, const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(assignSyn, pkb.getAssignAllStatements());

  } else if (arg2.second == EntityType::PARTIAL_MATCH) {

    return Result(assignSyn, pkb.getAssignGivenPartial(arg2.first));

  } else {

    // Exact match, not needed for MS1
    return Result(false);

  }
}

Result AssignPatternFunction::nameArg1(const std::string &assignSyn, const std::string &arg1Str, const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(assignSyn, pkb.getAssignGivenVariableUnderscore(arg1Str));

  } else if (arg2.second == EntityType::PARTIAL_MATCH) {

    return Result(assignSyn, pkb.getAssignGivenVariableGivenPartial(arg1Str, arg2.first));

  } else {

    // Exact match, not needed for MS1
    return Result(false);

  }
}

Result AssignPatternFunction::synonymArg1(const std::string &assignSyn, const ClauseArgument &arg1, const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(assignSyn, arg1.first, pkb.getAssignVariableUnderscore());

  } else if (arg2.second == EntityType::PARTIAL_MATCH) {

    return Result(assignSyn, arg1.first, pkb.getAssignVariableGivenPartial(arg2.first));

  } else {

    // Exact match, not needed for MS1
    return Result(false);

  }
}