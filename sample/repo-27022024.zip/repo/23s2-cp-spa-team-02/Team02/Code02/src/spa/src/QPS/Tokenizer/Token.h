#pragma once
#include "TokenType.h"
#include <string>

class Token {
public:
  Token(std::string value, const TokenType &type);
  [[nodiscard]] const std::string &getValue() const;
  [[nodiscard]] const TokenType &getType() const;
private:
  std::string value;
  TokenType type;

};
