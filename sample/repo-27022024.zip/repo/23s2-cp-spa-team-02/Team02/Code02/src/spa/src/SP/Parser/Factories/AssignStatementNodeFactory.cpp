//
// Created by yeemi on 2/10/2024.
//

#include "AssignStatementNodeFactory.h"
#include "NodeFactory.h"

AssignStatementNodeFactory::AssignStatementNodeFactory() = default;

AssignStatementNodeFactory::~AssignStatementNodeFactory() = default;

AssignStatementNodeFactory::AssignStatement
AssignStatementNodeFactory::createStatementNode(Tokens &tokens) {
  Variable variableNode = NodeFactory::createVariableNode(tokens);

  tokens.ensureNextTokenType(TokenTypeSP::ASSIGN);

  ArithmeticExpression arithmeticExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::ARITHMETIC);

  AssignStatementNode assignStatementNode =
      AssignStatementNode(NodeFactory::getStatementNumber(), variableNode,
                          arithmeticExpressionNode);

  return std::make_shared<AssignStatementNode>(assignStatementNode);
}
