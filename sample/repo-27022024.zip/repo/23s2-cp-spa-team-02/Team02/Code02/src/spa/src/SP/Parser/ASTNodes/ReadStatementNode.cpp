//
// Created by yeemi on 2/10/2024.
//

#include "ReadStatementNode.h"

ReadStatementNode::ReadStatementNode(int statementNumber, Variable variableNode)
    : StatementNode(statementNumber, StatementType::READ),
      _variableNode(std::move(variableNode)) {}

ReadStatementNode::~ReadStatementNode() = default;

void ReadStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitReadStatementNode(*this);
}

ReadStatementNode::Variable ReadStatementNode::getVariableNode() const {
  return _variableNode;
}

std::string ReadStatementNode::getVariableName() const {
  return getVariableNode()->getName();
}
