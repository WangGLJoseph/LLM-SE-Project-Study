//
// Created by Evan Chng on 11/2/24.
//

#include "Tokens.h"
#include "Exceptions/SyntaxErrorException.h"
#include "SP/Tokenizer/TokenFactory.h"
#include "Util/ShuntingYard.h"

#include <utility>

Tokens::Tokens(std::vector<TokenSP> tokens)
    : _tokens(std::move(tokens)), _index(0) {
  _length = _tokens.size();
}

Tokens::~Tokens() = default;

int Tokens::getIndex() const { return _index; }

int Tokens::getLength() const { return _length; }

bool Tokens::isEmpty() const { return _index >= _length; }

std::vector<TokenSP> Tokens::getTokens() { return _tokens; }

TokenSP Tokens::at(int idx) {
  if (idx < 0 || idx >= getLength()) {
    return TokenFactory::createToken(TokenTypeSP::ERROR, "out of range");
  }
  return getTokens().at(idx);
}

TokenTypeSP Tokens::peekHead() { return at(getIndex()).getType(); }

void Tokens::increaseIndex(int numberOfTokens) { _index += numberOfTokens; }

int Tokens::getRightParenthesisIndex(int curr) {
  int count = 0;
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();

    switch (type) {
    case TokenTypeSP::LEFT_PARENTHESIS:
      ++count;
      break;
    case TokenTypeSP::RIGHT_PARENTHESIS:
      --count;
      if (count < 0) {
        return curr;
      }
    default:
      break;
    }
    ++curr;
  }
  throw SyntaxErrorException(
      "unable to find matching RightParenthesis for startidx=" +
      std::to_string(curr));
}

int Tokens::getRightCurlyBracketIndex(int curr) {
  int count = 0;
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();

    switch (type) {
    case TokenTypeSP::LEFT_CURLY_BRACKET:
      ++count;
      break;
    case TokenTypeSP::RIGHT_CURLY_BRACKET:
      --count;
      if (count < 0) {
        return curr;
      }
    default:
      break;
    }
    ++curr;
  }
  throw SyntaxErrorException("unable to find matching RightCurlyBracket");
}

TokenSP Tokens::getNextToken() {
  increaseIndex(1);
  return at(getIndex() - 1);
}

int Tokens::getSemicolonIndex() {
  int curr = getIndex();
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();
    if (type == TokenTypeSP::SEMICOLON)
      return curr;
    curr++;
  }
  return curr;
}

std::string Tokens::getPostFixExpression(int startIdx, int endIdx) {
  std::string infix;
  // build expression with tokens seperated by whitespace
  // eg. x * ( 1 + 2 )
  for (int i = startIdx; i < endIdx; i++) {
    TokenSP cur = Tokens::at(i);
    infix += cur.getValue() + " ";
  }

  // if last character is whitespace
  if (!infix.empty() && infix[infix.length() - 1] == ' ') {
    infix = infix.substr(0, infix.length() - 1); // remove the last character
  }

  return ShuntingYard::infixToPostfix(infix);
}

void Tokens::ensureNextTokenType(TokenTypeSP t) {
  return getNextToken().ensureType(t);
}
void Tokens::ensureTokenTypeAt(int index, TokenTypeSP t) {
  return at(index).ensureType(t);
}

bool Tokens::isVariableAt(int index) {
  return at(index).isVariable();
}

bool Tokens::isRelationalAt(int index) {
  return at(index).isRelationalToken();
}

bool Tokens::checkTypeAt(int index, TokenTypeSP t) {
  return at(index).isType(t);
}