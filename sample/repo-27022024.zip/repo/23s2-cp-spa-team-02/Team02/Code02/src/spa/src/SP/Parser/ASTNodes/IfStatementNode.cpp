//
// Created by yeemi on 2/10/2024.
//

#include "IfStatementNode.h"

IfStatementNode::IfStatementNode(
    int statementNumber, ConditionalExpression conditionalExpressionNode,
    ThenStatementList thenStatementNodes, ElseStatementList elseStatementNodes)
    : StatementNode(statementNumber, StatementType::IF),
      _conditionalExpressionNode(std::move(conditionalExpressionNode)),
      _thenStatementNodes(std::move(thenStatementNodes)),
      _elseStatementNodes(std::move(elseStatementNodes)) {}

IfStatementNode::~IfStatementNode() = default;

void IfStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitIfStatementNode(*this);
}

IfStatementNode::ConditionalExpression
IfStatementNode::getConditionalExpressionNode() const {
  return _conditionalExpressionNode;
}

IfStatementNode::ThenStatementList
IfStatementNode::getThenStatementNodes() const {
  return _thenStatementNodes;
}

IfStatementNode::ElseStatementList
IfStatementNode::getElseStatementNodes() const {
  return _elseStatementNodes;
}