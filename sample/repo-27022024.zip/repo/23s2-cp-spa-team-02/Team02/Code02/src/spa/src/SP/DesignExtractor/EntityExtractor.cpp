//
// Created by yeemi on 2/8/2024.
//

#include "EntityExtractor.h"
#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/ASTNodes/CallStatementNode.h"
#include "SP/Parser/ASTNodes/ConstantNode.h"
#include "SP/Parser/ASTNodes/ExpressionNode.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/PrintStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/ReadStatementNode.h"
#include "SP/Parser/ASTNodes/VariableNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

EntityExtractor::EntityExtractor(PKBManager &pkbManager)
    : BaseExtractor(pkbManager) {}

EntityExtractor::~EntityExtractor() = default;

void EntityExtractor::visitProcedureNode(const ProcedureNode &procedureNode) {
  std::string procName = procedureNode.getName();
  getPKBManager().addProcedure(procName);
  visitStatementNodeList(procedureNode.getStatementNodes());
}

void EntityExtractor::visitStatementNodeList(
    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    statementNode->accept(shared_from_this());
  }
}

void EntityExtractor::visitConstantNode(const ConstantNode &constantNode) {
  std::string constantName = constantNode.getName();
  getPKBManager().addConstant(constantName);
}

void EntityExtractor::visitVariableNode(const VariableNode &variableNode) {
  std::string variableName = variableNode.getName();
  getPKBManager().addVariable(variableName);
}

void EntityExtractor::visitAssignStatementNode(
    const AssignStatementNode &assignStatementNode) {
  std::string variableName = assignStatementNode.getVariableName();
  getPKBManager().addVariable(variableName);
  getPKBManager().addStatementWithType(
      std::to_string(assignStatementNode.getStatementNumber()),
      assignStatementNode.getStatementType());
  assignStatementNode.getArithmeticExpressionNode()->accept(shared_from_this());
}

void EntityExtractor::visitCallStatementNode(
    const CallStatementNode &callStatementNode) {
  std::string procName = callStatementNode.getProcedureName();
  getPKBManager().addProcedure(procName);
  getPKBManager().addStatementWithType(
      std::to_string(callStatementNode.getStatementNumber()),
      callStatementNode.getStatementType());
}

void EntityExtractor::visitIfStatementNode(
    const IfStatementNode &ifStatementNode) {
  getPKBManager().addStatementWithType(
      std::to_string(ifStatementNode.getStatementNumber()),
      ifStatementNode.getStatementType());
  visitConditionalExpressionNode(
      *ifStatementNode.getConditionalExpressionNode());
  visitStatementNodeList(ifStatementNode.getThenStatementNodes());
  visitStatementNodeList(ifStatementNode.getElseStatementNodes());
}

void EntityExtractor::visitPrintStatementNode(
    const PrintStatementNode &printStatementNode) {
  getPKBManager().addStatementWithType(
      std::to_string(printStatementNode.getStatementNumber()),
      printStatementNode.getStatementType());
  std::string variableName = printStatementNode.getVariableName();
  getPKBManager().addVariable(variableName);
}

void EntityExtractor::visitReadStatementNode(
    const ReadStatementNode &readStatementNode) {
  getPKBManager().addStatementWithType(
      std::to_string(readStatementNode.getStatementNumber()),
      readStatementNode.getStatementType());
  std::string variableName = readStatementNode.getVariableName();
  getPKBManager().addVariable(variableName);
}

void EntityExtractor::visitWhileStatementNode(
    const WhileStatementNode &whileStatementNode) {

  getPKBManager().addStatementWithType(
      std::to_string(whileStatementNode.getStatementNumber()),
      whileStatementNode.getStatementType());
  visitConditionalExpressionNode(
      *whileStatementNode.getConditionalExpressionNode());
  visitStatementNodeList(whileStatementNode.getStatementNodes());
}

void EntityExtractor::visitArithmeticExpressionNode(
    const ExpressionNode &arithmeticExpressionNode) {
  extractData(arithmeticExpressionNode);
}

void EntityExtractor::visitConditionalExpressionNode(
    const ExpressionNode &conditionalExpressionNode) {
  extractData(conditionalExpressionNode);
}

void EntityExtractor::extractData(const ExpressionNode &expressionNode) {
  for (auto &variableNode : expressionNode.getVariableNodes()) {
    variableNode->accept(shared_from_this());
  }
  for (auto &constantNode : expressionNode.getConstantNodes()) {
    constantNode->accept(shared_from_this());
  }
}

void EntityExtractor::visitProgramNode(const ProgramNode &programNode) {}