#include "Result.h"

Result::Result(std::initializer_list<std::string> synonyms) {
  for (const auto& synonym : synonyms) {
    // Initialises entry
    table_[synonym];
  }
}

Result::Result(const std::string &synonym, const std::unordered_set<std::string> &vals) {

  std::vector<std::string>& col = table_[synonym];

  col.reserve(vals.size());

  for (auto& val: vals) {
    col.push_back(val);
  }
}

Result::Result(const std::string &syn1, const std::string &syn2,
    std::unordered_set<std::pair<std::string, std::string>, PairHash> vals) {

  std::vector<std::string>& col1 = table_[syn1];
  std::vector<std::string>& col2 = table_[syn2];

  col1.reserve(vals.size());
  col2.reserve(vals.size());

  for (auto& val: vals) {
    col1.push_back(val.first);
    col2.push_back(val.second);
  }
}

Result::Result(const std::string &syn1, const std::string &syn2, const std::string &syn3, const std::unordered_set<std::tuple<std::string, std::string, std::string>> &vals) {

  std::vector<std::string>& col1 = table_[syn1];
  std::vector<std::string>& col2 = table_[syn2];
  std::vector<std::string>& col3 = table_[syn3];

  col1.reserve(vals.size());
  col2.reserve(vals.size());
  col3.reserve(vals.size());

  for (auto& val: vals) {
    col1.push_back(std::get<0>(val));
    col2.push_back(std::get<1>(val));
    col3.push_back(std::get<2>(val));
  }
}

std::unordered_set<std::string> Result::getSynonym(const std::string& synonym) {

    std::vector<std::string>& synonymValues = table_[synonym];

    return {synonymValues.begin(), synonymValues.end()};
}

bool Result::isEmpty() const {

  return table_.empty();
}

bool Result::isPossible() const {

  return validFlag_ && (isEmpty() || size() > 0);
}

void Result::populateSynonym(const std::string &synonym, const std::vector<std::string> &values) {
  table_[synonym] = values;
}

size_t Result::size() const {

  if (isEmpty()) {
    return 0;
  } else {
    return table_.begin()->second.size();
  }
}

bool Result::contains(const std::string &synonym) {

  return table_.find(synonym) != table_.end();

}

Result Result::combineWith(Result &other) {

  if (!isPossible() || !other.isPossible()) {
    return Result(false);
  }

  if (isEmpty()) {
    return other;
  } else if (other.isEmpty()) {
    return *this;
  }

  Table newTable;

  // Vector of references to avoid hashing and looking up everytime
  std::vector<std::reference_wrapper<std::vector<std::string>>> thisOverlaps, otherOverlaps, thisNonOverlaps, otherNonOverlaps, newValues;

  // Find keys that overlap
  std::unordered_set<std::string> thisKeys, otherKeys;

  for (auto& [key, value] : table_) {
    thisKeys.insert(key);
  }

  for (auto& [key, value] : other.table_) {
    otherKeys.insert(key);
  }

  // Overlapping variables
  for (auto it = thisKeys.begin(); it != thisKeys.end();) {
    if (otherKeys.count(*it) > 0) {

      thisOverlaps.emplace_back(table_[*it]);
      otherOverlaps.emplace_back(other.table_[*it]);
      newValues.emplace_back(newTable[*it]);

      otherKeys.erase(*it);
      it = thisKeys.erase(it);
    } else {
      ++it;
    }
  }

  // Non-overlapping variables for this Result
  for (auto& key: thisKeys) {
    thisNonOverlaps.emplace_back(table_[key]);
    newValues.emplace_back(newTable[key]);
  }

  // Non-overlapping variables for other Result
  for (auto& key: otherKeys) {
    otherNonOverlaps.emplace_back(other.table_[key]);
    newValues.emplace_back(newTable[key]);
  }

  // Hash join build phase
  // build with thisValues
  std::unordered_map<std::vector<std::string>, std::vector<std::vector<std::string>>> build;

  size_t numEntries = this->size();
  for (size_t row  = 0; row < numEntries; ++row) {

    std::vector<std::string> key;
    std::vector<std::string> node;

    for (auto& vec: thisOverlaps) {
      key.push_back(vec.get()[row]);
    }

    for (auto& vec: thisNonOverlaps) {
      node.push_back(vec.get()[row]);
    }

    build[key].push_back(node);
  }

  // Probe phase
  size_t numProbes = other.size();

  for (size_t row = 0; row < numProbes; ++row) {

    std::vector<std::string> key;

    key.reserve(otherOverlaps.size());

    for (auto& vec: otherOverlaps) {
      key.push_back(vec.get()[row]);
    }

    auto it = build.find(key);

    if (it == build.end())  {
      continue;
    }

    for (auto& node: it->second) {

      size_t column = 0;

      // Push in overlapping values
      for (auto& str: key) {
        newValues[column++].get().push_back(str);
      }

      // Push in non-overlaps for this Result
      for (auto& str: node) {
        newValues[column++].get().push_back(str);
      }

      // Push in non-overlaps for other Result
      for (auto& vec: otherNonOverlaps) {
        newValues[column++].get().push_back(vec.get()[row]);
      }
    }
  }

  return Result(newTable);
}

ResultSet Result::retrieveValues(const std::vector<std::string> &selectedTuple) {

  if (!isPossible()) {
    return {};
  }

  std::vector<std::reference_wrapper<std::vector<std::string>>> relevantCols;

  ResultSet tupleSet;

  relevantCols.reserve(selectedTuple.size());

  for (auto& synonym: selectedTuple) {
    relevantCols.emplace_back(table_[synonym]);
  }

  for (size_t row = 0; row < this->size(); ++row) {

    std::vector<std::string> tuple;

    tuple.reserve(relevantCols.size());

    for (auto& col: relevantCols) {
      tuple.push_back(col.get()[row]);
    }

    tupleSet.insert(tuple);
  }

  return tupleSet;
}
