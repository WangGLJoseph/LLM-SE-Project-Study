//
// Created by yeemi on 2/10/2024.
//

#include "AssignStatementNode.h"

AssignStatementNode::AssignStatementNode(
    int statementNumber, Variable variableNode,
    ArithmeticExpression arithmeticExpressionNode)
    : StatementNode(statementNumber, StatementType::ASSIGN),
      _variableNode(std::move(variableNode)),
      _arithmeticExpressionNode(std::move(arithmeticExpressionNode)) {}

AssignStatementNode::~AssignStatementNode() = default;

void AssignStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitAssignStatementNode(*this);
}

AssignStatementNode::Variable AssignStatementNode::getVariableNode() const {
  return _variableNode;
}

AssignStatementNode::ArithmeticExpression
AssignStatementNode::getArithmeticExpressionNode() const {
  return _arithmeticExpressionNode;
}

std::string AssignStatementNode::getVariableName() const {
  return getVariableNode()->getName();
}
