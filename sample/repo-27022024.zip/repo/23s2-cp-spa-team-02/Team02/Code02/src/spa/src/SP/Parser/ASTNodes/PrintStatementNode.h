//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "StatementNode.h"
#include "VariableNode.h"

class PrintStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::shared_ptr<VariableNode> Variable;
  Variable _variableNode;

public:
  explicit PrintStatementNode(int statementNumber, Variable variableNode);
  ~PrintStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] Variable getVariableNode() const;
  [[nodiscard]] std::string getVariableName() const;
};