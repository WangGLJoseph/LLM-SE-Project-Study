//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../BaseExtractor.h"
#include <string>
#include <vector>

class ParentExtractor : public BaseExtractor,
                        public std::enable_shared_from_this<ParentExtractor> {
private:
  typedef std::vector<int> GrandParentStatementNumber;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  GrandParentStatementNumber _grandParents;

public:
  explicit ParentExtractor(PKBManager &pkbManager);
  ~ParentExtractor();

  void visitProcedureNode(const ProcedureNode &procedureNode) override;
  void visitStatementNodeList(const StatementList &statementNodes) override;
  void visitConstantNode(const ConstantNode &constantNode) override;
  void visitVariableNode(const VariableNode &variableNode) override;
  void visitAssignStatementNode(
      const AssignStatementNode &assignStatementNode) override;
  void
  visitCallStatementNode(const CallStatementNode &callStatementNode) override;
  void visitIfStatementNode(const IfStatementNode &ifStatementNode) override;
  void visitPrintStatementNode(
      const PrintStatementNode &printStatementNode) override;
  void
  visitReadStatementNode(const ReadStatementNode &readStatementNode) override;
  void visitWhileStatementNode(
      const WhileStatementNode &whileStatementNode) override;
  void visitArithmeticExpressionNode(
      const ExpressionNode &arithmeticExpressionNode) override;
  void visitConditionalExpressionNode(
      const ExpressionNode &conditionalExpressionNode) override;
  void extractParent(int parentStatementNumber,
                     const StatementList &statementNodes);
  void visitProgramNode(const ProgramNode &programNode) override;
  GrandParentStatementNumber &getGrandParents();
};
