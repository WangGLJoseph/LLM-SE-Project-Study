#pragma once

#include <unordered_set>

#include "PKB/API/PKBManager.h"

#include "QPS/Evaluators/KnowledgeRetriever.h"
#include "QPS/Evaluators/QueryEvaluator.h"
#include "QPS/Parser/QueryParser.h"
#include "QPS/Result.h"

using QueryResult = std::unordered_set<std::string>;

class QPS {

public:
    explicit QPS(PKBManager& pkb) : pkb_(pkb), evaluator_(pkb) {};
    virtual ~QPS() = default;

    QueryResult processQuery(const std::string& query);

private:
    QueryEvaluator evaluator_;
    QueryParser parser;
    PKBManager& pkb_;

    const std::unordered_set<std::string> syntaxErr_{"SyntaxError"};
    const std::unordered_set<std::string> semanticErr_{"SemanticError"};
};
