//
// Created by yeemi on 2/10/2024.
//

#include "IfStatementNodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"
#include "NodeFactory.h"

IfStatementNodeFactory::IfStatementNodeFactory() = default;

IfStatementNodeFactory::~IfStatementNodeFactory() = default;

IfStatementNodeFactory::IfStatement
IfStatementNodeFactory::createStatementNode(Tokens &tokens) {
  int statementNumber = NodeFactory::getStatementNumber();

  // Skip "if" and "("
  tokens.ensureNextTokenType(TokenTypeSP::IF);
  tokens.ensureNextTokenType(TokenTypeSP::LEFT_PARENTHESIS);

  ConditionalExpression conditionalExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::CONDITIONAL);

  // Skip "then {". ")" already skipped in conditionalExpressionNodeFactory
  tokens.ensureNextTokenType(TokenTypeSP::THEN);
  tokens.ensureNextTokenType(TokenTypeSP::LEFT_CURLY_BRACKET);

  ThenStatementList thenStatementNodes;
  int rightCurlyBracketIndex =
      tokens.getRightCurlyBracketIndex(tokens.getIndex());
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    Statement statementNode = NodeFactory::createStatementNode(tokens);
    thenStatementNodes.push_back(statementNode);
  }
  if (thenStatementNodes.empty()) {
    throw SyntaxErrorException("StmtLst must have 1 or more statements");
  }

  ElseStatementList elseStatementNodes;
  // Skip "} else {"
  tokens.ensureNextTokenType(TokenTypeSP::RIGHT_CURLY_BRACKET);
  tokens.ensureNextTokenType(TokenTypeSP::ELSE);
  tokens.ensureNextTokenType(TokenTypeSP::LEFT_CURLY_BRACKET);

  rightCurlyBracketIndex = tokens.getRightCurlyBracketIndex(tokens.getIndex());
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    Statement statementNode = NodeFactory::createStatementNode(tokens);
    elseStatementNodes.push_back(statementNode);
  }
  if (elseStatementNodes.empty()) {
    throw SyntaxErrorException("StmtLst must have 1 or more statements");
  }

  // Skip "}"
  tokens.ensureNextTokenType(TokenTypeSP::RIGHT_CURLY_BRACKET);

  IfStatementNode ifStatementNode =
      IfStatementNode(statementNumber, conditionalExpressionNode,
                      thenStatementNodes, elseStatementNodes);
  return std::make_shared<IfStatementNode>(ifStatementNode);
}
