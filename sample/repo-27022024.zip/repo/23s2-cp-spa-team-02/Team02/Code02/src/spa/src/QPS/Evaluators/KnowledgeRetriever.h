#pragma once

#include "QPS/Evaluators/GenericDispatcher.h"
#include "QPS/Functions/AssignPatternFunction.h"
#include "QPS/Functions/FollowsFunction.h"
#include "QPS/Functions/FollowsStarFunction.h"
#include "QPS/Functions/ModifiesFunction.h"
#include "QPS/Functions/ParentFunction.h"
#include "QPS/Functions/ParentStarFunction.h"
#include "QPS/Functions/UsesFunction.h"
#include "QPS/Query.h"

using SuchThatDispatcher =
    GenericDispatcher<StClause,
                                      ParentFunction,
                                      ParentStarFunction,
                                      FollowsFunction,
                                      FollowsStarFunction,
                                      ModifiesFunction,
                                      UsesFunction>;

using PatternDispatcher =
    GenericDispatcher<PatternClause, AssignPatternFunction>;

class KnowledgeRetriever {

public:
  explicit KnowledgeRetriever(PKBManager& pkb) : pkb_(pkb), stDispatcher_(pkb_), patternDispatcher_(pkb_) {};
  virtual ~KnowledgeRetriever() = default;

  Result getAllValues(const std::string& synonym, EntityType valType);

  Result dispatchClause(const StClause& stClause);

  Result dispatchClause(const PatternClause& patternClause);

private:
  PKBManager& pkb_;
  SuchThatDispatcher stDispatcher_;
  PatternDispatcher patternDispatcher_;
};