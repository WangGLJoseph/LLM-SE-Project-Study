//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <vector>

class ExpressionNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;
  VariableList _variableNodes;
  ConstantList _constantNodes;

public:
  explicit ExpressionNode(VariableList variableNodes,
                          ConstantList constantNodes);
  ~ExpressionNode();

  void accept(const Visitor &extractorVisitor) const override = 0;

  [[nodiscard]] VariableList getVariableNodes() const;
  [[nodiscard]] ConstantList getConstantNodes() const;
};