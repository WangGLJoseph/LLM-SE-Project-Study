//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "StatementNode.h"
#include "VariableNode.h"

class ReadStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::shared_ptr<VariableNode> Variable;
  Variable _variableNode;

public:
  explicit ReadStatementNode(int statementNumber, Variable variableNode);
  ~ReadStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] Variable getVariableNode() const;
  [[nodiscard]] std::string getVariableName() const;
};