//
// Created by yeemi on 2/10/2024.
//

#pragma once
#include "../../DesignExtractor/ExtractorVisitor.h"
#include "ExpressionNode.h"
#include "StatementNode.h"
#include <vector>

class IfStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::shared_ptr<ExpressionNode> ConditionalExpression;
  typedef std::vector<std::shared_ptr<StatementNode>> ThenStatementList;
  typedef std::vector<std::shared_ptr<StatementNode>> ElseStatementList;
  ConditionalExpression _conditionalExpressionNode;
  ThenStatementList _thenStatementNodes;
  ElseStatementList _elseStatementNodes;

public:
  explicit IfStatementNode(int statementNumber,
                           ConditionalExpression conditionalExpressionNode,
                           ThenStatementList thenStatementNodes,
                           ElseStatementList elseStatementNodes);
  ~IfStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] ConditionalExpression getConditionalExpressionNode() const;
  [[nodiscard]] ThenStatementList getThenStatementNodes() const;
  [[nodiscard]] ElseStatementList getElseStatementNodes() const;
};