//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../../PKB/API/PKBManager.h"
#include "ExtractorVisitor.h"

class BaseExtractor : public ExtractorVisitor {
private:
  PKBManager &_pkbManager;

public:
  explicit BaseExtractor(PKBManager &pkbManager);

  PKBManager &getPKBManager();
};
