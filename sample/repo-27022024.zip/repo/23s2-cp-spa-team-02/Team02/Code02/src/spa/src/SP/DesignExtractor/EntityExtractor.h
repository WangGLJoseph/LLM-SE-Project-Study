//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "SP/DesignExtractor/BaseExtractor.h"
#include "SP/Parser/ASTNodes/ExpressionNode.h"
#include <vector>

class EntityExtractor : public BaseExtractor,
                        public std::enable_shared_from_this<EntityExtractor> {
private:
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;

public:
  explicit EntityExtractor(PKBManager &pkbManager);
  ~EntityExtractor();

  void visitProcedureNode(const ProcedureNode &procedureNode) override;
  void visitStatementNodeList(const StatementList &statementNodes) override;
  void visitConstantNode(const ConstantNode &constantNode) override;
  void visitVariableNode(const VariableNode &variableNode) override;
  void visitAssignStatementNode(
      const AssignStatementNode &assignStatementNode) override;
  void
  visitCallStatementNode(const CallStatementNode &callStatementNode) override;
  void visitIfStatementNode(const IfStatementNode &ifStatementNode) override;
  void visitPrintStatementNode(
      const PrintStatementNode &printStatementNode) override;
  void
  visitReadStatementNode(const ReadStatementNode &readStatementNode) override;
  void visitWhileStatementNode(
      const WhileStatementNode &whileStatementNode) override;
  void visitArithmeticExpressionNode(
      const ExpressionNode &arithmeticExpressionNode) override;
  void visitConditionalExpressionNode(
      const ExpressionNode &conditionalExpressionNode) override;
  void extractData(const ExpressionNode &expressionNode);
  void visitProgramNode(const ProgramNode &programNode) override;
};
