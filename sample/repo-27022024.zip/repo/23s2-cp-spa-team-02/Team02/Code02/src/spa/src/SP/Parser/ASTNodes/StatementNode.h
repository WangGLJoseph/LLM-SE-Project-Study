//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <string>

class StatementNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  int _statementNumber;
  StatementType _statementType;

public:
  explicit StatementNode(int statementNumber, StatementType statementType);

  [[nodiscard]] int getStatementNumber() const;
  [[nodiscard]] StatementType getStatementType() const;

  void accept(const Visitor &extractorVisitor) const override = 0;
};