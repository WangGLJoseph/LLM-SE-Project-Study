#pragma once

#include "QPS/Evaluators/KnowledgeRetriever.h"

class QueryEvaluator {

public:
  explicit QueryEvaluator(PKBManager& pkbReadFacade) : dispatcher_(pkbReadFacade) {};

  ResultSet evaluateQuery(Query& query);

private:
  KnowledgeRetriever dispatcher_;
};
