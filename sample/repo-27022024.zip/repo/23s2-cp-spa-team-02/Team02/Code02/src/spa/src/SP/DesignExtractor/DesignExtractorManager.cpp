//
// Created by yeemi on 2/8/2024.
//

#include "DesignExtractorManager.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"

DesignExtractorManager::DesignExtractorManager(const ProgramNode &AST,
                                               PKBManager &pkbManager)
    : _ast(AST), _pkbManager(pkbManager) {}

DesignExtractorManager::~DesignExtractorManager() = default;

void DesignExtractorManager::extractData() {
  // extract entities
  Visitor entityExtractor = std::make_shared<EntityExtractor>(getPKBManager());
  getAST().accept(entityExtractor);

  // extract follows and follows*
  Visitor followsExtractor =
      std::make_shared<FollowsExtractor>(getPKBManager());
  getAST().accept(followsExtractor);

  // extract parent and parent*
  Visitor parentExtractor = std::make_shared<ParentExtractor>(getPKBManager());
  getAST().accept(parentExtractor);

  // extract modifies
  Visitor modifiesExtractor =
      std::make_shared<ModifiesExtractor>(getPKBManager());
  getAST().accept(modifiesExtractor);

  // extract uses
  Visitor usesExtractor = std::make_shared<UsesExtractor>(getPKBManager());
  getAST().accept(usesExtractor);
}

ProgramNode DesignExtractorManager::getAST() { return _ast; }
PKBManager &DesignExtractorManager::getPKBManager() { return _pkbManager; }
