//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <vector>

class ProgramNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::vector<std::shared_ptr<ProcedureNode>> ProcedureList;
  typedef std::shared_ptr<ProcedureNode> Procedure;
  ProcedureList _procedureNodes;

public:
  explicit ProgramNode(ProcedureList &procedureNodes);
  ~ProgramNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] ProcedureList getProcedureNodes() const;
};
