//
// Created by yeemi on 2/10/2024.
//

#include "WhileStatementNodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"
#include "NodeFactory.h"

WhileStatementNodeFactory::WhileStatementNodeFactory() = default;

WhileStatementNodeFactory::~WhileStatementNodeFactory() = default;

WhileStatementNodeFactory::WhileStatement
WhileStatementNodeFactory::createStatementNode(Tokens &tokens) {
  int statementNumber = NodeFactory::getStatementNumber();

  tokens.ensureNextTokenType(TokenTypeSP::WHILE);
  tokens.ensureNextTokenType(TokenTypeSP::LEFT_PARENTHESIS);

  ConditionalExpression conditionalExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::CONDITIONAL);
  StatementList statementNodes;

  tokens.ensureNextTokenType(TokenTypeSP::LEFT_CURLY_BRACKET);
  int rightCurlyBracketIndex =
      tokens.getRightCurlyBracketIndex(tokens.getIndex());
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    Statement statementNode = NodeFactory::createStatementNode(tokens);
    statementNodes.push_back(statementNode);
  }
  if (statementNodes.empty()) {
    throw SyntaxErrorException("StmtLst must have 1 or more statements");
  }

  tokens.ensureNextTokenType(TokenTypeSP::RIGHT_CURLY_BRACKET);
  WhileStatementNode whileStatementNode = WhileStatementNode(
      statementNumber, conditionalExpressionNode, statementNodes);
  return std::make_shared<WhileStatementNode>(whileStatementNode);
}
