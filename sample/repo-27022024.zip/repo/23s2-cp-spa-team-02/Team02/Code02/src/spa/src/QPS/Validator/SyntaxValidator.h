#pragma once
#include "Exceptions/SyntaxErrorException.h"
#include "QPS/PQLGrammar.h"
#include "QPS/Tokenizer/Token.h"
#include "QPS/Tokenizer/TokenType.h"

class SyntaxValidator {
public:
  void validateToken(const Token &token, TokenType expectedTokenType);

private:
  bool isValidDeclarationEntity(const Token &token);
  bool isValidIdent(const std::string &s);
  bool isValidExprSpec(const std::string &str);
};
