//
// Created by yeemi on 2/8/2024.
//

#include "FollowsExtractor.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

FollowsExtractor::FollowsExtractor(PKBManager &pkbManager)
    : BaseExtractor(pkbManager) {}

FollowsExtractor::~FollowsExtractor() = default;

void FollowsExtractor::visitProcedureNode(const ProcedureNode &procedureNode) {
  extractFollows(procedureNode.getStatementNodes());
  visitStatementNodeList(procedureNode.getStatementNodes());
}

void FollowsExtractor::visitStatementNodeList(
    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    statementNode->accept(shared_from_this());
  }
}

void FollowsExtractor::visitConstantNode(const ConstantNode &constantNode) {}

void FollowsExtractor::visitVariableNode(const VariableNode &variableNode) {}

void FollowsExtractor::visitAssignStatementNode(
    const AssignStatementNode &assignStatementNode) {}

void FollowsExtractor::visitCallStatementNode(
    const CallStatementNode &callStatementNode) {}

void FollowsExtractor::visitIfStatementNode(
    const IfStatementNode &ifStatementNode) {
  extractFollows(ifStatementNode.getThenStatementNodes());
  extractFollows(ifStatementNode.getElseStatementNodes());
  visitStatementNodeList(ifStatementNode.getThenStatementNodes());
  visitStatementNodeList(ifStatementNode.getElseStatementNodes());
}

void FollowsExtractor::visitPrintStatementNode(
    const PrintStatementNode &printStatementNode) {}

void FollowsExtractor::visitReadStatementNode(
    const ReadStatementNode &readStatementNode) {}

void FollowsExtractor::visitWhileStatementNode(
    const WhileStatementNode &whileStatementNode) {
  extractFollows(whileStatementNode.getStatementNodes());
  visitStatementNodeList(whileStatementNode.getStatementNodes());
}

void FollowsExtractor::visitArithmeticExpressionNode(
    const ExpressionNode &arithmeticExpressionNode) {}

void FollowsExtractor::visitConditionalExpressionNode(
    const ExpressionNode &conditionalExpressionNode) {}

void FollowsExtractor::extractFollows(const StatementList &statementNodes) {
  if (statementNodes.size() <= 1)
    return;

  std::vector<std::string> prev;
  for (size_t i = 0; i < statementNodes.size() - 1; i++) {
    std::string stmtNum1 =
        std::to_string(statementNodes[i]->getStatementNumber());
    std::string stmtNum2 =
        std::to_string(statementNodes[i + 1]->getStatementNumber());
    getPKBManager().addFollows(stmtNum1, stmtNum2);
    prev.push_back(stmtNum1);
    for (const std::string &prevStmtNum : prev) {
      getPKBManager().addFollowsStar(prevStmtNum, stmtNum2);
    }
  }
}

void FollowsExtractor::visitProgramNode(const ProgramNode &programNode) {}