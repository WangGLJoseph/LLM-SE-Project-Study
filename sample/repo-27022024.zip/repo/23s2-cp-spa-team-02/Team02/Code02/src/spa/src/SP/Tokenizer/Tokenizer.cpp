//
// Created by Evan Chng on 6/2/24.
//

#include "Tokenizer.h"
#include <istream>
#include <vector>

char Tokenizer::peekChar() {
  if (_readPosition >= input.tellg()) {
    return input.peek();
  }
  return '\0';
}

void Tokenizer::readCharAndAdvance() {
  if (_readPosition >= input.tellg()) {
    _ch = input.get();
    _readPosition++;
  }
  _position++;
}

std::string Tokenizer::readLiteral() {
  std::string lit;
  while (std::isalnum(_ch)) {
    lit.push_back(_ch);
    readCharAndAdvance();
  }
  return lit;
}

void Tokenizer::skipWhitespace() {
  while (std::isspace(_ch)) {
    readCharAndAdvance();
  }
}

bool isNumber(const std::string &str) {
  for (char c : str) {
    if (!std::isdigit(c)) {
      return false;
    }
  }
  if (str == "0") {
    return true;
  }
  size_t firstNonZero = str.find_first_not_of('0');
  return firstNonZero == 0;
}

TokenTypeSP Tokenizer::handleDoubleCharTokens(char c1, char c2) {
  std::string s;
  s.push_back(c1);
  s.push_back(c2);
  auto itr = doubleCharTokens.find(s);
  if (itr != doubleCharTokens.end()) {
    return itr->second;
  }
  return TokenTypeSP::ERROR;
}

TokenTypeSP Tokenizer::handleSingleCharTokens(char c) {
  std::string s;
  s.push_back(c);
  auto itr = singleCharTokens.find(s);
  if (itr != singleCharTokens.end()) {
    return itr->second;
  }
  return TokenTypeSP::ERROR;
}

TokenSP Tokenizer::nextToken() {
  skipWhitespace();

  auto doubleCharTokenType = handleDoubleCharTokens(_ch, peekChar());
  if (doubleCharTokenType != TokenTypeSP::ERROR) {
    std::string s = {_ch, peekChar()};
    readCharAndAdvance();
    readCharAndAdvance();
    return TokenFactory::createToken(doubleCharTokenType, s);
  }

  auto singleCharTokenType = handleSingleCharTokens(_ch);
  if (singleCharTokenType != TokenTypeSP::ERROR) {
    std::string s = {_ch};
    readCharAndAdvance();
    return TokenFactory::createToken(singleCharTokenType, s);
  }

  // handle multi character tokens
  if (std::isalpha(_ch)) {
    std::string lit = readLiteral();
    auto itr = keywords.find(lit);

    if (itr != keywords.end()) {
      return TokenFactory::createToken(itr->second, lit);
    } else {
      return TokenFactory::createToken(TokenTypeSP::NAME, lit);
    }
  }

  if (std::isdigit(_ch)) {
    std::string lit = readLiteral();
    if (!isNumber(lit)) {
      throw SyntaxErrorException("not a valid number");
    }
    return TokenFactory::createToken(TokenTypeSP::INTEGER, lit);
  }

  std::string s(1, _ch);
  throw SyntaxErrorException("TokenTypeSP not found: current char(" + s + ")");
}

Tokens Tokenizer::tokenize() {
  std::vector<TokenSP> tokens;
  readCharAndAdvance();
  while (!input.eof()) {
    auto tok = nextToken();
    tokens.push_back(tok);
    skipWhitespace();
  }
  return Tokens(tokens);
}
