#pragma once

#include "Exceptions/SyntaxErrorException.h"
#include "QPS/PQLGrammar.h"
#include "QPS/Query.h"
#include "Util/StringsUtils.h"
#include "Token.h"
#include <regex>

typedef std::vector<Token> QueryTokens;
class QueryTokenizer {
public:
  static QueryTokens tokenize(const std::string &trimmedQuery);
private:
  static TokenType determineTokenType(const std::smatch &match);

};
