#include "KnowledgeRetriever.h"

Result KnowledgeRetriever::getAllValues(const std::string& synonym, EntityType valType) {

  switch (valType) {
  case EntityType::STATEMENT:
    return Result(synonym, pkb_.getStatements());
  case EntityType::VARIABLE:
    return Result(synonym, pkb_.getVariables());
  case EntityType::PROCEDURE:
    return Result(synonym, pkb_.getProcedures());
  case EntityType::CONSTANT:
    return Result(synonym, pkb_.getConstants());
  default:
    return Result(synonym, pkb_.getStatementsWithType(entityToStatementType(valType)));
  }
}

Result KnowledgeRetriever::dispatchClause(const StClause& stClause) {

  return stDispatcher_.execute(stClause);
}

Result KnowledgeRetriever::dispatchClause(const PatternClause& patternClause) {

  return patternDispatcher_.execute(patternClause);
}