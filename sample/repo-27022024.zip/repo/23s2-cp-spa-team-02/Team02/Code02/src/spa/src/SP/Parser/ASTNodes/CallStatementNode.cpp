//
// Created by yeemi on 2/10/2024.
//

#include "CallStatementNode.h"

#include <utility>

CallStatementNode::CallStatementNode(int statementNumber,
                                     ProcedureName procedureName)
    : StatementNode(statementNumber, StatementType::CALL),
      _procedureName(std::move(procedureName)) {}

CallStatementNode::~CallStatementNode() = default;

void CallStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitCallStatementNode(*this);
}

CallStatementNode::ProcedureName CallStatementNode::getProcedureName() const {
  return _procedureName;
}
