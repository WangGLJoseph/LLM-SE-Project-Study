//
// Created by yeemi on 2/6/2024.
//

#include "SP.h"
#include "Tokenizer/Tokens.h"

void SP::parseSourceProgram(std::istream &sourceProgram,
                            PKBManager &pkbManager) {
  // Tokenize
  auto tokenizer = Tokenizer(sourceProgram);
  Tokens tokens = tokenizer.tokenize();

  // Build AST
  ProgramNode AST = Parser::parseTokens(tokens);

  // Extract
  DesignExtractorManager designExtractor =
      DesignExtractorManager(AST, pkbManager);
  designExtractor.extractData();
}
