//
// Created by yeemi on 2/10/2024.
//

#include "NodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"
#include "Exceptions/UnhandledException.h"

NodeFactory::NodeFactory() = default;

NodeFactory::~NodeFactory() = default;

ProgramNode NodeFactory::createAST(Tokens &tokens) {
  resetStatementNumber();
  ProcedureList procedureNodes;
  while (!tokens.isEmpty()) {
    Procedure procedureNode =
        getProcedureNodeFactory().createProcedureNode(tokens);
    procedureNodes.push_back(procedureNode);
  }
  ProgramNode AST = ProgramNode(procedureNodes);
  return AST;
}

int NodeFactory::getStatementNumber() {
  increaseStatementNumber();
  return _statementNumber - 1;
}

void NodeFactory::increaseStatementNumber() { _statementNumber++; }

void NodeFactory::resetStatementNumber() { _statementNumber = 1; }

std::shared_ptr<StatementNode>
NodeFactory::createStatementNode(Tokens &tokens) {
  TokenSP firstToken = tokens.at(tokens.getIndex());
  TokenSP secondToken = tokens.at(tokens.getIndex() + 1);
  if (secondToken.isType(TokenTypeSP::ASSIGN) && firstToken.isVariable()) {
    return getAssignStatementNodeFactory().createStatementNode(tokens);
  }

  switch (firstToken.getType()) {
  case TokenTypeSP::NAME:
    return getAssignStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::CALL:
    return getCallStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::PRINT:
    return getPrintStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::READ:
    return getReadStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::WHILE:
    return getWhileStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::IF:
    return getIfStatementNodeFactory().createStatementNode(tokens);
  default:
    throw SyntaxErrorException(
        "createStatementNode: first token is not a statement keyword: " +
        TokenSP::getTypeString(firstToken.getType()));
  }
}

NodeFactory::Expression NodeFactory::createExpressionNode(Tokens &tokens,
                                                          ExpressionType type) {
  switch (type) {
  case ExpressionType::ARITHMETIC:
    return getArithmeticExpressionNodeFactory().createExpressionNode(tokens);
  case ExpressionType::CONDITIONAL:
    return getConditionalExpressionNodeFactory().createExpressionNode(tokens);
  default:
    throw UnhandledErrorException(
        "createExpressionNode: unknown expression type");
  }
}

NodeFactory::Constant NodeFactory::createConstantNode(Tokens &tokens) {
  return getConstantNodeFactory().createConstantNode(tokens);
}

NodeFactory::Variable NodeFactory::createVariableNode(Tokens &tokens) {
  return getVariableNodeFactory().createVariableNode(tokens);
}

ProcedureNodeFactory NodeFactory::getProcedureNodeFactory() {
  return ProcedureNodeFactory();
}

AssignStatementNodeFactory NodeFactory::getAssignStatementNodeFactory() {
  return AssignStatementNodeFactory();
}

CallStatementNodeFactory NodeFactory::getCallStatementNodeFactory() {
  return CallStatementNodeFactory();
}

IfStatementNodeFactory NodeFactory::getIfStatementNodeFactory() {
  return IfStatementNodeFactory();
}

ReadStatementNodeFactory NodeFactory::getReadStatementNodeFactory() {
  return ReadStatementNodeFactory();
}

PrintStatementNodeFactory NodeFactory::getPrintStatementNodeFactory() {
  return PrintStatementNodeFactory();
}

WhileStatementNodeFactory NodeFactory::getWhileStatementNodeFactory() {
  return WhileStatementNodeFactory();
}

ArithmeticExpressionNodeFactory
NodeFactory::getArithmeticExpressionNodeFactory() {
  return ArithmeticExpressionNodeFactory();
}

ConditionalExpressionNodeFactory
NodeFactory::getConditionalExpressionNodeFactory() {
  return ConditionalExpressionNodeFactory();
}

ConstantNodeFactory NodeFactory::getConstantNodeFactory() {
  return ConstantNodeFactory();
}

VariableNodeFactory NodeFactory::getVariableNodeFactory() {
  return VariableNodeFactory();
}

void NodeFactory::initializeFactory() {

}
