//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ExpressionNode.h"

class ConditionalExpressionNode : public ExpressionNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;

public:
  explicit ConditionalExpressionNode(VariableList variableNodes,
                                     ConstantList constantNodes);
  ~ConditionalExpressionNode();

  void accept(const Visitor &extractorVisitor) const override;
};