//
// Created by yeemi on 2/10/2024.
//

#include "ReadStatementNodeFactory.h"
#include "NodeFactory.h"
#include "SP/Tokenizer/TokenType.h"

ReadStatementNodeFactory::ReadStatementNodeFactory() = default;

ReadStatementNodeFactory::~ReadStatementNodeFactory() = default;

ReadStatementNodeFactory::ReadStatement
ReadStatementNodeFactory::createStatementNode(Tokens &tokens) {
  tokens.ensureNextTokenType(TokenTypeSP::READ);

  Variable variableNode = NodeFactory::createVariableNode(tokens);

  tokens.ensureNextTokenType(TokenTypeSP::SEMICOLON);

  return std::make_shared<ReadStatementNode>(NodeFactory::getStatementNumber(),
                                             variableNode);
}
