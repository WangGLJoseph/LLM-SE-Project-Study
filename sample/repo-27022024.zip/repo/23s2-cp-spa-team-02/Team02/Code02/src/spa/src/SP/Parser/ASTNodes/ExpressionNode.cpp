//
// Created by yeemi on 2/10/2024.
//

#include "ExpressionNode.h"

#include <utility>

ExpressionNode::ExpressionNode(VariableList variableNodes,
                               ConstantList constantNodes)
    : _variableNodes(std::move(variableNodes)),
      _constantNodes(std::move(constantNodes)) {}

ExpressionNode::~ExpressionNode() = default;

ExpressionNode::VariableList ExpressionNode::getVariableNodes() const {
  return _variableNodes;
}

ExpressionNode::ConstantList ExpressionNode::getConstantNodes() const {
  return _constantNodes;
}
