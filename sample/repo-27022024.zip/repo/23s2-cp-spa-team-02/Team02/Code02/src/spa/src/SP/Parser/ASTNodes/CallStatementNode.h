//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ProcedureNode.h"
#include "StatementNode.h"

class CallStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::string ProcedureName;
  ProcedureName _procedureName;

public:
  explicit CallStatementNode(int statementNumber, ProcedureName procedureName);
  ~CallStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] ProcedureName getProcedureName() const;
};