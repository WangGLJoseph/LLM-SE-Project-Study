//
// Created by yeemi on 2/10/2024.
//

#include "StatementNodeFactory.h"

StatementNodeFactory::StatementNodeFactory() = default;
StatementNodeFactory::~StatementNodeFactory() = default;
