//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../../PKB/API/PKBManager.h"
#include "AbstractionExtractor/FollowsExtractor.h"
#include "AbstractionExtractor/ModifiesExtractor.h"
#include "AbstractionExtractor/ParentExtractor.h"
#include "AbstractionExtractor/UsesExtractor.h"
#include "EntityExtractor.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"

class DesignExtractorManager {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  PKBManager &_pkbManager;
  ProgramNode _ast;

public:
  explicit DesignExtractorManager(const ProgramNode &AST,
                                  PKBManager &pkbWriteFacade);
  ~DesignExtractorManager();

  void extractData();
  ProgramNode getAST();
  PKBManager &getPKBManager();
};
