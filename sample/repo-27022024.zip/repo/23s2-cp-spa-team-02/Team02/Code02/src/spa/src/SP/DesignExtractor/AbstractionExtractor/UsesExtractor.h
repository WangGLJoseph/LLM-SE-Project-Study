//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../BaseExtractor.h"
#include <vector>

class UsesExtractor : public BaseExtractor,
                      public std::enable_shared_from_this<UsesExtractor> {
private:
  typedef std::vector<int> GrandParentStatementNumber;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;
  GrandParentStatementNumber _grandParents;

public:
  explicit UsesExtractor(PKBManager &pkbManager);
  ~UsesExtractor();

  void visitProcedureNode(const ProcedureNode &procedureNode) override;
  void visitStatementNodeList(const StatementList &statementNodes) override;
  void visitConstantNode(const ConstantNode &constantNode) override;
  void visitVariableNode(const VariableNode &variableNode) override;
  void visitAssignStatementNode(
      const AssignStatementNode &assignStatementNode) override;
  void
  visitCallStatementNode(const CallStatementNode &callStatementNode) override;
  void visitIfStatementNode(const IfStatementNode &ifStatementNode) override;
  void visitPrintStatementNode(
      const PrintStatementNode &printStatementNode) override;
  void
  visitReadStatementNode(const ReadStatementNode &readStatementNode) override;
  void visitWhileStatementNode(
      const WhileStatementNode &whileStatementNode) override;
  void visitArithmeticExpressionNode(
      const ExpressionNode &arithmeticExpressionNode) override;
  void visitConditionalExpressionNode(
      const ExpressionNode &conditionalExpressionNode) override;
  void visitProgramNode(const ProgramNode &programNode) override;
  GrandParentStatementNumber &getGrandParents();
  void extractUses(const ExpressionNode &expressionNode);
  void extractAssignConstantsAndVariables(const ExpressionNode &expressionNode);
  void extractGrandParentUses(const std::string &variableName);
};
