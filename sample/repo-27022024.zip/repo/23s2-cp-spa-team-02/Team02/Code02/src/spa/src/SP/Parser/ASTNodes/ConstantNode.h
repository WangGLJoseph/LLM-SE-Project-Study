//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <string>

class ConstantNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::string ConstantName;
  ConstantName _name;

public:
  explicit ConstantNode(ConstantName name);
  ~ConstantNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] ConstantName getName() const;
};