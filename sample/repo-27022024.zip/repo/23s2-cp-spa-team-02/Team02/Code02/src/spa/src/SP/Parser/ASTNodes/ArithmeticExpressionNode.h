//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ExpressionNode.h"
#include <string>

class ArithmeticExpressionNode : public ExpressionNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::string PostFixExpression;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;
  PostFixExpression _postFixExpression;

public:
  ArithmeticExpressionNode(VariableList variables, ConstantList constants,
                           PostFixExpression postFixExpression);
  ~ArithmeticExpressionNode();

  void accept(const Visitor &extractorVisitor) const override;
  PostFixExpression getPostFixExpression();
};