//
// Created by yeemi on 2/10/2024.
//

#include "ArithmeticExpressionNodeFactory.h"
#include "NodeFactory.h"

ArithmeticExpressionNodeFactory::ArithmeticExpressionNodeFactory() = default;

ArithmeticExpressionNodeFactory::~ArithmeticExpressionNodeFactory() = default;

ArithmeticExpressionNodeFactory::ArithmeticExpression
ArithmeticExpressionNodeFactory::createExpressionNode(Tokens &tokens) {
  int semicolonIndex = tokens.getSemicolonIndex();
  PostFixExpression postFixExpression =
      tokens.getPostFixExpression(tokens.getIndex(), semicolonIndex);
  VariableList variableNodes;
  ConstantList constantNodes;
  while (tokens.getIndex() < semicolonIndex) {
    TokenSP tok = tokens.at(tokens.getIndex());
    if (tok.isVariable()) {
      variableNodes.push_back(NodeFactory::createVariableNode(tokens));
    } else if (tok.isType(TokenTypeSP::INTEGER)) {
      constantNodes.push_back(NodeFactory::createConstantNode(tokens));
    } else {
      tokens.increaseIndex(1);
    }
  }

  tokens.ensureNextTokenType(TokenTypeSP::SEMICOLON);

  return std::make_shared<ArithmeticExpressionNode>(
      variableNodes, constantNodes, postFixExpression);
}
