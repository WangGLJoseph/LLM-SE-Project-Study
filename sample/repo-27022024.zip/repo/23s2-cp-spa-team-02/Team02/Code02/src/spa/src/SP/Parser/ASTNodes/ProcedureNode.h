//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include "StatementNode.h"
#include <string>
#include <vector>

class ProcedureNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
  typedef std::string ProcedureName;
  StatementList _statementNodes;
  ProcedureName _name;

public:
  explicit ProcedureNode(StatementList &statementNodes, ProcedureName name);
  ~ProcedureNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] StatementList getStatementNodes() const;
  [[nodiscard]] ProcedureName getName() const;
};
