//
// Created by yeemi on 2/8/2024.
//

#include "ModifiesExtractor.h"
#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/ReadStatementNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

ModifiesExtractor::ModifiesExtractor(PKBManager &pkbManager)
    : BaseExtractor(pkbManager) {}

ModifiesExtractor::~ModifiesExtractor() = default;

void ModifiesExtractor::visitProcedureNode(const ProcedureNode &procedureNode) {
  // TODO: Milestone 2 Modifies with Procedure
  visitStatementNodeList(procedureNode.getStatementNodes());
}

void ModifiesExtractor::visitStatementNodeList(
    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    getGrandParents().push_back(statementNode->getStatementNumber());
    statementNode->accept(shared_from_this());
    getGrandParents().pop_back();
  }
}

void ModifiesExtractor::visitConstantNode(const ConstantNode &constantNode) {}

void ModifiesExtractor::visitVariableNode(const VariableNode &variableNode) {}

void ModifiesExtractor::visitAssignStatementNode(
    const AssignStatementNode &assignStatementNode) {
  int statementNumber = assignStatementNode.getStatementNumber();
  std::string variableName = assignStatementNode.getVariableName();
  getPKBManager().addModifiesStatement(std::to_string(statementNumber),
                                       variableName);
  extractGrandParentModifies(variableName);
}

void ModifiesExtractor::visitCallStatementNode(
    const CallStatementNode &callStatementNode) {}

void ModifiesExtractor::visitIfStatementNode(
    const IfStatementNode &ifStatementNode) {
  visitStatementNodeList(ifStatementNode.getThenStatementNodes());
  visitStatementNodeList(ifStatementNode.getElseStatementNodes());
}

void ModifiesExtractor::visitPrintStatementNode(
    const PrintStatementNode &printStatementNode) {}

void ModifiesExtractor::visitReadStatementNode(
    const ReadStatementNode &readStatementNode) {
  int statementNumber = readStatementNode.getStatementNumber();
  std::string variableName = readStatementNode.getVariableName();
  getPKBManager().addModifiesStatement(std::to_string(statementNumber),
                                       variableName);
  extractGrandParentModifies(variableName);
}

void ModifiesExtractor::visitWhileStatementNode(
    const WhileStatementNode &whileStatementNode) {
  visitStatementNodeList(whileStatementNode.getStatementNodes());
}

void ModifiesExtractor::visitArithmeticExpressionNode(
    const ExpressionNode &arithmeticExpressionNode) {}

void ModifiesExtractor::visitConditionalExpressionNode(
    const ExpressionNode &conditionalExpressionNode) {}

void ModifiesExtractor::visitProgramNode(const ProgramNode &programNode) {}

ModifiesExtractor::GrandParentStatementNumber &
ModifiesExtractor::getGrandParents() {
  return _grandParents;
}

void ModifiesExtractor::extractGrandParentModifies(
    const std::string &variableName) {
  for (const auto &grandParent : getGrandParents()) {
    getPKBManager().addModifiesStatement(std::to_string(grandParent),
                                         variableName);
  }
}
