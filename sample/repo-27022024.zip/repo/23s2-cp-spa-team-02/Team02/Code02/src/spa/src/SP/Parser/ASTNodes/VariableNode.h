//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <string>

class VariableNode : public Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::string VariableName;
  VariableName _name;

public:
  explicit VariableNode(VariableName name);
  ~VariableNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] VariableName getName() const;
};