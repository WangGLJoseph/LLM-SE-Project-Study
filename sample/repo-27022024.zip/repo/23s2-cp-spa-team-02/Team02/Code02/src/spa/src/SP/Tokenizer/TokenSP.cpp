//
// Created by yeemi on 2/6/2024.
//

#include <utility>

#include "Exceptions/SyntaxErrorException.h"
#include "TokenSP.h"

static const std::unordered_map<TokenTypeSP, std::string> tokenTypeMap = {
    // Keywords
    {TokenTypeSP::PROCEDURE, "PROCEDURE"},
    {TokenTypeSP::WHILE, "WHILE"},
    {TokenTypeSP::READ, "READ"},
    {TokenTypeSP::PRINT, "PRINT"},
    {TokenTypeSP::CALL, "CALL"},
    {TokenTypeSP::IF, "IF"},
    {TokenTypeSP::THEN, "THEN"},
    {TokenTypeSP::ELSE, "ELSE"},

    // Single-character tokens
    {TokenTypeSP::LEFT_PARENTHESIS, "LEFT_PARENTHESIS"},
    {TokenTypeSP::RIGHT_PARENTHESIS, "RIGHT_PARENTHESIS"},
    {TokenTypeSP::LEFT_CURLY_BRACKET, "LEFT_CURLY_BRACKET"},
    {TokenTypeSP::RIGHT_CURLY_BRACKET, "RIGHT_CURLY_BRACKET"},
    {TokenTypeSP::SEMICOLON, "SEMICOLON"},
    {TokenTypeSP::ASSIGN, "EQUALS"},
    {TokenTypeSP::PLUS, "PLUS"},
    {TokenTypeSP::MINUS, "MINUS"},
    {TokenTypeSP::TIMES, "TIMES"},
    {TokenTypeSP::DIVIDE, "DIVIDE"},
    {TokenTypeSP::MODULO, "MODULO"},
    {TokenTypeSP::LESS_THAN, "LESS_THAN"},
    {TokenTypeSP::GREATER_THAN, "GREATER_THAN"},
    {TokenTypeSP::NOT, "NOT"},

    // Double-character tokens
    {TokenTypeSP::LESS_THAN_OR_EQUALS, "LESS_THAN_OR_EQUALS"},
    {TokenTypeSP::GREATER_THAN_OR_EQUALS, "GREATER_THAN_OR_EQUALS"},
    {TokenTypeSP::DOUBLE_EQUALS, "DOUBLE_EQUALS"},
    {TokenTypeSP::NOT_EQUALS, "NOT_EQUALS"},
    {TokenTypeSP::AND, "AND"},
    {TokenTypeSP::OR, "OR"},

    // Other tokens
    {TokenTypeSP::NAME, "NAME"},
    {TokenTypeSP::ERROR, "ERROR"},

};

TokenSP::TokenSP(TokenTypeSP type, std::string value)
    : _value(std::move(value)), _type(type) {}

TokenTypeSP TokenSP::getType() { return _type; }

std::string TokenSP::getValue() { return _value; }

bool TokenSP::equals(TokenSP &other) {
  return (getType() == other.getType()) && (getValue() == other.getValue());
}

std::string TokenSP::getTypeString(TokenTypeSP t) {

  auto itr = tokenTypeMap.find(t);
  if (itr == tokenTypeMap.end()) {
    throw SyntaxErrorException("tokentype not found in map");
  }
  return itr->second;
}

bool TokenSP::isRelationalToken() {
  return getType() == TokenTypeSP::LESS_THAN ||
         getType() == TokenTypeSP::LESS_THAN_OR_EQUALS ||
         getType() == TokenTypeSP::GREATER_THAN ||
         getType() == TokenTypeSP::GREATER_THAN_OR_EQUALS ||
         getType() == TokenTypeSP::DOUBLE_EQUALS ||
         getType() == TokenTypeSP::NOT_EQUALS;
}

bool TokenSP::isType(TokenTypeSP t) { return getType() == t; }

void TokenSP::ensureType(TokenTypeSP t) {
  if (t != _type) {
    throw SyntaxErrorException("expected token " + getTypeString(t) +
                               " but got " + getTypeString(_type));
  }
}

bool TokenSP::isVariable() {
  return getType() == TokenTypeSP::NAME ||
         getType() == TokenTypeSP::PROCEDURE ||
         getType() == TokenTypeSP::READ || getType() == TokenTypeSP::PRINT ||
         getType() == TokenTypeSP::CALL || getType() == TokenTypeSP::IF ||
         getType() == TokenTypeSP::THEN || getType() == TokenTypeSP::ELSE ||
         getType() == TokenTypeSP::WHILE;
}
