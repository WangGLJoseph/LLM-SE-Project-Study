//
// Created by yeemi on 2/10/2024.
//

#include "StatementNode.h"

#include <utility>

StatementNode::StatementNode(int statementNumber, StatementType statementType)
    : _statementNumber(statementNumber), _statementType(statementType) {}

int StatementNode::getStatementNumber() const { return _statementNumber; }
StatementType StatementNode::getStatementType() const { return _statementType; }