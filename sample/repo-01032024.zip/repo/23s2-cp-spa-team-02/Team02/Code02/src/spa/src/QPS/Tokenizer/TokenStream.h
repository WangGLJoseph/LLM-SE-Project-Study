#include "QPS/Tokenizer/QueryTokenizer.h"
#include "QPS/Tokenizer/Token.h"
#include "QPS/Tokenizer/TokenType.h"

class TokenStream {
public:
  [[nodiscard]] const Token& peekToken();
  void consumeToken();
  bool endOfTokens();
  void setTokens(QueryTokens &tokens);
  const std::string &peekTokenValue();
  TokenType peekTokenType();
private:
  QueryTokens tokens_;
  size_t position_ = 0;
};
