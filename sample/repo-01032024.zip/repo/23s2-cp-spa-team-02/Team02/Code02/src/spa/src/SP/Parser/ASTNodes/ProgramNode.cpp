//
// Created by yeemi on 2/10/2024.
//

#include "ProgramNode.h"
#include "ProcedureNode.h"

ProgramNode::ProgramNode(ProcedureList &procedureNodes)
    : _procedureNodes(procedureNodes) {}

ProgramNode::~ProgramNode() = default;

void ProgramNode::accept(const Visitor &extractorVisitor) const {
  for (const Procedure &procedureNode : getProcedureNodes()) {
    procedureNode->accept(extractorVisitor);
  }
}

ProgramNode::ProcedureList ProgramNode::getProcedureNodes() const {
  return _procedureNodes;
}
