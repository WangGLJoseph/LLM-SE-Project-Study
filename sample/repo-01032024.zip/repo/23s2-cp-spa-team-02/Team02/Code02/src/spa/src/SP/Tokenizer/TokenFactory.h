//
// Created by Evan Chng on 6/2/24.
//
#pragma once

#include "TokenSP.h"
#include "TokenType.h"

class TokenFactory {
public:
  TokenFactory();

  ~TokenFactory();

  static TokenSP createToken(TokenTypeSP tokenType, const std::string &value);
};
