//
// Created by yeemi on 2/10/2024.
//

#include "PrintStatementNode.h"

PrintStatementNode::PrintStatementNode(int statementNumber,
                                       Variable variableNode)
    : StatementNode(statementNumber, StatementType::PRINT),
      _variableNode(std::move(variableNode)) {}

PrintStatementNode::~PrintStatementNode() = default;

void PrintStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitPrintStatementNode(*this);
}

PrintStatementNode::Variable PrintStatementNode::getVariableNode() const {
  return _variableNode;
}

std::string PrintStatementNode::getVariableName() const {
  return getVariableNode()->getName();
}
