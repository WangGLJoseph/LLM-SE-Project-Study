//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ReadStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class ReadStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> ReadStatement;
  typedef std::shared_ptr<VariableNode> Variable;

public:
  ReadStatementNodeFactory();
  ~ReadStatementNodeFactory();

  ReadStatement createStatementNode(Tokens &tokens) override;
};