#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "Util/PairHash.h"

// Define hash function for vector of strings
template <>
struct std::hash<std::vector<std::string>>
{
  std::size_t operator()(const std::vector<std::string>& values) const
  {
    // multiplier used to remove commutativity and associativity
    size_t multiplier = 1;

    size_t result = 0;
    for (auto& value: values) {
      result ^= std::hash<std::string>()(value) * multiplier++;
    }

    return result;
  }
};

using Table = std::unordered_map<std::string, std::vector<std::string>>;
using ResultSet = std::unordered_set<std::vector<std::string>>;

class Result {

public:

    explicit Result(std::initializer_list<std::string> synonyms);
    explicit Result(const Table& table) : table_(table) {};
    Result(bool validFlag) : validFlag_(validFlag) {};
    Result(const std::string& synonym, const std::unordered_set<std::string> &vals);
    Result(const std::string& syn1, const std::string& syn2,
        std::unordered_set<std::pair<std::string, std::string>, PairHash> vals);
    Result(const std::string& syn1, const std::string& syn2, const std::string& syn3, const std::unordered_set<std::tuple<std::string, std::string, std::string>> &vals);

    std::unordered_set<std::string> getSynonym(const std::string& synonym);
    void populateSynonym(const std::string& synonym, const std::vector<std::string>& values);

    // Returns true if this Result does not contain any synonyms
    bool isEmpty() const;

    // Returns true if possible to still get results
    bool isPossible() const;

    size_t size() const;

    // Returns true if table contains synonym
    bool contains(const std::string& synonym);

    Result combineWith(Result& other);

    ResultSet retrieveValues(const std::vector<std::string>& selectedTuple);

private:
    bool validFlag_ = true;
    Table table_;
};