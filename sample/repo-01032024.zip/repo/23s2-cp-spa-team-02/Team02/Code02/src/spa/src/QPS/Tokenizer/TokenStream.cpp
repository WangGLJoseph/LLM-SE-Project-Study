#include "TokenStream.h"

void TokenStream::setTokens(QueryTokens &tokens) {
  tokens_ = tokens;
  position_ = 0;
}

const Token& TokenStream::peekToken() {
  return tokens_[position_];
}

const std::string& TokenStream::peekTokenValue() {
  return tokens_[position_].getValue();
}

TokenType TokenStream::peekTokenType() {
  if (position_ >= tokens_.size()) {
    throw SyntaxErrorException("No more tokens");
  }
  return tokens_[position_].getType();
}

void TokenStream::consumeToken() {
  position_++;
}

bool TokenStream::endOfTokens() {
  return (position_ >= tokens_.size());
}
