#pragma once

#include "PQLGrammar.h"
#include <string>
#include <unordered_map>
#include <vector>

typedef std::unordered_map<std::string, EntityType> SynonymMap;
typedef std::pair<std::string, EntityType> ClauseArgument;

class Clause {
  // Common stuff between StClause and PatternClause belong here

protected:
  std::vector<ClauseArgument> args_;
};

class StClause : public Clause {
public:
  explicit StClause(RelRef rel,
                    const std::pair<ClauseArgument, ClauseArgument> &args)
      : rel_(rel) {
    args_.emplace_back(args.first);
    args_.emplace_back(args.second);
  };
  virtual ~StClause() = default;

  [[nodiscard]] RelRef getRelationship() const { return rel_; }
  [[nodiscard]] const ClauseArgument &getArg1() const { return args_[0]; }
  [[nodiscard]] const ClauseArgument &getArg2() const { return args_[1]; }

private:
  RelRef rel_;
};

class PatternClause : public Clause {
public:
  explicit PatternClause(std::string patternSyn, EntityType patternEnt,
                         const std::pair<ClauseArgument, ClauseArgument> &args)
      : assignSyn_(patternSyn), patternEnt_(patternEnt) {
    args_.emplace_back(args.first);
    args_.emplace_back(args.second);
  };
  virtual ~PatternClause() = default;

  [[nodiscard]] const std::string &getPatternSyn() const { return assignSyn_; }
  [[nodiscard]] EntityType getRelationship() const { return patternEnt_; }
  [[nodiscard]] const ClauseArgument &getArg1() const { return args_[0]; }
  [[nodiscard]] const ClauseArgument &getArg2() const { return args_[1]; }

private:
  std::string assignSyn_;
  EntityType patternEnt_;
};

class Query {
public:
  Query(std::string &selectedSynonym, SynonymMap &synonymMap,
        std::vector<StClause> &stClauses,
        std::vector<PatternClause> &patternClauses);
  ~Query() = default;
  SynonymMap synonymMap_;

  // TODO replace selectedSynonym to support tuple and boolean
  std::string selectedSynonym_;
  std::vector<StClause> stClauses_;
  std::vector<PatternClause> patternClauses_;

  [[nodiscard]] bool hasClauses() const {
    return hasStClauses() || hasPatternClauses();
  };
  [[nodiscard]] bool hasStClauses() const { return !stClauses_.empty(); };
  [[nodiscard]] bool hasPatternClauses() const {
    return !patternClauses_.empty();
  };
};
