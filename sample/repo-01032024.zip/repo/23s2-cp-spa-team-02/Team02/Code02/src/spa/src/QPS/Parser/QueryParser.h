#pragma once
#include "QPS/PQLGrammar.h"
#include "QPS/Query.h"
#include "QPS/Tokenizer/QueryTokenizer.h"
#include "QPS/Tokenizer/TokenStream.h"
#include "QPS/Validator/SemanticValidator.h"
#include "QPS/Validator/SyntaxValidator.h"
#include <unordered_map>
#include <regex>

class QueryParser {
private:
  SyntaxValidator syntaxValidator_;
  SemanticValidator semanticValidator_;

  // Need to keep synonymMap for semantic validation of args and select
  SynonymMap synonymMap_;
  void clearSynonymMap();

  TokenStream tokenStream_;
  const Token& getExpectedToken(TokenType expectedTokenType);

  void parseDeclarations();
  void parseSynonymDec(EntityType &decEntityType);
  std::string parseSelectClause();
  std::pair<std::vector<StClause>, std::vector<PatternClause>> parseClauses();

  StClause parseSuchThatClause();
  RelRef parseRelRef();
  std::pair<ClauseArgument, ClauseArgument> parseRelArgs(RelRef relRefType);
  ClauseArgument parseRefArg();
  ClauseArgument parseSynonymArg();
  ClauseArgument parseWildcardArg();
  ClauseArgument parseIntArg();
  ClauseArgument parseQuotedIdent();

  PatternClause parsePatternClause();
  std::pair<ClauseArgument, ClauseArgument> parsePatternArgs();
  ClauseArgument parseExprSpecArg();
  std::string parseQuotedExpr();

  // For syntax checking of arg token types
  void checkNextRefType(TokenType expectedRefType);
  void checkFirstArgRefType(RelRef relRefType);
  void checkSecondArgRefType(RelRef relRefType);
public:
  Query parseQuery(const std::string &query);
};
