//
// Created by yeemi on 2/10/2024.
//

#include "CallStatementNodeFactory.h"
#include "NodeFactory.h"

CallStatementNodeFactory::CallStatementNodeFactory() = default;

CallStatementNodeFactory::~CallStatementNodeFactory() = default;

CallStatementNodeFactory::CallStatement
CallStatementNodeFactory::createStatementNode(Tokens &tokens) {
  tokens.ensureNextTokenType(TokenTypeSP::CALL);

  std::string procedureName = tokens.getNextToken().getValue();

  tokens.ensureNextTokenType(TokenTypeSP::SEMICOLON);
  return std::make_shared<CallStatementNode>(NodeFactory::getStatementNumber(),
                                             procedureName);
}
