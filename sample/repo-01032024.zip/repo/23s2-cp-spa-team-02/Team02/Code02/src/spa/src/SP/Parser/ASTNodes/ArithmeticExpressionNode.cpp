//
// Created by yeemi on 2/10/2024.
//

#include "ArithmeticExpressionNode.h"

#include <utility>

ArithmeticExpressionNode::ArithmeticExpressionNode(
    VariableList variables, ConstantList constants,
    PostFixExpression postFixExpression)
    : ExpressionNode(std::move(variables), std::move(constants)),
      _postFixExpression(std::move(postFixExpression)) {}

ArithmeticExpressionNode::~ArithmeticExpressionNode() = default;

void ArithmeticExpressionNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitArithmeticExpressionNode(*this);
}
ArithmeticExpressionNode::PostFixExpression
ArithmeticExpressionNode::getPostFixExpression() {
  return _postFixExpression;
}
