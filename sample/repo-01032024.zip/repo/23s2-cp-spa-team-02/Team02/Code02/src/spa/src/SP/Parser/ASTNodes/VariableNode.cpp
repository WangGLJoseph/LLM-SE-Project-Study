//
// Created by yeemi on 2/10/2024.
//

#include "VariableNode.h"

VariableNode::VariableNode(VariableName name) : _name(std::move(name)) {}

VariableNode::~VariableNode() = default;

void VariableNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitVariableNode(*this);
}

VariableNode::VariableName VariableNode::getName() const { return _name; }
