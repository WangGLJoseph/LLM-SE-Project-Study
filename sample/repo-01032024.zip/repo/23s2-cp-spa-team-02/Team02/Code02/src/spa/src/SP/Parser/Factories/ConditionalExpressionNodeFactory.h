//
// Created by yeemi on 2/12/2024.
//
#pragma once

#include "../ASTNodes/ConditionalExpressionNode.h"
#include "ExpressionNodeFactory.h"

class ConditionalExpressionNodeFactory : public ExpressionNodeFactory {
private:
  typedef std::shared_ptr<ExpressionNode> ConditionalExpression;
  typedef std::vector<std::shared_ptr<VariableNode>> VariableList;
  typedef std::vector<std::shared_ptr<ConstantNode>> ConstantList;

public:
  ConditionalExpressionNodeFactory();

  ~ConditionalExpressionNodeFactory();

  ConditionalExpression createExpressionNode(Tokens &tokens) override;

  static void validateConditionalExpr(Tokens &tokens, int start, int end);
};
