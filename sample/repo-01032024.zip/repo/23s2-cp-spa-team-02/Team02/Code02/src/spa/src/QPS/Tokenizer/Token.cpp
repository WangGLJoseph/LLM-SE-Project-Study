#include "Token.h"

#include <utility>

Token::Token(std::string value, const TokenType &type)
    : value(std::move(value)), type(type) {}

const std::string &Token::getValue() const { return value; }

const TokenType &Token::getType() const { return type; }
