//
// Created by yeemi on 2/10/2024.
//

#include "WhileStatementNode.h"

#include <utility>

WhileStatementNode::WhileStatementNode(
    int statementNumber, ConditionalExpression conditionalExpressionNode,
    StatementList statementNodes)
    : StatementNode(statementNumber, StatementType::WHILE),
      _conditionalExpressionNode(std::move(conditionalExpressionNode)),
      _statementNodes(std::move(statementNodes)) {}

WhileStatementNode::~WhileStatementNode() = default;

void WhileStatementNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitWhileStatementNode(*this);
}

WhileStatementNode::ConditionalExpression
WhileStatementNode::getConditionalExpressionNode() const {
  return _conditionalExpressionNode;
}

WhileStatementNode::StatementList
WhileStatementNode::getStatementNodes() const {
  return _statementNodes;
}
