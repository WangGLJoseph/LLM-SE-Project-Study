#include "ModifiesFunction.h"

Result ModifiesFunction::operator()(const StClause &clause, PKBManager &pkb) {

  const ClauseArgument& arg1 = clause.getArg1();

  if (arg1.second == EntityType::STMT_NUM) {

    return constantArg1(arg1.first, clause.getArg2(), pkb);

  } else if (entityToStatementType(arg1.second) != StatementType::UNKNOWN) {

    return statementArg1(arg1, clause.getArg2(), pkb);

  } else {

    // procedure name, not needed for MS1
    return Result(false);

  }
}

Result ModifiesFunction::constantArg1(const std::string &arg1Str, const ClauseArgument &arg2, PKBManager &pkb) {

  if (arg2.second == EntityType::WILDCARD) {

    return Result(pkb.doesUnderscoreGetModified(arg1Str));

  } else if (arg2.second == EntityType::NAME) {

    return Result(pkb.doesModifiesPairExist(arg1Str, arg2.first));

  } else {

    return Result(arg2.first, pkb.getVariableModified(arg1Str));

  }
}

Result ModifiesFunction::statementArg1(const ClauseArgument& arg1, const ClauseArgument& arg2, PKBManager& pkb) {

  StatementType arg1StmtType = entityToStatementType(arg1.second);

  if (arg2.second == EntityType::WILDCARD) {

    return Result(arg1.first, pkb.getStatementModifiesType(arg1StmtType));

  } else if (arg2.second == EntityType::NAME) {

    return Result(arg1.first, pkb.getStatementsModifies(arg1StmtType, arg2.first));

  } else {

    // Variable
    return Result(arg1.first, arg2.first, pkb.getAllModifiesPairsWithType(arg1StmtType));

  }
}