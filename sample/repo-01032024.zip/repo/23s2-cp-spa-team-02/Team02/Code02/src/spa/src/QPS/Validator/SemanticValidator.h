#pragma once
#include "QPS/Query.h"
#include "QPS/PQLGrammar.h"
#include "Exceptions/SemanticErrorException.h"

class SemanticValidator {
public:
  void validateQuery(Query &queryRep);
  void validateDupDeclarations();
  void validateSelectClause(const std::string &synonym,
                                   const SynonymMap &synonymMap);
  void validateStClause(const StClause &clause);
  void validatePatternClause(const PatternClause &clause,
                                    const SynonymMap &synonymMap);
  void validateSynonymDeclared(const std::string &synonym,
                                      const SynonymMap &synonymMap);
  void validateSynonymNotDeclared(const std::string &synonym,
                                         const SynonymMap &synonymMap);

  void reset();
private:
  bool hasDuplicateSynonymDec = false;
};