//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Tokenizer/TokenSP.h"
#include "SP/Tokenizer/Tokens.h"
#include "StatementNodeFactory.h"

class ProcedureNodeFactory {
private:
  typedef std::string ProcedureName;
  typedef std::shared_ptr<ProcedureNode> Procedure;
  typedef std::shared_ptr<StatementNode> Statement;
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;

public:
  ProcedureNodeFactory();
  ~ProcedureNodeFactory();

  Procedure createProcedureNode(Tokens &tokens);
};
