//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ArithmeticExpressionNode.h"
#include "StatementNode.h"
#include "VariableNode.h"
#include <vector>

class AssignStatementNode : public StatementNode {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;
  typedef std::shared_ptr<VariableNode> Variable;
  typedef std::shared_ptr<ExpressionNode> ArithmeticExpression;
  Variable _variableNode;
  ArithmeticExpression _arithmeticExpressionNode;

public:
  explicit AssignStatementNode(int statementNumber, Variable variableNode,
                               ArithmeticExpression arithmeticExpressionNode);
  ~AssignStatementNode();

  void accept(const Visitor &extractorVisitor) const override;
  [[nodiscard]] Variable getVariableNode() const;
  [[nodiscard]] ArithmeticExpression getArithmeticExpressionNode() const;
  [[nodiscard]] std::string getVariableName() const;
};