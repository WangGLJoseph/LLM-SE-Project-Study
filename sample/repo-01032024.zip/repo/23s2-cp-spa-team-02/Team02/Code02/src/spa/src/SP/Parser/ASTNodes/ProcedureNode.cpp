//
// Created by yeemi on 2/10/2024.
//

#include "ProcedureNode.h"

#include <utility>

ProcedureNode::ProcedureNode(StatementList &statementNodes, ProcedureName name)
    : _statementNodes(statementNodes), _name(std::move(name)) {}

ProcedureNode::~ProcedureNode() = default;

void ProcedureNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitProcedureNode(*this);
}

ProcedureNode::StatementList ProcedureNode::getStatementNodes() const {
  return _statementNodes;
}

ProcedureNode::ProcedureName ProcedureNode::getName() const { return _name; }
