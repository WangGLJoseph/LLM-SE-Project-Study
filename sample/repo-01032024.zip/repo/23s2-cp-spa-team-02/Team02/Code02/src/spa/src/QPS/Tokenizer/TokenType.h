#pragma once
#include <string>
#include <unordered_map>

enum class TokenType {
  // Used for tokenization
  IDENT, // ALPHANUMERIC
  SEMICOLON,
  COMMA,
  UNDERSCORE, // used for both wildcard and partial match
  INTEGER,
  QUOTED_EXPR,
  UNKNOWN,
  PAREN_OPEN,
  PAREN_CLOSE,
  SUCH_THAT,
  STAR,
  // Used for parsing only, cannot be matched without context
  DECLARATION_ENTITY,
  RELREF,
  SYNONYM,
  SELECT,
  PATTERN,
  QUOTED_IDENT,
  SPACE,
  STMT_REF,
  ENT_REF,
  BOTH_REF
};
