#include "SemanticValidator.h"

void SemanticValidator::validateQuery(Query &query) {
  validateDupDeclarations();
  validateSelectClause(query.selectedSynonym_, query.synonymMap_);
  for (const auto &stClause : query.stClauses_) {
    validateStClause(stClause);
  }
  for (const auto &patternClause : query.patternClauses_) {
    validatePatternClause(patternClause, query.synonymMap_);
  }
}

void SemanticValidator::validateDupDeclarations() {
  // Check no duplicate declarations
  if (hasDuplicateSynonymDec) {
    throw SemanticErrorException("Synonym name can only be declared once");
  }
}

void SemanticValidator::validateSelectClause(const std::string &synonym,
                                             const SynonymMap &synonymMap) {
  SemanticValidator::validateSynonymDeclared(synonym, synonymMap);
}

void SemanticValidator::validateStClause(const StClause &clause) {
  // Check if any undeclared synonyms
  if (clause.getArg1().second == EntityType::UNDECLARED || clause.getArg2().second == EntityType::UNDECLARED) {
    throw SemanticErrorException("Undeclared synonyms in clause args");
  }
  // Check valid argument types
  std::pair<std::unordered_set<EntityType>, std::unordered_set<EntityType>>
      validArgs = validStArgEntTypes.at(clause.getRelationship());
  if (!validArgs.first.count(clause.getArg1().second) ||
        !validArgs.second.count(clause.getArg2().second)) {
    throw SemanticErrorException("Invalid such-that clause argument types, " + entityTypeToString.at(clause.getArg1().second) + " " + entityTypeToString.at(clause.getArg2().second));
  }
}

void SemanticValidator::validatePatternClause(const PatternClause &clause, const SynonymMap &synonymMap) {
  // Check pattern synonym is valid
  // Check if declared
  SemanticValidator::validateSynonymDeclared(clause.getPatternSyn(), synonymMap);
  // Check if valid type
  if (!validPatternTypes.count(synonymMap.at(clause.getPatternSyn()))) {
    throw SemanticErrorException("`" + clause.getPatternSyn() +
                                 "` is not a valid pattern synonym");
  }
  // Check first arg
  if (clause.getArg1().second == EntityType::UNDECLARED) {
    throw SemanticErrorException("Undeclared synonyms in clause args");
  }
  if (!validPatternFirstArgTypes.count(clause.getArg1().second)) {
   throw SemanticErrorException("Invalid pattern clause argument types") ;
  }

}

void SemanticValidator::validateSynonymDeclared(const std::string &synonym,
                                                const SynonymMap &synonymMap) {
  if (!synonymMap.count(synonym)) {
    throw SemanticErrorException("Synonym `" + synonym + "` not declared");
  }
}

// Checked during parsing
void SemanticValidator::validateSynonymNotDeclared(
    const std::string &synonym, const SynonymMap &synonymMap) {
  if (synonymMap.count(synonym)) {
    hasDuplicateSynonymDec = true;
  }
}

void SemanticValidator::reset() {
  hasDuplicateSynonymDec = false;
}