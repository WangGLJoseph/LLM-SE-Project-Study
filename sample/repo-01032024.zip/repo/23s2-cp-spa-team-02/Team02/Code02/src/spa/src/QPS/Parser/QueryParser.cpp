#include "QueryParser.h"

void QueryParser::clearSynonymMap() { synonymMap_ = {}; }

const Token& QueryParser::getExpectedToken(TokenType expectedTokenType) {
  if (tokenStream_.endOfTokens()) {
    throw SyntaxErrorException("No more tokens");
  }
  const Token& token = tokenStream_.peekToken();
  syntaxValidator_.validateToken(token, expectedTokenType);
  tokenStream_.consumeToken();
  return token;
}

void QueryParser::checkNextRefType(TokenType expectedRefType) {
  // Syntax check on whether next Token can be stmtRef or entRef without consuming
  if (tokenStream_.endOfTokens()) {
    throw SyntaxErrorException("No more tokens");
  }
  const Token& token = tokenStream_.peekToken();
  syntaxValidator_.validateToken(token, expectedRefType);
}

Query QueryParser::parseQuery(const std::string &query) {
  // Parse sequentially using recursive descent
  std::vector<Token> tokens = QueryTokenizer::tokenize(query);
  tokenStream_.setTokens(tokens);
  clearSynonymMap();
  semanticValidator_.reset();

  // Declarations
  parseDeclarations();
  // Select TODO MS2: handle tuples and boolean, attributes
  std::string selectedSynonym = parseSelectClause();
  // Clauses
  std::pair<std::vector<StClause>, std::vector<PatternClause>> clauses =
      parseClauses();
  Query queryRep(selectedSynonym, synonymMap_, clauses.first, clauses.second);
  // Semantic validation
  semanticValidator_.validateQuery(queryRep);
  return queryRep;
}

void QueryParser::parseSynonymDec(EntityType &decEntityType) {
  // Add to synonymMap
  Token synonymToken = getExpectedToken(TokenType::SYNONYM);
  // Check duplicate synonyms but don't throw semantic error yet
  semanticValidator_.validateSynonymNotDeclared(synonymToken.getValue(), synonymMap_);
  synonymMap_[synonymToken.getValue()] = decEntityType;
}

void QueryParser::parseDeclarations() {
  while (!tokenStream_.endOfTokens() && tokenStream_.peekTokenValue() != pql_constants::selectCl) {
    Token entityToken = getExpectedToken(TokenType::DECLARATION_ENTITY);
    EntityType decEntityType = tokenValToDecEntity.at(entityToken.getValue());
    parseSynonymDec(decEntityType);
    // Check for commas
    while (!tokenStream_.endOfTokens() && tokenStream_.peekTokenType() != TokenType::SEMICOLON) {
      getExpectedToken(TokenType::COMMA);
      parseSynonymDec(decEntityType);
    }
    getExpectedToken(TokenType::SEMICOLON);
  }
}

std::string QueryParser::parseSelectClause() {
  // TODO MS2: handle tuples and boolean, attributes
  getExpectedToken(TokenType::SELECT);
  Token selectedToken = getExpectedToken(TokenType::SYNONYM);
  return selectedToken.getValue();
}

std::pair<std::vector<StClause>, std::vector<PatternClause>>
QueryParser::parseClauses() {
  std::vector<StClause> stClauses{};
  std::vector<PatternClause> patternClauses{};

  while (!tokenStream_.endOfTokens()) {
    // TODO MS2: handle 'and', 'with'
    if (tokenStream_.peekTokenType() == TokenType::SUCH_THAT) {
      StClause stClause = parseSuchThatClause();
      stClauses.emplace_back(stClause);
    } else if (tokenStream_.peekTokenValue() == pql_constants::patternCl) {
      PatternClause patternClause = parsePatternClause();
      patternClauses.emplace_back(patternClause);
    } else {
      throw SyntaxErrorException("Unknown clause `" + tokenStream_.peekTokenValue() +
                                 "`");
    }
  }
  return {stClauses, patternClauses};
}

StClause QueryParser::parseSuchThatClause() {
  getExpectedToken(TokenType::SUCH_THAT);
  RelRef relRefType = parseRelRef();
  std::pair<ClauseArgument, ClauseArgument> clauseArgs = parseRelArgs(relRefType);
  return StClause(relRefType, clauseArgs);
}

RelRef QueryParser::parseRelRef() {
  Token relRefToken = getExpectedToken(TokenType::RELREF);
  // Check if star, used to get specific RelRef for Follows, Parent
  // Uses and Modifies only differs by arg types, should not be followed by star
  std::string relRefString = relRefToken.getValue();
  if (tokenStream_.peekTokenType() == TokenType::STAR) {
    if (!pql_constants::relRefStarSet.count(relRefToken.getValue() +
                                            tokenStream_.peekTokenValue())) {
      throw SyntaxErrorException("Given relRef `" + relRefToken.getValue() +
                                 "` does not have transitive closure");
    }
    relRefString += tokenStream_.peekTokenValue();
    getExpectedToken(TokenType::STAR);
  }
  RelRef relRefType = tokenValToRelRef.at(relRefString);
  return relRefType;
}

std::pair<ClauseArgument, ClauseArgument> QueryParser::parseRelArgs(RelRef relRefType) {
  // Parse suchthat-cl args, check for syntax error based on TokenType
  // Uses and Modifies expect bothRef as first arg, entRef as second
  // All relationships only expect stmtRef for both args
  getExpectedToken(TokenType::PAREN_OPEN);
  // Check ref type of arg tokens without consuming
  checkFirstArgRefType(relRefType);
  ClauseArgument arg1 = parseRefArg();
  getExpectedToken(TokenType::COMMA);
  checkSecondArgRefType(relRefType);
  ClauseArgument arg2 = parseRefArg();
  getExpectedToken(TokenType::PAREN_CLOSE);
  return {arg1, arg2};
}

void QueryParser::checkFirstArgRefType(RelRef relRefType) {
  if (relRefType == RelRef::MODIFIES || relRefType == RelRef::USES) {
    checkNextRefType(TokenType::BOTH_REF);
  } else {
    checkNextRefType(TokenType::STMT_REF);
  }
}

void QueryParser::checkSecondArgRefType(RelRef relRefType) {
  if (relRefType == RelRef::MODIFIES || relRefType == RelRef::USES) {
    checkNextRefType(TokenType::ENT_REF);
  } else {
    checkNextRefType(TokenType::STMT_REF);
  }
}

ClauseArgument QueryParser::parseRefArg() {
  // Both entRef and stmtRef
  // 4 types: synonyms, wildcard, integers, quoted ident
  ClauseArgument arg;
  // Checked syntax error based on TokenType before parsing
  // Check specific type of arg and further parse
  if (tokenStream_.peekTokenType() == TokenType::IDENT) {
    // Can only be synonym
    arg = parseSynonymArg();
  } else if (tokenStream_.peekTokenType() == TokenType::UNDERSCORE) {
    arg = parseWildcardArg();
  } else if (tokenStream_.peekTokenType() == TokenType::INTEGER) {
    arg = parseIntArg();
  } else { // Quoted IDENT
    arg = parseQuotedIdent();
  }
  return arg;
}

ClauseArgument QueryParser::parseSynonymArg() {
  Token synonymToken = getExpectedToken(TokenType::SYNONYM);
  // If synonym is undeclared during syntax checking, don't throw semantic error
  // During semantic checking, UNDECLARED type arg will throw semantic error
  if (!synonymMap_.count(synonymToken.getValue())) {
    return {synonymToken.getValue(), EntityType::UNDECLARED};
  }
  return {synonymToken.getValue(), synonymMap_.at(synonymToken.getValue())};
}

ClauseArgument QueryParser::parseWildcardArg() {
  Token wildcardToken = getExpectedToken(TokenType::UNDERSCORE);
  return {wildcardToken.getValue(), EntityType::WILDCARD};
}

ClauseArgument QueryParser::parseIntArg() {
  Token intToken = getExpectedToken(TokenType::INTEGER);
  return {intToken.getValue(), EntityType::STMT_NUM};
}

ClauseArgument QueryParser::parseQuotedIdent() {
  // Only names should be inside quote
  // Diff from quoted expression for pattern-cl
  Token quotedIdentToken = getExpectedToken(TokenType::QUOTED_IDENT);
  // Type should only be variable name or procedure name (cant distinguish)
  return {quotedIdentToken.getValue(), EntityType::NAME};
}

PatternClause QueryParser::parsePatternClause() {
  getExpectedToken(TokenType::PATTERN);
  ClauseArgument synonymArg = parseSynonymArg();
  // Similar args syntax to RefArg but different semantics
  std::pair<ClauseArgument, ClauseArgument> args = parsePatternArgs();
  return PatternClause(synonymArg.first, synonymArg.second, args);
}

// TODO MS2: 3 args for if
std::pair<ClauseArgument, ClauseArgument> QueryParser::parsePatternArgs() {
  getExpectedToken(TokenType::PAREN_OPEN);
  // arg1 is entRef: synonym, wildcard, quoted ident
  checkNextRefType(TokenType::ENT_REF);
  ClauseArgument arg1 = parseRefArg();
  getExpectedToken(TokenType::COMMA);
  // arg2 is "expression-spec": wildcard, quoted expression (exact and partial
  // match)
  ClauseArgument arg2 = parseExprSpecArg();
  getExpectedToken(TokenType::PAREN_CLOSE);
  return {arg1, arg2};
}

ClauseArgument QueryParser::parseExprSpecArg() {
  /* Check if wildcard, exact or partial match
   * For MS1, assume constant or variable partial matching only (QUOTED_IDENT)
   * TODO MS2: further parse and handle expression-spec with terms and operators
   */
  if (tokenStream_.peekTokenType() == TokenType::UNDERSCORE) {
    Token wildcardToken = getExpectedToken(TokenType::UNDERSCORE);
    if (tokenStream_.peekTokenType() == TokenType::QUOTED_EXPR) {
      // Partial match
      std::string exprSpecArg = parseQuotedExpr();
      getExpectedToken(TokenType::UNDERSCORE);
      return {exprSpecArg, EntityType::PARTIAL_MATCH};
    } else {
      // Wildcard
      return {wildcardToken.getValue(), EntityType::WILDCARD};
    }
  } else {
    // Exact match or invalid type
    std::string exprSpecArg = parseQuotedExpr();
    return {exprSpecArg, EntityType::EXACT_MATCH};
  }
}

std::string QueryParser::parseQuotedExpr() {
  // TODO MS2: convert to postfix for PKB
  Token exprSpecToken = getExpectedToken(TokenType::QUOTED_EXPR);
  return StringUtils::removeWhitespaces(exprSpecToken.getValue());
}
