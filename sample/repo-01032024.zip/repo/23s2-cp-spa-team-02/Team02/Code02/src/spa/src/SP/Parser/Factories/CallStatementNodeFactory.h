//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/CallStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class CallStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> CallStatement;

public:
  CallStatementNodeFactory();
  ~CallStatementNodeFactory();

  CallStatement createStatementNode(Tokens &tokens) override;
};
