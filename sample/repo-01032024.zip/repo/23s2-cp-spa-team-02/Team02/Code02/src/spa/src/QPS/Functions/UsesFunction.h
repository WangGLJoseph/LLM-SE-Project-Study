#pragma once

#include "PKB/API/PKBManager.h"
#include "QPS/Result.h"
#include "QPS/PQLGrammar.h"
#include "QPS/Query.h"

class UsesFunction {

public:
  static constexpr RelRef rel = RelRef::USES;

  Result operator()(const StClause& clause, PKBManager& pkb);

private:
  static Result constantArg1(const std::string& arg1Str, const ClauseArgument& arg2, PKBManager& pkb);

  static Result statementArg1(const ClauseArgument& arg1, const ClauseArgument& arg2, PKBManager& pkb);
};

