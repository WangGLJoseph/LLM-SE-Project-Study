//
// Created by yeemi on 2/8/2024.
//

#include "ParentExtractor.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

ParentExtractor::ParentExtractor(PKBManager &pkbManager)
    : BaseExtractor(pkbManager) {}

ParentExtractor::~ParentExtractor() = default;

void ParentExtractor::visitProcedureNode(const ProcedureNode &procedureNode) {
  visitStatementNodeList(procedureNode.getStatementNodes());
}

void ParentExtractor::visitStatementNodeList(
    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    getGrandParents().push_back(statementNode->getStatementNumber());
    statementNode->accept(shared_from_this());
    getGrandParents().pop_back();
  }
}

void ParentExtractor::visitConstantNode(const ConstantNode &constantNode) {}

void ParentExtractor::visitVariableNode(const VariableNode &variableNode) {}

void ParentExtractor::visitAssignStatementNode(
    const AssignStatementNode &assignStatementNode) {}

void ParentExtractor::visitCallStatementNode(
    const CallStatementNode &callStatementNode) {}

void ParentExtractor::visitIfStatementNode(
    const IfStatementNode &ifStatementNode) {
  extractParent(ifStatementNode.getStatementNumber(),
                ifStatementNode.getThenStatementNodes());
  extractParent(ifStatementNode.getStatementNumber(),
                ifStatementNode.getElseStatementNodes());
  visitStatementNodeList(ifStatementNode.getThenStatementNodes());
  visitStatementNodeList(ifStatementNode.getElseStatementNodes());
}

void ParentExtractor::visitPrintStatementNode(
    const PrintStatementNode &printStatementNode) {}

void ParentExtractor::visitReadStatementNode(
    const ReadStatementNode &readStatementNode) {}

void ParentExtractor::visitWhileStatementNode(
    const WhileStatementNode &whileStatementNode) {
  extractParent(whileStatementNode.getStatementNumber(),
                whileStatementNode.getStatementNodes());
  visitStatementNodeList(whileStatementNode.getStatementNodes());
}

void ParentExtractor::visitArithmeticExpressionNode(
    const ExpressionNode &arithmeticExpressionNode) {}

void ParentExtractor::visitConditionalExpressionNode(
    const ExpressionNode &conditionalExpressionNode) {}

void ParentExtractor::visitProgramNode(const ProgramNode &programNode) {}

void ParentExtractor::extractParent(int parentStatementNumber,
                                    const StatementList &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    std::string childStatementNumber =
        std::to_string(statementNode->getStatementNumber());
    getPKBManager().addParent(std::to_string(parentStatementNumber),
                              childStatementNumber);
    for (const auto &grandparent : getGrandParents()) {
      getPKBManager().addParentStar(std::to_string(grandparent),
                                    childStatementNumber);
    }
  }
}

ParentExtractor::GrandParentStatementNumber &
ParentExtractor::getGrandParents() {
  return _grandParents;
}
