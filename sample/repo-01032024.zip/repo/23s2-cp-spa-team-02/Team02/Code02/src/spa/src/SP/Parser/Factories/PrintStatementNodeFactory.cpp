//
// Created by yeemi on 2/10/2024.
//

#include "PrintStatementNodeFactory.h"
#include "NodeFactory.h"

PrintStatementNodeFactory::PrintStatementNodeFactory() = default;

PrintStatementNodeFactory::~PrintStatementNodeFactory() = default;

PrintStatementNodeFactory::PrintStatement
PrintStatementNodeFactory::createStatementNode(Tokens &tokens) {
  tokens.ensureNextTokenType(TokenTypeSP::PRINT);

  Variable variableNode = NodeFactory::createVariableNode(tokens);

  tokens.ensureNextTokenType(TokenTypeSP::SEMICOLON);
  return std::make_shared<PrintStatementNode>(NodeFactory::getStatementNumber(),
                                              variableNode);
}
