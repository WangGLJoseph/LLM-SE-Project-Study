#include "SyntaxValidator.h"
void SyntaxValidator::validateToken(const Token &token,
                                    TokenType expectedTokenType) {
  switch (expectedTokenType) {
  case TokenType::DECLARATION_ENTITY:
    if (!isValidDeclarationEntity(token)) {
      throw SyntaxErrorException("Invalid declaration entity `" +
                                 token.getValue() + "`");
    }
    break;
  case TokenType::SYNONYM:
    if (token.getType() != TokenType::IDENT) {
      throw SyntaxErrorException("Invalid synonym '" + token.getValue() + "`");
    }
    break;
  case TokenType::SELECT:
    if (token.getValue() != pql_constants::selectCl) {
      throw SyntaxErrorException("Missing `" + pql_constants::selectCl + "`");
    }
    break;
  case TokenType::RELREF:
    if (!pql_constants::relRefSet.count(token.getValue())) {
      throw SyntaxErrorException("Invalid relation reference `" +
                                 token.getValue() + "`");
    }
    break;
  case TokenType::QUOTED_IDENT:
    if (!isValidIdent(token.getValue())) {
      throw SyntaxErrorException("Invalid ident `" + token.getValue() + "`");
    }
    break;
  case TokenType::PATTERN:
    if (token.getValue() != pql_constants::patternCl) {
      throw SyntaxErrorException("Missing `" + pql_constants::patternCl + "`");
    }
    break;
  case TokenType::QUOTED_EXPR:
    // Can have whitespaces inside, strip
    if (token.getType() != expectedTokenType ||
        !isValidExprSpec(token.getValue())) {
      throw SyntaxErrorException("Invalid expression-spec `" +
                                 token.getValue() + "`");
    }
    break;
  case TokenType::STMT_REF:
    if (!stmtRefTokenTypes.count(token.getType())) {
      throw SyntaxErrorException("Invalid stmtRef `" +
                                 token.getValue() + "`");
    }
    break;
  case TokenType::ENT_REF:
    if (!entRefTokenTypes.count(token.getType())) {
      throw SyntaxErrorException("Invalid entRef `" +
                                 token.getValue() + "`");
    }
    break;
  case TokenType::BOTH_REF:
    if (!bothRefTokenTypes.count(token.getType())) {
      throw SyntaxErrorException("Invalid stmtRef/entRef `" +
                                 token.getValue() + "`");
    }
    break;
  default:
    if (token.getType() != expectedTokenType) {
      throw SyntaxErrorException("Unexpected token `" + token.getValue() + "`");
    }
  }
}

bool SyntaxValidator::isValidDeclarationEntity(const Token &token) {
  return pql_constants::decEntitySet.count(token.getValue()) > 0;
}

bool SyntaxValidator::isValidIdent(const std::string &s) {
  std::regex pattern("^[a-zA-Z][a-zA-Z0-9]*$");
  return std::regex_match(s, pattern);
}

bool SyntaxValidator::isValidExprSpec(const std::string &str) {
  // TODO MS2: handle non-constant and non-variable only expressions
  std::regex pattern("([a-zA-Z][a-zA-Z0-9]*$)|(^0$|^[1-9][0-9]*)");
  return std::regex_match(str, pattern);
}
