#pragma once

#include "PKB/API/PKBManager.h"
#include "QPS/Result.h"
#include "QPS/PQLGrammar.h"
#include "QPS/Query.h"

class AssignPatternFunction {

public:
  static constexpr EntityType rel = EntityType::ASSIGNMENT;

  Result operator()(const PatternClause& clause, PKBManager& pkb);

private:
  static Result wildcardArg1(const std::string& assignSyn, const ClauseArgument& arg2, PKBManager& pkb);

  static Result nameArg1(const std::string& assignSyn, const std::string& arg1Str, const ClauseArgument& arg2, PKBManager& pkb);

  static Result synonymArg1(const std::string& assignSyn, const ClauseArgument& arg1, const ClauseArgument& arg2, PKBManager& pkb);
};

