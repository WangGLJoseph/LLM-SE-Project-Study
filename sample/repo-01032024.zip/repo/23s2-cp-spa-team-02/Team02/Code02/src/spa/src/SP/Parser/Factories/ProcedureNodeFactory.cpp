//
// Created by yeemi on 2/10/2024.
//

#include "ProcedureNodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"
#include "NodeFactory.h"

ProcedureNodeFactory::ProcedureNodeFactory() = default;

ProcedureNodeFactory::~ProcedureNodeFactory() = default;

ProcedureNodeFactory::Procedure
ProcedureNodeFactory::createProcedureNode(Tokens &tokens) {
  tokens.ensureNextTokenType(TokenTypeSP::PROCEDURE);
  TokenSP variableToken = tokens.getNextToken();
  if (!variableToken.isVariable()) {
    throw SyntaxErrorException("expected variable after procedure");
  }
  ProcedureName procedureName = variableToken.getValue();
  tokens.ensureNextTokenType(TokenTypeSP::LEFT_CURLY_BRACKET);

  StatementList statementNodes;
  while (!tokens.isEmpty()) {
    Statement statementNode = NodeFactory::createStatementNode(tokens);
    statementNodes.push_back(statementNode);
    if (tokens.checkTypeAt(tokens.getIndex(),RIGHT_CURLY_BRACKET)) {
      break;
    }
  }

  Procedure procedureNode =
      std::make_shared<ProcedureNode>(statementNodes, procedureName);

  tokens.ensureNextTokenType(TokenTypeSP::RIGHT_CURLY_BRACKET);

  return procedureNode;
}
