//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/DesignExtractor/ExtractorVisitor.h"
#include "Util/StatementType.h"

class Node {
private:
  typedef std::shared_ptr<ExtractorVisitor> Visitor;

public:
  ~Node();
  virtual void accept(const Visitor &extractorVisitor) const = 0;
};
