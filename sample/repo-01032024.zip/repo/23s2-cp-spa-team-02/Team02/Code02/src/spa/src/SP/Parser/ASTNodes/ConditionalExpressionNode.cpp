//
// Created by yeemi on 2/10/2024.
//

#include "ConditionalExpressionNode.h"

#include <utility>

ConditionalExpressionNode::ConditionalExpressionNode(VariableList variableNodes,
                                                     ConstantList constantNodes)
    : ExpressionNode(std::move(variableNodes), std::move(constantNodes)) {}

ConditionalExpressionNode::~ConditionalExpressionNode() = default;

void ConditionalExpressionNode::accept(const Visitor &extractorVisitor) const {
  extractorVisitor->visitConditionalExpressionNode(*this);
}