//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ExpressionTypes.h"
#include "SP/Parser/ASTNodes/StatementNode.h"
#include "SP/Tokenizer/TokenType.h"
#include "SP/Tokenizer/Tokens.h"
#include <memory>

class StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> Statement;

public:
  StatementNodeFactory();
  ~StatementNodeFactory();

  virtual Statement createStatementNode(Tokens &tokens) = 0;
};
