//
// Created by yeemi on 2/6/2024.
//

#pragma once

#include <memory>
#include <vector>

class ProgramNode;
class ProcedureNode;

class ConstantNode;
class VariableNode;

class ExpressionNode;
class ArithmeticExpressionNode;
class ConditionalExpressionNode;

class StatementNode;
class AssignStatementNode;
class CallStatementNode;
class IfStatementNode;
class PrintStatementNode;
class ReadStatementNode;
class WhileStatementNode;

class ExtractorVisitor {
private:
  typedef std::vector<std::shared_ptr<StatementNode>> StatementList;
public:
  virtual void visitConstantNode(const ConstantNode &constantNode) = 0;
  virtual void visitVariableNode(const VariableNode &variableNode) = 0;
  virtual void visitArithmeticExpressionNode(
      const ExpressionNode &arithmeticExpressionNode) = 0;
  virtual void visitConditionalExpressionNode(
      const ExpressionNode &conditionalExpressionNode) = 0;
  virtual void
  visitAssignStatementNode(const AssignStatementNode &assignStatementNode) = 0;
  virtual void
  visitCallStatementNode(const CallStatementNode &callStatementNode) = 0;
  virtual void visitIfStatementNode(const IfStatementNode &ifStatementNode) = 0;
  virtual void
  visitPrintStatementNode(const PrintStatementNode &printStatementNode) = 0;
  virtual void
  visitReadStatementNode(const ReadStatementNode &readStatementNode) = 0;
  virtual void
  visitWhileStatementNode(const WhileStatementNode &whileStatementNode) = 0;
  virtual void visitProgramNode(const ProgramNode &programNode) = 0;
  virtual void visitProcedureNode(const ProcedureNode &procedureNode) = 0;
  virtual void visitStatementNodeList(
      const StatementList &statementNodes) = 0;
};