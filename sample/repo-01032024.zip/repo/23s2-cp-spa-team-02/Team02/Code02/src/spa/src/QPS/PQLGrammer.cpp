#include "PQLGrammar.h"

StatementType entityToStatementType(EntityType entityType){

  switch (entityType) {

  case EntityType::STATEMENT:
    return StatementType::STATEMENT;
  case EntityType::READ:
    return StatementType::READ;
  case EntityType::PRINT:
    return StatementType::PRINT;
  case EntityType::ASSIGNMENT:
    return StatementType::ASSIGN;
  case EntityType::CALL:
    return StatementType::CALL;
  case EntityType::WHILE:
    return StatementType::WHILE;
  case EntityType::IF:
    return StatementType::IF;
  default:
    return StatementType::UNKNOWN;
  }
}