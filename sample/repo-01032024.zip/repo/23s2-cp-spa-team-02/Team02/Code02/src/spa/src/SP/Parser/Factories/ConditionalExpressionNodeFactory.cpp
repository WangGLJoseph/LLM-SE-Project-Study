//
// Created by yeemi on 2/12/2024.
//

#include "ConditionalExpressionNodeFactory.h"
#include "Exceptions/SyntaxErrorException.h"
#include "NodeFactory.h"

ConditionalExpressionNodeFactory::ConditionalExpressionNodeFactory() = default;

ConditionalExpressionNodeFactory::~ConditionalExpressionNodeFactory() = default;

ConditionalExpressionNodeFactory::ConditionalExpression
ConditionalExpressionNodeFactory::createExpressionNode(Tokens &tokens) {
  int rightParenthesisIndex =
      tokens.getRightParenthesisIndex(tokens.getIndex());
  validateConditionalExpr(tokens, tokens.getIndex(), rightParenthesisIndex);
  VariableList variableNodes;
  ConstantList constantNodes;
  while (tokens.getIndex() < rightParenthesisIndex) {
    TokenSP tok = tokens.at(tokens.getIndex());
    if (tok.isVariable()) {
      variableNodes.push_back(NodeFactory::createVariableNode(tokens));
    } else if (tok.isType(TokenTypeSP::INTEGER)) {
      constantNodes.push_back(NodeFactory::createConstantNode(tokens));
    } else {
      tokens.increaseIndex(1);
    }
  }
  tokens.ensureNextTokenType(RIGHT_PARENTHESIS);
  return std::make_shared<ConditionalExpressionNode>(variableNodes,
                                                     constantNodes);
}

void validateArithmeticExpr(Tokens &tokens, int start, int end) {
  // throw Syntax error if expression is invalid
  tokens.getPostFixExpression(start, end);
}

void validateRelationalFactor(Tokens &tokens, int start, int end) {
  if (start >= end) {
    throw SyntaxErrorException("validateRelationalFactor: out of range");
  }
  int size = end - start;
  if (size != 1) {
    validateArithmeticExpr(tokens, start, end);
    return;
  }
  if (!tokens.isVariableAt(start) && !tokens.checkTypeAt(start,INTEGER)) {
    throw SyntaxErrorException("must be name or integer");
  }
}

void validateRelationalExpr(Tokens &tokens, int start, int end) {
  if (start >= end) {
    throw SyntaxErrorException("validateRelationalExpr: out of range");
  }
  int leftEnd = start;
  while (leftEnd < end) {
    leftEnd++;
    if (tokens.isRelationalAt(leftEnd)) {
      break;
    }
  }
  if (leftEnd == end) {
    throw SyntaxErrorException("could not find relational operator");
  }
  int rightStart = leftEnd + 1;
  validateRelationalFactor(tokens, start, leftEnd);
  validateRelationalFactor(tokens, rightStart, end);
}

void ConditionalExpressionNodeFactory::validateConditionalExpr(Tokens &tokens,
                                                               int start,
                                                               int end) {
  int rightParenthesis;

  if (start >= end) {
    throw SyntaxErrorException("validateConditionalExpr: out of range");
  }
  if (tokens.checkTypeAt(start, NOT)) {
    tokens.ensureTokenTypeAt(start + 1, LEFT_PARENTHESIS);
    rightParenthesis = tokens.getRightParenthesisIndex(start + 2);
    if (rightParenthesis >= end) {
      throw SyntaxErrorException(
          "validateConditionalExpr: right paran out of expression range");
    }
    if (rightParenthesis != end - 1) {
      throw SyntaxErrorException("validateConditionalExpr: right paran must "
                                 "be last token of expression");
    }
    validateConditionalExpr(tokens, start + 2, rightParenthesis);
  } else if (tokens.checkTypeAt(start, LEFT_PARENTHESIS)) {
    rightParenthesis = tokens.getRightParenthesisIndex(start + 1);
    if (rightParenthesis >= end) {
      throw SyntaxErrorException(
          "validateConditionalExpr: right paran out of expression range");
    }

    // verify that op is valid
    int op = rightParenthesis + 1;
    if (tokens.isRelationalAt(op)) {
      validateRelationalExpr(tokens, start, end);
      return;
    }
    if (!tokens.checkTypeAt(op, AND) && !tokens.checkTypeAt(op,OR)) {
      throw SyntaxErrorException(
          "validateConditionalExpr: op token is neither AND nor OR");
    }

    // check left expr
    validateConditionalExpr(tokens, start + 1, rightParenthesis);

    int rightStart = op + 1;

    tokens.ensureTokenTypeAt(rightStart, LEFT_PARENTHESIS);
    rightParenthesis = tokens.getRightParenthesisIndex(rightStart + 1);
    if (rightParenthesis >= end) {
      throw SyntaxErrorException(
          "validateConditionalExpr: right paran out of expression range");
    }
    if (rightParenthesis != end - 1) {
      throw SyntaxErrorException("validateConditionalExpr: right paran must "
                                 "be last token of expression");
    }

    validateConditionalExpr(tokens, rightStart + 1, rightParenthesis);
  } else {
    validateRelationalExpr(tokens, start, end);
  }
}
