//
// Created by yeemi on 2/6/2024.
//

#pragma once

#include "SP/Tokenizer/TokenType.h"
#include <string>
#include <unordered_map>

class TokenSP {
private:
  std::string _value;
  TokenTypeSP _type;

public:
  TokenSP(TokenTypeSP type, std::string value);

  [[nodiscard]] std::string getValue();

  [[nodiscard]] TokenTypeSP getType();

  [[nodiscard]] bool equals(TokenSP &other);

  void ensureType(TokenTypeSP t);

  static std::string getTypeString(TokenTypeSP t);

  bool isVariable();

  bool isRelationalToken();

  bool isType(TokenTypeSP t);
};
