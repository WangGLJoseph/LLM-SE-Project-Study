//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class IfStatementNodeFactory : public StatementNodeFactory {
private:
  typedef std::shared_ptr<StatementNode> IfStatement;
  typedef std::shared_ptr<StatementNode> Statement;
  typedef std::shared_ptr<ExpressionNode> ConditionalExpression;
  typedef std::vector<std::shared_ptr<StatementNode>> ThenStatementList;
  typedef std::vector<std::shared_ptr<StatementNode>> ElseStatementList;

public:
  IfStatementNodeFactory();
  ~IfStatementNodeFactory();

  IfStatement createStatementNode(Tokens &tokens) override;
};
