//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_WHILETABLE_H
#define SPA_WHILETABLE_H

#include "pkb/tables/base/Table.h"

class WhileTable : public Table {
public:
    WhileTable() = default;

};


#endif //SPA_WHILETABLE_H
