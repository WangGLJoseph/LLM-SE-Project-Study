//
// Created by Alex on 25/2/2024.
//

#include "QueryProjector.h"
#include "qps/query_elements/constraint/Constraint.h"
#include "qps/query_elements/constraint/FollowsConstraint.h"
#include "qps/QueryProjector/ResultTable/ResultTable.h"


void processQuery(){

}

void QueryProjector::processConstraints(std::shared_ptr<Constraint> c){
    ResultTable table;


}

