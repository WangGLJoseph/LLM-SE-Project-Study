//
// Created by sjh_9 on 25/2/2024.
//

#ifndef SPA_READTABLE_H
#define SPA_READTABLE_H

#include "pkb/tables/base/Table.h"

class ReadTable : public Table {
public:
    ReadTable() = default;
};


#endif //SPA_READTABLE_H
