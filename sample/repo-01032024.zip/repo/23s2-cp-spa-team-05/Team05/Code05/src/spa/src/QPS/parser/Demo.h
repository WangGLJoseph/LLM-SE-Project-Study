//
// Created by Alex on 17/2/2024.
//

#ifndef SPA_DEMO_H
#define SPA_DEMO_H


    class Demo {
    public:
        void demonstrate();
    };


#endif //SPA_DEMO_H
