//
// Created by tohzh on 17/2/2024.
//

#include "FollowsTConstraintBuilder.h"

void FollowsTConstraintBuilder::addConstraintClause(shared_ptr<RelationshipClause> rs, shared_ptr<QueryObject> qo) {
    if (rs->getRelationshipType() != QPSTokenType::FOLLOWS_T) {
        throw std::invalid_argument( "Not followsT argument" );
    }

    arg1 = buildArgAsStatementRef(rs->getFirstArg(), rs->getFirstReferenceType(), qo);
    arg2 = buildArgAsStatementRef(rs->getSecondArg(), rs->getSecondReferenceType(), qo);
    constraintClause = make_shared<FollowsTConstraint>(arg1, arg2);
}