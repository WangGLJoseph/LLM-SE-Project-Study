//
// Created by tohzh on 11/2/2024.
//

#include "catch.hpp"
using namespace std;

#include "catch.hpp"
#include "qps/query_validator/NoDeclarationRule.h" // Include the header file for SingleDeclarationRule
#include "qps/query_elements/QueryObject.h"
#include "qps/query_elements/constraint_argument/statement_reference/StatementEntity.h"
#include "qps/query_elements/constraint_argument/statement_reference/PrintEntity.h"
#include "qps/query_elements/constraint/ParentConstraint.h"

// ai-gen start(gpt, 1, e)
// prompt: https://chat.openai.com/share/58cc37a5-02ca-46fb-8029-ff79056aad6c
TEST_CASE("noDeclarationRule_AllEntitiesDeclaredOnce_returnsNoString") {
    // Create a QueryObject with all entities declared exactly once
    IntermediateQuery qo;
    // Add entity declarations

    auto e1 = std::make_shared<DeclarationClause>(DeclarationClause());
    e1->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::STMT1), "p");
    auto e2 = std::make_shared<DeclarationClause>(DeclarationClause());
    e2->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::PRINT), "s");


    qo.addClause(e1);
    qo.addClause(e2);

    auto t1 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "p");
    auto t2 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "s");
    auto pConstraint = std::make_shared<RelationshipClause>(QPSTokenType::QPSTypeInfo::PARENT, t1, QPSTokenType::QPSTypeInfo::STMT_REF, t2, QPSTokenType::QPSTypeInfo::STMT_REF);

    qo.addClause(pConstraint);
    NoDeclarationRule rule;
    REQUIRE(rule.validate(qo).empty());
}

TEST_CASE("noDeclarationRule_Missing2EntityDeclaration_returnsString") {
    // Create a QueryObject with a missing entity declaration
    IntermediateQuery qo;
    // Add entity declaration

    auto e1 = std::make_shared<DeclarationClause>(DeclarationClause());
    e1->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::STMT1), "j");
    auto e2 = std::make_shared<DeclarationClause>(DeclarationClause());
    e2->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::PRINT), "h");

    auto t1 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "j");
    auto t2 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "h");
    auto pConstraint = std::make_shared<RelationshipClause>(QPSTokenType::QPSTypeInfo::PARENT, t1, QPSTokenType::QPSTypeInfo::STMT_REF, t2, QPSTokenType::QPSTypeInfo::STMT_REF);

    // Add a constraint with an undeclared entity as an argument
    qo.addClause(pConstraint); // e1, e2 is not declared in qo
    NoDeclarationRule rule;

    REQUIRE(rule.validate(qo) == VALIDATION_RULE_NO_DECLARATION);
}

TEST_CASE("noDeclarationRule_Missing1EntityDeclaration_returnsString") {
    // Create a QueryObject with a missing entity declaration
    IntermediateQuery qo;
    // Add entity declaration

    auto e1= std::make_shared<DeclarationClause>(DeclarationClause());
    e1->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::STMT1), "g");
    auto e2 = std::make_shared<DeclarationClause>(DeclarationClause());
    e2->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::PRINT), "f");


    qo.addClause(e1);

    auto t1 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "g");
    auto t2 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "f");
    auto pConstraint = std::make_shared<RelationshipClause>(QPSTokenType::QPSTypeInfo::PARENT, t1, QPSTokenType::QPSTypeInfo::STMT_REF, t2, QPSTokenType::QPSTypeInfo::STMT_REF);


    // Add a constraint with an undeclared entity as an argument
    qo.addClause(pConstraint);
    NoDeclarationRule rule;

    REQUIRE(rule.validate(qo) == VALIDATION_RULE_NO_DECLARATION);
}



TEST_CASE("noDeclarationRule_MultipleUsageOfMissingEntity_returnsString") {
    // Create a QueryObject with multiple usage of the same entity
    IntermediateQuery qo;
    // Add entity declaration
    auto e1 = std::make_shared<DeclarationClause>(DeclarationClause());
    e1->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::STMT1), "e");
    auto e2 = std::make_shared<DeclarationClause>(DeclarationClause());
    e2->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::PRINT), "e2");

    qo.addClause(e1);

    auto t1 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "e");
    auto t2 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "e2");

    auto pConstraint = std::make_shared<RelationshipClause>(QPSTokenType::QPSTypeInfo::PARENT, t2, QPSTokenType::QPSTypeInfo::STMT_REF, t2, QPSTokenType::QPSTypeInfo::STMT_REF);
    qo.addClause(pConstraint);

    // Add a constraint with multiple occurrences of the same entity as arguments
    //auto* p = new ParentConstraint(e2, e2); // e1 is assigned again
    NoDeclarationRule rule;
    REQUIRE(rule.validate(qo) == VALIDATION_RULE_NO_DECLARATION);
}

TEST_CASE("noDeclarationRule_EmptyQueryObjectPass_returnsNoString") {
    // Create an empty QueryObject
    IntermediateQuery qo;
    NoDeclarationRule rule;
    REQUIRE(rule.validate(qo).empty());
}

TEST_CASE("noDeclarationRule_EntitiesUsedAsArgumentsNotDeclared_returnsString") {
    // Create a QueryObject with entities used as arguments but not declared
    IntermediateQuery qo;
    // Add a constraint with an entity as an argument without declaration
    auto e1 = std::make_shared<DeclarationClause>(DeclarationClause());
    e1->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::STMT1), "q");
    auto e2 = std::make_shared<DeclarationClause>(DeclarationClause());
    e2->addDeclaration(QPSTokenType(QPSTokenType::QPSTypeInfo::PRINT), "s");

    auto t1 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "q");
    auto t2 = QPSToken(QPSTokenType(QPSTokenType::QPSTypeInfo::SYNONYM), "s");
    auto pConstraint = std::make_shared<RelationshipClause>(QPSTokenType::QPSTypeInfo::PARENT, t1, QPSTokenType::QPSTypeInfo::STMT_REF, t2, QPSTokenType::QPSTypeInfo::STMT_REF);
    qo.addClause(pConstraint); // e1 and e2 is not declared in qo
    NoDeclarationRule rule;
    REQUIRE(rule.validate(qo) == VALIDATION_RULE_NO_DECLARATION);
}

// ai-gen end