#ifndef TESTWRAPPER_H
#define TESTWRAPPER_H

#include <string>
#include <iostream>
#include <list>

// include your other headers here
#include "AbstractWrapper.h"
#include "SP/SP.h"
#include "PKB/PKB.h"
#include "PKB/API/PKBReadFacade.h"
#include "PKB/API/PKBWriteFacade.h"
#include "QPS/QPS.h"

class TestWrapper : public AbstractWrapper {
 public:
  // default constructor
  TestWrapper() : pkbRead_(pkb_), pkbWrite_(pkb_), qps_(pkbRead_) {};
  
  // destructor
  ~TestWrapper();
  
  // method for parsing the SIMPLE source
  virtual void parse(std::string filename);
  
  // method for evaluating a query
  virtual void evaluate(std::string query, std::list<std::string>& results);

private:
  PKB pkb_;
  PKBReadFacade pkbRead_;
  PKBWriteFacade pkbWrite_;
  QPS qps_;
  SP sp_{};
};

#endif
