//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <vector>

class ExpressionNode : public Node {
private:
  std::vector<std::shared_ptr<VariableNode>> _variableNodes;
  std::vector<std::shared_ptr<ConstantNode>> _constantNodes;

public:
  explicit ExpressionNode(
      std::vector<std::shared_ptr<VariableNode>> variableNodes,
      std::vector<std::shared_ptr<ConstantNode>> constantNodes);
  ~ExpressionNode();

  void accept(ExtractorVisitor *extractorVisitor) override = 0;

  std::vector<std::shared_ptr<VariableNode>> getVariableNodes();
  std::vector<std::shared_ptr<ConstantNode>> getConstantNodes();
};