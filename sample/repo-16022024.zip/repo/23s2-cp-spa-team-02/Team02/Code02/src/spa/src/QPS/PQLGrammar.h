#pragma once

enum class RelRef {
  FOLLOWS,
  FOLLOWS_T,
  PARENT,
  PARENT_T,
  USES_S,
  USES_P,
  MODIFIES_S,
  MODIFIES_P
};

enum class EntityType {
  PROCEDURE,
  VARIABLE,
  STATEMENT,
  READ,
  PRINT,
  ASSIGNMENT,
  CALL,
  WHILE,
  IF,
  CONSTANT,
  WILDCARD,
};
