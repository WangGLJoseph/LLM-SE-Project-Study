//
// Created by yeemi on 2/12/2024.
//

#pragma once

enum ExpressionType { ARITHMETIC, CONDITIONAL, RELATIONAL };
