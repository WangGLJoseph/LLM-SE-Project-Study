//
// Created by yeemi on 2/8/2024.
//

#include "EntityExtractor.h"
#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/ASTNodes/CallStatementNode.h"
#include "SP/Parser/ASTNodes/ConstantNode.h"
#include "SP/Parser/ASTNodes/ExpressionNode.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/PrintStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/ReadStatementNode.h"
#include "SP/Parser/ASTNodes/VariableNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

EntityExtractor::EntityExtractor(PKBWriteFacade &pkbWriteFacade)
    : BaseExtractor(pkbWriteFacade) {}

EntityExtractor::~EntityExtractor() = default;

void EntityExtractor::visitProcedureNode(
    std::shared_ptr<ProcedureNode> procedureNode) {
  std::string procName = procedureNode->getName();
  getPKBWriteFacade().addProcedure(procName);
  visitStatementNodeList(procedureNode->getStatementNodes());
}

void EntityExtractor::visitStatementNodeList(
    const std::vector<std::shared_ptr<StatementNode>> &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    statementNode->accept(this);
  }
}

void EntityExtractor::visitConstantNode(
    std::shared_ptr<ConstantNode> constantNode) {
  std::string constantName = constantNode->getName();
  getPKBWriteFacade().addConstant(constantName);
}

void EntityExtractor::visitVariableNode(
    std::shared_ptr<VariableNode> variableNode) {
  std::string variableName = variableNode->getName();
  getPKBWriteFacade().addVariable(variableName);
}

void EntityExtractor::visitAssignStatementNode(
    std::shared_ptr<AssignStatementNode> assignStatementNode) {
  std::string variableName = assignStatementNode->getVariableNode()->getName();
  getPKBWriteFacade().addVariable(variableName);
  getPKBWriteFacade().addStatementWithType(
      std::to_string(assignStatementNode->getStatementNumber()),
      assignStatementNode->getStatementType());
  assignStatementNode->getArithmeticExpressionNode()->accept(this);
}

void EntityExtractor::visitCallStatementNode(
    std::shared_ptr<CallStatementNode> callStatementNode) {
  std::string procName = callStatementNode->getProcedureName();
  getPKBWriteFacade().addProcedure(procName);
  getPKBWriteFacade().addStatementWithType(
      std::to_string(callStatementNode->getStatementNumber()),
      callStatementNode->getStatementType());
}

void EntityExtractor::visitIfStatementNode(
    std::shared_ptr<IfStatementNode> ifStatementNode) {
  getPKBWriteFacade().addStatementWithType(
      std::to_string(ifStatementNode->getStatementNumber()),
      ifStatementNode->getStatementType());
  visitConditionalExpressionNode(
      ifStatementNode->getConditionalExpressionNode());
  visitStatementNodeList(ifStatementNode->getThenStatementNodes());
  visitStatementNodeList(ifStatementNode->getElseStatementNodes());
}

void EntityExtractor::visitPrintStatementNode(
    std::shared_ptr<PrintStatementNode> printStatementNode) {
  getPKBWriteFacade().addStatementWithType(
      std::to_string(printStatementNode->getStatementNumber()),
      printStatementNode->getStatementType());
  std::string variableName = printStatementNode->getVariableNode()->getName();
  getPKBWriteFacade().addVariable(variableName);
}

void EntityExtractor::visitReadStatementNode(
    std::shared_ptr<ReadStatementNode> readStatementNode) {
  getPKBWriteFacade().addStatementWithType(
      std::to_string(readStatementNode->getStatementNumber()),
      readStatementNode->getStatementType());
  std::string variableName = readStatementNode->getVariableNode()->getName();
  getPKBWriteFacade().addVariable(variableName);
}

void EntityExtractor::visitWhileStatementNode(
    std::shared_ptr<WhileStatementNode> whileStatementNode) {

  getPKBWriteFacade().addStatementWithType(
      std::to_string(whileStatementNode->getStatementNumber()),
      whileStatementNode->getStatementType());
  visitConditionalExpressionNode(
      whileStatementNode->getConditionalExpressionNode());
  visitStatementNodeList(whileStatementNode->getStatementNodes());
}

void EntityExtractor::visitArithmeticExpressionNode(
    std::shared_ptr<ExpressionNode> arithmeticExpressionNode) {
  extractData(arithmeticExpressionNode);
}

void EntityExtractor::visitConditionalExpressionNode(
    std::shared_ptr<ExpressionNode> conditionalExpressionNode) {
  extractData(conditionalExpressionNode);
}

void EntityExtractor::visitRelationalExpressionNode(
    std::shared_ptr<ExpressionNode> relationalExpressionNode) {
  extractData(relationalExpressionNode);
}

void EntityExtractor::extractData(
    const std::shared_ptr<ExpressionNode> &expressionNode) {
  for (auto &variableNode : expressionNode->getVariableNodes()) {
    variableNode->accept(this);
  }
  for (auto &constantNode : expressionNode->getConstantNodes()) {
    constantNode->accept(this);
  }
}

void EntityExtractor::visitProgramNode(
    std::shared_ptr<ProgramNode> programNode) {}