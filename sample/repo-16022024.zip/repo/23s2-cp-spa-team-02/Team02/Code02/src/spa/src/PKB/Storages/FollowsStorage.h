//
// Created by Clement Kong on 7/2/24.
//

#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>

class FollowsStorage {
public:
  FollowsStorage();
  ~FollowsStorage();

  void addFollows(const std::string &statement1, const std::string &statement2);
  bool hasFollows();

  // TODO: Future implementation is a recursive call to get follows* rs instead
  // of manual NOT COMPLETED
  void addFollowsStar(const std::string &statement1,
                      const std::string &statement2);

  const std::string &getStatementFollowing(const std::string &statement);

private:
  std::unordered_map<std::string, std::string> follows_;
  std::unordered_map<std::string, std::unordered_set<std::string>> followsStar_;
};
