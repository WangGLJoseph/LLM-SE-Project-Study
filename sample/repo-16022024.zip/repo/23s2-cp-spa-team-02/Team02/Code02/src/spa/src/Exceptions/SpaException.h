//
// Created by Evan Chng on 8/2/24.
//
#pragma once

#include <exception>
#include <string>
#include <utility>

class SpaException : public std::exception {
public:
    // Constructor with error message
    SpaException() = default;

    // Virtual destructor for proper cleanup in inheritance
    ~SpaException() override = default;

    explicit SpaException(std::string_view msg) : msg_(msg) {}

    // Function to get the error message
    virtual std::string_view what() = 0;

protected:
    std::string msg_;
};