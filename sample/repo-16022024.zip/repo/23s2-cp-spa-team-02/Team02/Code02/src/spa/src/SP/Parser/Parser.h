//
// Created by yeemi on 2/6/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ProgramNode.h"
#include "SP/Parser/Factories/NodeFactory.h"
#include "SP/Tokenizer/TokenSP.h"
#include "SP/Tokenizer/Tokens.h"

class Parser {
public:
  Parser();
  ~Parser();

  static ProgramNode parseTokens(Tokens &tokens);
};
