#pragma once

#include "PQLGrammar.h"
#include <string>
#include <unordered_map>
#include <vector>

class Clause {
  // Common stuff between StClause and PatternClause belong here
};

class StClause : public Clause {
public:
  explicit StClause(RelRef rel, const std::string &arg1,
                    const std::string &arg2)
      : rel_(rel), arg1_(arg1), arg2_(arg2){};
  virtual ~StClause() = default;

  [[nodiscard]] RelRef getRelationship() const { return rel_; }
  [[nodiscard]] const std::string &getArg1() const { return arg1_; }
  [[nodiscard]] const std::string &getArg2() const { return arg2_; }

private:
  RelRef rel_;
  std::string arg1_;
  std::string arg2_;

  // When such that clause does not contain synonym, it should be returning True
  // or False instead of a set of values.
};

class PatternClause : public Clause {
public:
  explicit PatternClause(const std::string &assignSyn, const std::string &arg1,
                         const std::string &arg2)
      : assignSyn_(assignSyn), arg1_(arg1), arg2_(arg2){};
  virtual ~PatternClause() = default;

  [[nodiscard]] const std::string &getassignSyn() const { return assignSyn_; }
  [[nodiscard]] const std::string &getArg1() const { return arg1_; }
  [[nodiscard]] const std::string &getArg2() const { return arg2_; }

private:
  std::string assignSyn_;
  std::string arg1_;
  std::string arg2_;
};

class Query {
public:
  Query(std::string& selectedSynonym, std::unordered_map<std::string, EntityType>& synonymMap,
        std::vector<StClause>& stClauses, std::vector<PatternClause>& patternClauses);
  ~Query() = default;
  std::unordered_map<std::string, EntityType> synonymMap_;

  // TODO replace selectedSynonym to support tuple and boolean
  std::string selectedSynonym_;
  std::vector<StClause> stClauses_;
  std::vector<PatternClause> patternClauses_;
};
