//
// Created by yeemi on 2/10/2024.
//

#include "ProgramNode.h"
#include "ProcedureNode.h"

ProgramNode::ProgramNode(
    std::vector<std::shared_ptr<ProcedureNode>> &procedureNodes)
    : _procedureNodes(procedureNodes) {}

ProgramNode::~ProgramNode() = default;

void ProgramNode::accept(ExtractorVisitor *extractorVisitor) {
  for (const std::shared_ptr<ProcedureNode> &procedureNode :
       getProcedureNodes()) {
    procedureNode->accept(extractorVisitor);
  }
}

std::vector<std::shared_ptr<ProcedureNode>> ProgramNode::getProcedureNodes() {
  return _procedureNodes;
}
