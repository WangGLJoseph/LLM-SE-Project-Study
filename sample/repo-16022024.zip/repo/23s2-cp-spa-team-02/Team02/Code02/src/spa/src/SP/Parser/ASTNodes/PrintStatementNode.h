//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "StatementNode.h"

class PrintStatementNode : public StatementNode {
private:
  std::shared_ptr<VariableNode> _variableNode;

public:
  explicit PrintStatementNode(int statementNumber,
                              std::shared_ptr<VariableNode> variableNode);
  ~PrintStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::shared_ptr<VariableNode> getVariableNode();
};