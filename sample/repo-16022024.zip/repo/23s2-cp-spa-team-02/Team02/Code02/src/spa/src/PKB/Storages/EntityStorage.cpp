
//
// Created by Clement Kong on 7/2/24.
//
#include "EntityStorage.h"

EntityStorage::EntityStorage() = default;
EntityStorage::~EntityStorage() = default;

void EntityStorage::addVariable(const std::string &varName) {
  this->variableStorage_.insert(varName);
}

void EntityStorage::addConstant(const std::string &constVal) {
  this->constantStorage_.insert(constVal);
}

void EntityStorage::addProcedure(const std::string &procName) {
  this->procedureStorage_.insert(procName);
}

const std::unordered_set<std::string> &EntityStorage::getConstants() {
  return this->constantStorage_;
}

const std::unordered_set<std::string> &EntityStorage::getVariables() {
  return this->variableStorage_;
}

const std::unordered_set<std::string> &EntityStorage::getProcedures() {
  return this->procedureStorage_;
}
