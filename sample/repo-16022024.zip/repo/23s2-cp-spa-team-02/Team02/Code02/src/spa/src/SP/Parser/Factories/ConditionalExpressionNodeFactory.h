//
// Created by yeemi on 2/12/2024.
//
#pragma once

#include "../ASTNodes/ConditionalExpressionNode.h"
#include "ExpressionNodeFactory.h"

class ConditionalExpressionNodeFactory : public ExpressionNodeFactory {
public:
  ConditionalExpressionNodeFactory();
  ~ConditionalExpressionNodeFactory();

  std::shared_ptr<ExpressionNode> createExpressionNode(Tokens &tokens) override;
};
