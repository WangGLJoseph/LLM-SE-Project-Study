//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ArithmeticExpressionNodeFactory.h"
#include "AssignStatementNodeFactory.h"
#include "CallStatementNodeFactory.h"
#include "ConditionalExpressionNodeFactory.h"
#include "ConstantNodeFactory.h"
#include "IfStatementNodeFactory.h"
#include "PrintStatementNodeFactory.h"
#include "ProcedureNodeFactory.h"
#include "ReadStatementNodeFactory.h"
#include "RelationalExpressionNodeFactory.h"
#include "SP/Parser/ASTNodes/ExpressionTypes.h"
#include "SP/Parser/ASTNodes/Node.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"
#include "SP/Tokenizer/TokenSP.h"
#include "SP/Tokenizer/Tokens.h"
#include "VariableNodeFactory.h"
#include "WhileStatementNodeFactory.h"

class NodeFactory {
private:
  inline static ProcedureNodeFactory _procedureNodeFactory;
  inline static AssignStatementNodeFactory _assignStatementNodeFactory;
  inline static CallStatementNodeFactory _callStatementNodeFactory;
  inline static IfStatementNodeFactory _ifStatementNodeFactory;
  inline static ReadStatementNodeFactory _readStatementNodeFactory;
  inline static PrintStatementNodeFactory _printStatementNodeFactory;
  inline static WhileStatementNodeFactory _whileStatementNodeFactory;
  inline static ArithmeticExpressionNodeFactory
      _arithmeticExpressionNodeFactory;
  inline static ConditionalExpressionNodeFactory
      _conditionalExpressionNodeFactory;
  inline static RelationalExpressionNodeFactory
      _relationalExpressionNodeFactory;
  inline static ConstantNodeFactory _constantNodeFactory;
  inline static VariableNodeFactory _variableNodeFactory;
  inline static int _statementNumber;

public:
  NodeFactory();
  ~NodeFactory();

  static int getStatementNumber();
  static void initializeFactory();
  static void increaseStatementNumber();
  static void resetStatementNumber();
  static ProgramNode createAST(Tokens &tokens);
  //  static ProcedureNodeFactory getProcedureNodeFactory();
  static AssignStatementNodeFactory getAssignStatementNodeFactory();
  static CallStatementNodeFactory getCallStatementNodeFactory();
  static IfStatementNodeFactory getIfStatementNodeFactory();
  static ReadStatementNodeFactory getReadStatementNodeFactory();
  static PrintStatementNodeFactory getPrintStatementNodeFactory();
  static WhileStatementNodeFactory getWhileStatementNodeFactory();
  static ArithmeticExpressionNodeFactory getArithmeticExpressionNodeFactory();
  static ConditionalExpressionNodeFactory getConditionalExpressionNodeFactory();
  static RelationalExpressionNodeFactory getRelationalExpressionNodeFactory();
  static ConstantNodeFactory getConstantNodeFactory();
  static VariableNodeFactory getVariableNodeFactory();
  static std::shared_ptr<ProcedureNode> createProcedureNode(Tokens &tokens);
  static std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens);
  static std::shared_ptr<ExpressionNode>
  createExpressionNode(Tokens &tokens, ExpressionType type);
  static std::shared_ptr<ConstantNode> createConstantNode(Tokens &tokens);
  static std::shared_ptr<VariableNode> createVariableNode(Tokens &tokens);
};
