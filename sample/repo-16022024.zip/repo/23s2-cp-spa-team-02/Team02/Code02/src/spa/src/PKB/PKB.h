//
// Created by Clement Kong on 5/2/24.
//

#pragma once
#include "PKB/Storages/EntityStorage.h"
#include "PKB/Storages/FollowsStorage.h"
#include "PKB/Storages/StatementStorage.h"
#include <string>
#include <unordered_map>
#include <unordered_set>

class PKB {
public:
  // Constructor and destructor
  PKB();
  ~PKB();

private:
  // Storage for procedures and variables they modify
  EntityStorage entityStorage_;
  FollowsStorage followsStorage_;
  StatementStorage statementStorage_;

  friend class PKBWriteFacade;
  friend class PKBReadFacade;
};
