//
// Created by Clement Kong on 5/2/24.
//
#pragma once
#include "PKB/PKB.h"

class PKBReadFacade {
public:
  PKBReadFacade(PKB &pkb);

  ~PKBReadFacade();

  const std::unordered_set<std::string> &getVariables() const;
  const std::unordered_set<std::string> &getConstants() const;
  const std::unordered_set<std::string> &getProcedures() const;
  const std::unordered_set<std::string> &getStatements() const;
  const std::unordered_set<std::string> &
  getStatementsWithType(const std::string &stmtType) const;
  const std::unordered_set<std::string> &
  getStatementsWithMetadata(const std::string &stmtMeta) const;

  // Follows
  const std::string &getStatementFollowing(const std::string &statement) const;

private:
  PKB &pkb_;
};
