//
// Created by yeemi on 2/10/2024.
//

#include "WhileStatementNode.h"

#include <utility>

WhileStatementNode::WhileStatementNode(
    int statementNumber,
    std::shared_ptr<ExpressionNode> conditionalExpressionNode,
    std::vector<std::shared_ptr<StatementNode>> statementNodes)
    : StatementNode(statementNumber, "while"),
      _conditionalExpressionNode(std::move(conditionalExpressionNode)),
      _statementNodes(std::move(statementNodes)) {}

WhileStatementNode::~WhileStatementNode() = default;

void WhileStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitWhileStatementNode(
      std::make_shared<WhileStatementNode>(*this));
}

std::shared_ptr<ExpressionNode>
WhileStatementNode::getConditionalExpressionNode() {
  return _conditionalExpressionNode;
}

std::vector<std::shared_ptr<StatementNode>>
WhileStatementNode::getStatementNodes() {
  return _statementNodes;
}
