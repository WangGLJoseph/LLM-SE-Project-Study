#include "Token.h"

Token::Token(std::string value, TokenType type)
    : value(std::move(value)), type(type) {}

std::string Token::getValue() const {
  return value;
}

TokenType Token::getType() const {
  return type;
}
