#include "EvaluatorDispatcher.h"

Result EvaluatorDispatcher::dispatchClause(const StClause& stClause) {

  switch (stClause.getRelationship()) {

  case RelRef::FOLLOWS:
    return followsEvaluator_.evaluate(stClause);

  default:
    break;

  }

  return Result{{}};
}

Result EvaluatorDispatcher::dispatchClause(const PatternClause& patternClause) {

  return Result{{}};
}