//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <string>

class VariableNode : public Node {
private:
  std::string _name;

public:
  explicit VariableNode(std::string name);
  ~VariableNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::string getName();
};