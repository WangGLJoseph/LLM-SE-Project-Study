//
// Created by yeemi on 2/10/2024.
//

#include "ExpressionNode.h"

#include <utility>

ExpressionNode::ExpressionNode(
    std::vector<std::shared_ptr<VariableNode>> variableNodes,
    std::vector<std::shared_ptr<ConstantNode>> constantNodes)
    : _variableNodes(std::move(variableNodes)),
      _constantNodes(std::move(constantNodes)) {}

ExpressionNode::~ExpressionNode() = default;

std::vector<std::shared_ptr<VariableNode>> ExpressionNode::getVariableNodes() {
  return _variableNodes;
}

std::vector<std::shared_ptr<ConstantNode>> ExpressionNode::getConstantNodes() {
  return _constantNodes;
}
