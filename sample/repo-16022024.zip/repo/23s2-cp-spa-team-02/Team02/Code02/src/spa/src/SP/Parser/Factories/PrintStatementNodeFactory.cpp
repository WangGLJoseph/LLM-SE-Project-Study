//
// Created by yeemi on 2/10/2024.
//

#include "PrintStatementNodeFactory.h"
#include "NodeFactory.h"

PrintStatementNodeFactory::PrintStatementNodeFactory() = default;

PrintStatementNodeFactory::~PrintStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
PrintStatementNodeFactory::createStatementNode(Tokens &tokens) {
  // Skip the read keyword
  tokens.increaseIndex(1);

  std::shared_ptr<VariableNode> variableNode =
      NodeFactory::createVariableNode(tokens);

  // Skip the ";" semicolon
  tokens.increaseIndex(1);
  return std::make_shared<PrintStatementNode>(NodeFactory::getStatementNumber(),
                                              variableNode);
}
