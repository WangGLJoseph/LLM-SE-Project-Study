//
// Created by yeemi on 2/12/2024.
//

#include "ConditionalExpressionNodeFactory.h"
#include "NodeFactory.h"

ConditionalExpressionNodeFactory::ConditionalExpressionNodeFactory() = default;

ConditionalExpressionNodeFactory::~ConditionalExpressionNodeFactory() = default;

std::shared_ptr<ExpressionNode>
ConditionalExpressionNodeFactory::createExpressionNode(Tokens &tokens) {
  int rightParenthesisIndex = tokens.getRightParenthesisIndex();
  std::vector<std::shared_ptr<VariableNode>> variableNodes;
  std::vector<std::shared_ptr<ConstantNode>> constantNodes;
  while (tokens.getIndex() < rightParenthesisIndex) {
    TokenTypeSP type = tokens.peekHead();
    switch (type) {
    case TokenTypeSP::NAME:
      variableNodes.push_back(NodeFactory::createVariableNode(tokens));
      break;
    case TokenTypeSP::INTEGER:
      constantNodes.push_back(NodeFactory::createConstantNode(tokens));
      break;
    default:
      // skip operators and nested conditions for now
      tokens.increaseIndex(1);
      break;
    }
  }
  // Skip the ")"
  tokens.increaseIndex(1);
  return std::make_shared<ConditionalExpressionNode>(variableNodes,
                                                     constantNodes);
}