#pragma once

#include <unordered_set>

#include "PKB/API/PKBReadFacade.h"

#include "QPS/Parser/QueryParser.h"
#include "QPS/Result.h"
#include "QPS/EvaluatorDispatcher.h"

class QPS {

public:
    explicit QPS(PKBReadFacade& pkb) : pkb_(pkb), evaluator_(pkb) {};
    virtual ~QPS() = default;

    std::unordered_set<std::string> processQuery(const std::string& query);

private:
    EvaluatorDispatcher evaluator_;
    QueryParser parser;
    PKBReadFacade pkb_;
};
