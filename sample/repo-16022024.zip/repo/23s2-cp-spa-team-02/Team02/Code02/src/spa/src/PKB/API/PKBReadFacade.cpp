//
// Created by Clement Kong on 5/2/24.
//
#include "PKBReadFacade.h"
PKBReadFacade::PKBReadFacade(PKB &pkb) : pkb_(pkb) {}

PKBReadFacade::~PKBReadFacade() = default;

const std::unordered_set<std::string> &PKBReadFacade::getVariables() const {
  return this->pkb_.entityStorage_.getVariables();
}

const std::unordered_set<std::string> &PKBReadFacade::getProcedures() const {
  return this->pkb_.entityStorage_.getProcedures();
}

const std::unordered_set<std::string> &PKBReadFacade::getConstants() const {
  return this->pkb_.entityStorage_.getConstants();
}

const std::unordered_set<std::string> &PKBReadFacade::getStatements() const {
  return this->pkb_.statementStorage_.getStatements();
}

const std::unordered_set<std::string> &
PKBReadFacade::getStatementsWithType(const std::string &stmtType) const {
  return this->pkb_.statementStorage_.getStatementsWithType(stmtType);
}

const std::unordered_set<std::string> &
PKBReadFacade::getStatementsWithMetadata(const std::string &metadata) const {
  return this->pkb_.statementStorage_.getStatementsWithMetadata(metadata);
}

const std::string &
PKBReadFacade::getStatementFollowing(const std::string &statement) const {
  return this->pkb_.followsStorage_.getStatementFollowing(statement);
}