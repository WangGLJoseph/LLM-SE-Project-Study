//
// Created by yeemi on 2/10/2024.
//

#include "NodeFactory.h"

NodeFactory::NodeFactory() = default;

NodeFactory::~NodeFactory() = default;

ProgramNode NodeFactory::createAST(Tokens &tokens) {
  resetStatementNumber();
  std::vector<std::shared_ptr<ProcedureNode>> procedureNodes;
  while (!tokens.isEmpty()) {
    std::shared_ptr<ProcedureNode> procedureNode = createProcedureNode(tokens);
    procedureNodes.push_back(procedureNode);
  }
  ProgramNode AST = ProgramNode(procedureNodes);
  return AST;
}
int NodeFactory::getStatementNumber() {
  increaseStatementNumber();
  return _statementNumber - 1;
}

void NodeFactory::increaseStatementNumber() { _statementNumber++; }

void NodeFactory::resetStatementNumber() {
  // TODO: Confirm if start at 0 or 1 + decide where to increment
  _statementNumber = 1;
}

std::shared_ptr<StatementNode>
NodeFactory::createStatementNode(Tokens &tokens) {
  TokenTypeSP firstToken = tokens.peekHead();

  switch (firstToken) {
  case TokenTypeSP::NAME:
    return getAssignStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::CALL:
    return getCallStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::PRINT:
    return getPrintStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::READ:
    return getReadStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::WHILE:
    return getWhileStatementNodeFactory().createStatementNode(tokens);
  case TokenTypeSP::IF:
    return getIfStatementNodeFactory().createStatementNode(tokens);
  default:
    // TODO: Handle Exception
    return nullptr;
  }
}

std::shared_ptr<ExpressionNode>
NodeFactory::createExpressionNode(Tokens &tokens, ExpressionType type) {
  switch (type) {
  case ExpressionType::ARITHMETIC:
    return getArithmeticExpressionNodeFactory().createExpressionNode(tokens);
  case ExpressionType::CONDITIONAL:
    return getConditionalExpressionNodeFactory().createExpressionNode(tokens);
  case ExpressionType::RELATIONAL:
    return getRelationalExpressionNodeFactory().createExpressionNode(tokens);
  default:
    // TODO: Handle Exception
    return nullptr;
  }
}

std::shared_ptr<ConstantNode> NodeFactory::createConstantNode(Tokens &tokens) {
  return getConstantNodeFactory().createConstantNode(tokens);
}
std::shared_ptr<VariableNode> NodeFactory::createVariableNode(Tokens &tokens) {
  return getVariableNodeFactory().createVariableNode(tokens);
}

// ProcedureNodeFactory NodeFactory::getProcedureNodeFactory() {
//   return _procedureNodeFactory;
// }

AssignStatementNodeFactory NodeFactory::getAssignStatementNodeFactory() {
  return _assignStatementNodeFactory;
}

CallStatementNodeFactory NodeFactory::getCallStatementNodeFactory() {
  return _callStatementNodeFactory;
}

IfStatementNodeFactory NodeFactory::getIfStatementNodeFactory() {
  return _ifStatementNodeFactory;
}

ReadStatementNodeFactory NodeFactory::getReadStatementNodeFactory() {
  return _readStatementNodeFactory;
}

PrintStatementNodeFactory NodeFactory::getPrintStatementNodeFactory() {
  return _printStatementNodeFactory;
}

WhileStatementNodeFactory NodeFactory::getWhileStatementNodeFactory() {
  return _whileStatementNodeFactory;
}

ArithmeticExpressionNodeFactory
NodeFactory::getArithmeticExpressionNodeFactory() {
  return _arithmeticExpressionNodeFactory;
}

ConditionalExpressionNodeFactory
NodeFactory::getConditionalExpressionNodeFactory() {
  return _conditionalExpressionNodeFactory;
}

RelationalExpressionNodeFactory
NodeFactory::getRelationalExpressionNodeFactory() {
  return _relationalExpressionNodeFactory;
}
ConstantNodeFactory NodeFactory::getConstantNodeFactory() {
  return _constantNodeFactory;
}
VariableNodeFactory NodeFactory::getVariableNodeFactory() {
  return _variableNodeFactory;
}

std::shared_ptr<ProcedureNode>
NodeFactory::createProcedureNode(Tokens &tokens) {
  ProcedureNodeFactory factoryInstance = ProcedureNodeFactory();
  return ProcedureNodeFactory::createProcedureNode(tokens);
}
void NodeFactory::initializeFactory() {
  _procedureNodeFactory = ProcedureNodeFactory();
  _assignStatementNodeFactory = AssignStatementNodeFactory();
  _callStatementNodeFactory = CallStatementNodeFactory();
  _ifStatementNodeFactory = IfStatementNodeFactory();
  _readStatementNodeFactory = ReadStatementNodeFactory();
  _printStatementNodeFactory = PrintStatementNodeFactory();
  _whileStatementNodeFactory = WhileStatementNodeFactory();
  _arithmeticExpressionNodeFactory = ArithmeticExpressionNodeFactory();
  _conditionalExpressionNodeFactory = ConditionalExpressionNodeFactory();
  _relationalExpressionNodeFactory = RelationalExpressionNodeFactory();
  _constantNodeFactory = ConstantNodeFactory();
  _variableNodeFactory = VariableNodeFactory();
}
