//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/PrintStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class PrintStatementNodeFactory : public StatementNodeFactory {
public:
  PrintStatementNodeFactory();
  ~PrintStatementNodeFactory();

  std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens) override;
};