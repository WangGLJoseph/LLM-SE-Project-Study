#pragma once
#include "QPS/Query.h"
#include "QPS/Tokenizer/QueryTokenizer.h"
#include "QPS/PQLGrammar.h"

class QueryParser {
private:
  // TODO: mapping from token to entity
  const std::unordered_map<std::string, EntityType> tokenValToEntityType = {
      {"procedure", EntityType::PROCEDURE},
      {"variable",  EntityType::VARIABLE},
      {"stmt", EntityType::STATEMENT},
      {"read",      EntityType::READ},
      {"print",     EntityType::PRINT},
      {"assign",    EntityType::ASSIGNMENT},
      {"call",      EntityType::CALL},
      {"while",     EntityType::WHILE},
      {"if",        EntityType::IF},
  };

  const std::unordered_map<std::string, RelRef> tokenValToRelRef = {
    {"Follows", RelRef::FOLLOWS},
    {"Follows*",  RelRef::FOLLOWS_T},
    {"Parent", RelRef::PARENT},
    {"Parent*",      RelRef::PARENT_T},
    {"Uses",     RelRef::USES_S},
    {"Modifies",      RelRef::MODIFIES_S},
  };
private:
  std::string removeWhitespaces(const std::string& query);
  std::pair<std::string, std::string> getClauseArgs(
      const std::vector<Token>& tokens, size_t& index);
public:
  Query parseQuery(const std::string &query);
  QueryTokenizer tokenizer;
};
