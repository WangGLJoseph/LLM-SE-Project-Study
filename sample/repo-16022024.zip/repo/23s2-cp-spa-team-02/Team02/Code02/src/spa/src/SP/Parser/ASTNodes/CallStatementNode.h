//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ProcedureNode.h"
#include "StatementNode.h"

class CallStatementNode : public StatementNode {
private:
  std::string _procedureName;

public:
  explicit CallStatementNode(int statementNumber, std::string procedureName);
  ~CallStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::string getProcedureName();
};