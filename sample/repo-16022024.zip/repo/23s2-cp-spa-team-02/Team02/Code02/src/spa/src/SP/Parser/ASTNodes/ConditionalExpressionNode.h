//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ExpressionNode.h"

class ConditionalExpressionNode : public ExpressionNode {
public:
  explicit ConditionalExpressionNode(
      std::vector<std::shared_ptr<VariableNode>> variableNodes,
      std::vector<std::shared_ptr<ConstantNode>> constantNodes);
  ~ConditionalExpressionNode();
  void accept(ExtractorVisitor *extractorVisitor) override;
};