//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <string>

class StatementNode : public Node {
private:
  int _statementNumber;
  std::string _statementType;

public:
  explicit StatementNode(int statementNumber, std::string statementType);

  [[nodiscard]] int getStatementNumber() const;
  [[nodiscard]] std::string getStatementType() const;

  void accept(ExtractorVisitor *extractorVisitor) override = 0;
};