//
// Created by yeemi on 2/12/2024.
//

#include "RelationalExpressionNodeFactory.h"

RelationalExpressionNodeFactory::RelationalExpressionNodeFactory() = default;

RelationalExpressionNodeFactory::~RelationalExpressionNodeFactory() = default;

std::shared_ptr<ExpressionNode>
RelationalExpressionNodeFactory::createExpressionNode(Tokens &tokens) {
  return {};
}