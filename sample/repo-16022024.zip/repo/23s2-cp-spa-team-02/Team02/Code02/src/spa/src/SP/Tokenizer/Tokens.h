//
// Created by Evan Chng on 11/2/24.
//
#pragma once

#include "TokenSP.h"
#include <vector>

class Tokens {
private:
  std::vector<TokenSP> _tokens;
  int _index;
  int _length;

public:
  explicit Tokens(std::vector<TokenSP> tokens);
  ~Tokens();

  [[nodiscard]] int getIndex() const;
  [[nodiscard]] int getLength() const;
  bool isEmpty();
  std::vector<TokenSP> getTokens();
  TokenSP at(int idx);
  TokenTypeSP peekHead();
  void increaseIndex(int numberOfTokens);
  int getRightParenthesisIndex();
  int getRightCurlyBracketIndex();
  int getSemicolonIndex();
  TokenSP getNextToken();
};
