//
// Created by Evan Chng on 8/2/24.
//
#pragma once

#include <exception>
#include <utility>
#include <string>

class SyntaxErrorException : public std::exception {
private:
    std::string message_;
public:
    explicit SyntaxErrorException(std::string msg) : message_(std::move(msg)) {}

    [[nodiscard]] const char *what() const noexcept override {
        return message_.c_str();
    }
};