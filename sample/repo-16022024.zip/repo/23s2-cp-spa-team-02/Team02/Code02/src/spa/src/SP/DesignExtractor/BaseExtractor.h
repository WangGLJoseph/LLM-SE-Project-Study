//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../../PKB/API/PKBWriteFacade.h"
#include "ExtractorVisitor.h"

class BaseExtractor : public ExtractorVisitor {
private:
  PKBWriteFacade &_pkbWriteFacade;

public:
  explicit BaseExtractor(PKBWriteFacade &pkbWriteFacade);

  PKBWriteFacade getPKBWriteFacade();
};
