#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using Table = std::unordered_map<std::string, std::vector<std::string>>;

class Result {

public:

    explicit Result(std::initializer_list<std::string> synonyms);
    explicit Result(Table& table) : table_(table) {};

    std::unordered_set<std::string> getSynonym(const std::string& synonym);
    void populateSynonym(const std::string& synonym, const std::vector<std::string>& values);

    bool isEmpty();

private:
    Table table_;
};