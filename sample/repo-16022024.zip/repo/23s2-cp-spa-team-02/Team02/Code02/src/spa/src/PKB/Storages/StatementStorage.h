//
// Created by Clement Kong on 7/2/24.
//

#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>

class StatementStorage {
public:
  StatementStorage();
  ~StatementStorage();

  void addStatementWithType(const std::string &stmtNumber,
                            const std::string &stmtType);
  void addStatementMetadata(const std::string &stmtNumber,
                          std::unordered_set<std::string> &metadata);

  // Get all statements
  const std::unordered_set<std::string> &getStatements();

  // Get statements with type e.g. Read
  const std::unordered_set<std::string> &
  getStatementsWithType(const std::string &stmtType);

  // Get statements that contain meta e.g. statement 1 contains metadata x
  const std::unordered_set<std::string> &
  getStatementsWithMetadata(const std::string &metadata);

private:
  // Store statement number in string format
  std::unordered_set<std::string> allStatementStorage_;
  std::unordered_set<std::string> allStatementTypes_;
  std::unordered_map<std::string, std::unordered_set<std::string>>
      statementTypes_;

  std::unordered_map<std::string, std::unordered_set<std::string>>
      statementItems_;
  std::unordered_map<std::string, std::unordered_set<std::string>>
      itemsReverseMap_;
};
