//
// Created by yeemi on 2/10/2024.
//

#include "ReadStatementNode.h"

#include <utility>

ReadStatementNode::ReadStatementNode(int statementNumber,
                                     std::shared_ptr<VariableNode> variableNode)
    : StatementNode(statementNumber, "read"),
      _variableNode(std::move(variableNode)) {}

ReadStatementNode::~ReadStatementNode() = default;

void ReadStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitReadStatementNode(
      std::make_shared<ReadStatementNode>(*this));
}

std::shared_ptr<VariableNode> ReadStatementNode::getVariableNode() {
  return _variableNode;
}
