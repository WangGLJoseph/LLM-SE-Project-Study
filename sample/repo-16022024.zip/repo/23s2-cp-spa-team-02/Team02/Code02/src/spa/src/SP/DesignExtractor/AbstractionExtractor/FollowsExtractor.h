//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../BaseExtractor.h"
#include <vector>

class FollowsExtractor : public BaseExtractor {
public:
  explicit FollowsExtractor(PKBWriteFacade &pkbWriteFacade);
  ~FollowsExtractor();

  void
  visitProcedureNode(std::shared_ptr<ProcedureNode> procedureNode) override;
  void visitStatementNodeList(
      const std::vector<std::shared_ptr<StatementNode>> &statementNodes);
  void visitConstantNode(std::shared_ptr<ConstantNode> constantNode) override;
  void visitVariableNode(std::shared_ptr<VariableNode> variableNode) override;
  void visitAssignStatementNode(
      std::shared_ptr<AssignStatementNode> assignStatementNode) override;
  void visitCallStatementNode(
      std::shared_ptr<CallStatementNode> callStatementNode) override;
  void visitIfStatementNode(
      std::shared_ptr<IfStatementNode> ifStatementNode) override;
  void visitPrintStatementNode(
      std::shared_ptr<PrintStatementNode> printStatementNode) override;
  void visitReadStatementNode(
      std::shared_ptr<ReadStatementNode> readStatementNode) override;
  void visitWhileStatementNode(
      std::shared_ptr<WhileStatementNode> whileStatementNode) override;
  void visitArithmeticExpressionNode(
      std::shared_ptr<ExpressionNode> arithmeticExpressionNode) override;
  void visitConditionalExpressionNode(
      std::shared_ptr<ExpressionNode> conditionalExpressionNode) override;
  void visitRelationalExpressionNode(
      std::shared_ptr<ExpressionNode> relationalExpressionNode) override;
  void
  extractFollows(std::vector<std::shared_ptr<StatementNode>> statementNodes);
  void visitProgramNode(std::shared_ptr<ProgramNode> programNode);
};
