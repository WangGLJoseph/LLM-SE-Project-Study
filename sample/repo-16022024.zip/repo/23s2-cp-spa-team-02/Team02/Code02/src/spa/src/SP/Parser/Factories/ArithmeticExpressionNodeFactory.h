//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "../ASTNodes/ArithmeticExpressionNode.h"
#include "ExpressionNodeFactory.h"

class ArithmeticExpressionNodeFactory : public ExpressionNodeFactory {
public:
  ArithmeticExpressionNodeFactory();
  ~ArithmeticExpressionNodeFactory();

  std::shared_ptr<ExpressionNode> createExpressionNode(Tokens &tokens) override;
};
