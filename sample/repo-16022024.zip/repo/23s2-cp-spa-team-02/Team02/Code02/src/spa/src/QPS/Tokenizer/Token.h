#pragma once
#include "TokenType.h"
#include <string>

class Token {
private:
  std::string value;
  TokenType type;

public:
  Token(std::string value, TokenType type);
  std::string getValue() const;
  TokenType getType() const;
};


