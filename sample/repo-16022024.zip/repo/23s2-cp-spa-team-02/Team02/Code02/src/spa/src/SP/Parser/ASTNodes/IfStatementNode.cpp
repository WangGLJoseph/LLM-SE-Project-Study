//
// Created by yeemi on 2/10/2024.
//

#include "IfStatementNode.h"

IfStatementNode::IfStatementNode(
    int statementNumber,
    std::shared_ptr<ExpressionNode> conditionalExpressionNode,
    std::vector<std::shared_ptr<StatementNode>> thenStatementNodes,
    std::vector<std::shared_ptr<StatementNode>> elseStatementNodes)
    : StatementNode(statementNumber, "if"),
      _conditionalExpressionNode(std::move(conditionalExpressionNode)),
      _thenStatementNodes(std::move(thenStatementNodes)),
      _elseStatementNodes(std::move(elseStatementNodes)) {}

IfStatementNode::~IfStatementNode() = default;

void IfStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitIfStatementNode(
      std::make_shared<IfStatementNode>(*this));
}

std::shared_ptr<ExpressionNode>
IfStatementNode::getConditionalExpressionNode() {
  return _conditionalExpressionNode;
}

std::vector<std::shared_ptr<StatementNode>>
IfStatementNode::getThenStatementNodes() {
  return _thenStatementNodes;
}

std::vector<std::shared_ptr<StatementNode>>
IfStatementNode::getElseStatementNodes() {
  return _elseStatementNodes;
}