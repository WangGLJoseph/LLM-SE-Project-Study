//
// Created by yeemi on 2/10/2024.
//

#include "StatementNode.h"

#include <utility>

StatementNode::StatementNode(int statementNumber, std::string statementType)
    : _statementNumber(statementNumber),
      _statementType(std::move(statementType)) {}

int StatementNode::getStatementNumber() const { return _statementNumber; }
std::string StatementNode::getStatementType() const { return _statementType; }