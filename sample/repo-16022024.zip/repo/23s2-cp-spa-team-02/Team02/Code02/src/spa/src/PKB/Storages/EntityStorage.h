//
// Created by Clement Kong on 7/2/24.
//
#pragma once
#include <string>
#include <unordered_map>
#include <unordered_set>

class EntityStorage {
public:
  EntityStorage();
  ~EntityStorage();

  void addVariable(const std::string &varName);
  void addConstant(const std::string &constVal);
  void addProcedure(const std::string &procName);

  const std::unordered_set<std::string> &getVariables();
  const std::unordered_set<std::string> &getConstants();
  const std::unordered_set<std::string> &getProcedures();

private:
  std::unordered_set<std::string> variableStorage_;
  std::unordered_set<std::string> constantStorage_;
  std::unordered_set<std::string> procedureStorage_;
};
