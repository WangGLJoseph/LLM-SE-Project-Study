//
// Created by yeemi on 2/8/2024.
//

#include "UsesExtractor.h"

UsesExtractor::UsesExtractor(PKBWriteFacade &pkbWriteFacade)
    : BaseExtractor(pkbWriteFacade) {}

UsesExtractor::~UsesExtractor() = default;

void UsesExtractor::visitProgramNode(std::shared_ptr<ProgramNode> programNode) {
}
