//
// Created by yeemi on 2/10/2024.
//

#include "AssignStatementNodeFactory.h"
#include "NodeFactory.h"

AssignStatementNodeFactory::AssignStatementNodeFactory() = default;

AssignStatementNodeFactory::~AssignStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
AssignStatementNodeFactory::createStatementNode(Tokens &tokens) {
  std::shared_ptr<VariableNode> variableNode =
      NodeFactory::createVariableNode(tokens);

  // Skip "=" assign operator
  tokens.increaseIndex(1);

  std::shared_ptr<ExpressionNode> arithmeticExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::ARITHMETIC);

  AssignStatementNode assignStatementNode =
      AssignStatementNode(NodeFactory::getStatementNumber(), variableNode,
                          arithmeticExpressionNode);

  return std::make_shared<AssignStatementNode>(assignStatementNode);
}