//
// Created by yeemi on 2/8/2024.
//

#include "BaseExtractor.h"

BaseExtractor::BaseExtractor(PKBWriteFacade &pkbWriteFacade)
    : _pkbWriteFacade(pkbWriteFacade) {}

PKBWriteFacade BaseExtractor::getPKBWriteFacade() { return _pkbWriteFacade; }