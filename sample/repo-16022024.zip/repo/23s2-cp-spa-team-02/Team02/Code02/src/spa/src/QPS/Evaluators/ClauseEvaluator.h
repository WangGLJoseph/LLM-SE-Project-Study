#pragma once

#include "PKB/API/PKBReadFacade.h"
#include "QPS/Result.h"

class ClauseEvaluator {

public:
  explicit ClauseEvaluator(PKBReadFacade& pkb) : pkb_(pkb) {};
  virtual ~ClauseEvaluator() = default;

protected:
  PKBReadFacade& pkb_;
};
