//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/DesignExtractor/ExtractorVisitor.h"

class Node {
public:
  ~Node();
  virtual void accept(ExtractorVisitor *extractorVisitor) = 0;
};
