//
// Created by yeemi on 2/12/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/VariableNode.h"
#include "SP/Tokenizer/Tokens.h"

class VariableNodeFactory {
public:
  VariableNodeFactory();
  ~VariableNodeFactory();

  std::shared_ptr<VariableNode> createVariableNode(Tokens &tokens);
};
