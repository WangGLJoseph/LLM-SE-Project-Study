#include "QueryTokenizer.h"

void QueryTokenizer::tokenize(const std::string& query) {
  // TODO: update implementation to be similar to SP tokenizer and use lexical tokens
  std::regex tokenPatterns(
      "(\\bSelect\\b)|(\\bsuch\\s+that\\b)|(\\bpattern\\b)|(\\bassign\\b)|"
      "(\\bvariable\\b)|([a-zA-Z0-9_][a-zA-Z0-9_]*)|([;])|(\\s+)|(\\()|(\\))");

  auto wordsBegin = std::sregex_iterator(query.begin(), query.end(), tokenPatterns);
  auto wordsEnd = std::sregex_iterator();

  tokens.clear();

  for (std::sregex_iterator i = wordsBegin; i != wordsEnd; ++i) {
    const std::smatch& match = *i;
    TokenType type = determineTokenType(match);
    if (type != TokenType::UNKNOWN && type != TokenType::WHITESPACE) {
      tokens.emplace_back(match.str(), type);
    }
  }
}

TokenType QueryTokenizer::determineTokenType(const std::smatch& match) {
  if (match[1].matched) return TokenType::SELECT;
  if (match[2].matched) return TokenType::SUCH_THAT;
  if (match[3].matched) return TokenType::PATTERN;
  if (match[4].matched) return TokenType::ASSIGN;
  if (match[5].matched) return TokenType::VARIABLE;
  if (match[6].matched) return TokenType::IDENTIFIER;
  if (match[7].matched) return TokenType::SYMBOL;
  if (match[8].matched) return TokenType::WHITESPACE;
  if (match[9].matched) return TokenType::PAREN_OPEN;
  if (match[10].matched) return TokenType::PAREN_CLOSE;
  return TokenType::UNKNOWN;
}
