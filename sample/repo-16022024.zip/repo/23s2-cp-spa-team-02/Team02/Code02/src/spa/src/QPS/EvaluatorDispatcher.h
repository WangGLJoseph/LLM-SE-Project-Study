#pragma once

#include "PKB/API/PKBReadFacade.h"

#include "QPS/Query.h"
#include "QPS/Evaluators/FollowsClauseEvaluator.h"

class EvaluatorDispatcher {

public:
  explicit EvaluatorDispatcher(PKBReadFacade& pkb) : followsEvaluator_(pkb) {};
  virtual ~EvaluatorDispatcher() {};

  Result dispatchClause(const StClause& stClause);

  Result dispatchClause(const PatternClause& patternClause);

private:
  FollowsClauseEvaluator followsEvaluator_;
};
