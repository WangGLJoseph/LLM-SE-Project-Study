#pragma once

#include "QPS/Query.h"
#include "QPS/Evaluators/ClauseEvaluator.h"


class FollowsClauseEvaluator : public ClauseEvaluator {

public:
  explicit FollowsClauseEvaluator(PKBReadFacade& pkb) : ClauseEvaluator(pkb) {};

  Result evaluate(const StClause& stClause);

};
