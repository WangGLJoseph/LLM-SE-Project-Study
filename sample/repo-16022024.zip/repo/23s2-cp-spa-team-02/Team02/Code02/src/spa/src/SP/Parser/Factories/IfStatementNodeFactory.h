//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class IfStatementNodeFactory : public StatementNodeFactory {
public:
  IfStatementNodeFactory();
  ~IfStatementNodeFactory();

  std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens) override;
};
