//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ConditionalExpressionNode.h"
#include "StatementNode.h"
#include <vector>

class WhileStatementNode : public StatementNode {
private:
  std::shared_ptr<ExpressionNode> _conditionalExpressionNode;
  std::vector<std::shared_ptr<StatementNode>> _statementNodes;

public:
  explicit WhileStatementNode(
      int statementNumber,
      std::shared_ptr<ExpressionNode> conditionalExpressionNode,
      std::vector<std::shared_ptr<StatementNode>> statementNodes);
  ~WhileStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::shared_ptr<ExpressionNode> getConditionalExpressionNode();
  std::vector<std::shared_ptr<StatementNode>> getStatementNodes();
};