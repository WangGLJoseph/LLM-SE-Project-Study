//
// Created by yeemi on 2/12/2024.
//

#include "VariableNodeFactory.h"

VariableNodeFactory::VariableNodeFactory() = default;

VariableNodeFactory::~VariableNodeFactory() = default;

std::shared_ptr<VariableNode>
VariableNodeFactory::createVariableNode(Tokens &tokens) {
  TokenSP variable = tokens.getNextToken();
  return std::make_shared<VariableNode>(variable.getValue());
}
