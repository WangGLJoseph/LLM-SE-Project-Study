//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "StatementNode.h"
#include "VariableNode.h"

class ReadStatementNode : public StatementNode {
private:
  std::shared_ptr<VariableNode> _variableNode;

public:
  explicit ReadStatementNode(int statementNumber,
                             std::shared_ptr<VariableNode> variableNode);
  ~ReadStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::shared_ptr<VariableNode> getVariableNode();
};