#include "Query.h"

Query::Query(std::string &selectedSynonym,
             std::unordered_map<std::string, EntityType> &synonymMap,
             std::vector<StClause> &stClauses,
             std::vector<PatternClause> &patternClauses)
    : selectedSynonym_(selectedSynonym), synonymMap_(synonymMap),
      stClauses_(stClauses), patternClauses_(patternClauses) {}

