//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ExpressionNode.h"

class RelationalExpressionNode : public ExpressionNode {
public:
  void accept(ExtractorVisitor *extractorVisitor) override;
};