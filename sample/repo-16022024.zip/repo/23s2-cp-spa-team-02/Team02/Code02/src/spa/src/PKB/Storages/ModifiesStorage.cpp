//
// Created by Clement Kong on 7/2/24.
//
#include "ModifiesStorage.h"

ModifiesStorage::ModifiesStorage() = default;
ModifiesStorage::~ModifiesStorage() = default;