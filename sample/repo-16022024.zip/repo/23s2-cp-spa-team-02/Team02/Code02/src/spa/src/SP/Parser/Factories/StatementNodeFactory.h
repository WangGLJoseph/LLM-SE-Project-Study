//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ExpressionTypes.h"
#include "SP/Parser/ASTNodes/StatementNode.h"
#include "SP/Tokenizer/TokenType.h"
#include "SP/Tokenizer/Tokens.h"
#include <memory>

class StatementNodeFactory {
public:
  StatementNodeFactory();
  ~StatementNodeFactory();

  virtual std::shared_ptr<StatementNode>
  createStatementNode(Tokens &tokens) = 0;
};
