//
// Created by yeemi on 2/8/2024.
//

#include "FollowsExtractor.h"
#include "SP/Parser/ASTNodes/IfStatementNode.h"
#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Parser/ASTNodes/WhileStatementNode.h"

FollowsExtractor::FollowsExtractor(PKBWriteFacade &pkbWriteFacade)
    : BaseExtractor(pkbWriteFacade) {}

FollowsExtractor::~FollowsExtractor() = default;

void FollowsExtractor::visitProcedureNode(
    std::shared_ptr<ProcedureNode> procedureNode) {
  extractFollows(procedureNode->getStatementNodes());
  visitStatementNodeList(procedureNode->getStatementNodes());
}

void FollowsExtractor::visitStatementNodeList(
    const std::vector<std::shared_ptr<StatementNode>> &statementNodes) {
  for (const auto &statementNode : statementNodes) {
    statementNode->accept(this);
  }
}

void FollowsExtractor::visitConstantNode(
    std::shared_ptr<ConstantNode> constantNode) {}

void FollowsExtractor::visitVariableNode(
    std::shared_ptr<VariableNode> variableNode) {}

void FollowsExtractor::visitAssignStatementNode(
    std::shared_ptr<AssignStatementNode> assignStatementNode) {}

void FollowsExtractor::visitCallStatementNode(
    std::shared_ptr<CallStatementNode> callStatementNode) {}

void FollowsExtractor::visitIfStatementNode(
    std::shared_ptr<IfStatementNode> ifStatementNode) {
  extractFollows(ifStatementNode->getThenStatementNodes());
  extractFollows(ifStatementNode->getElseStatementNodes());
  visitStatementNodeList(ifStatementNode->getThenStatementNodes());
  visitStatementNodeList(ifStatementNode->getElseStatementNodes());
}

void FollowsExtractor::visitPrintStatementNode(
    std::shared_ptr<PrintStatementNode> printStatementNode) {}

void FollowsExtractor::visitReadStatementNode(
    std::shared_ptr<ReadStatementNode> readStatementNode) {}

void FollowsExtractor::visitWhileStatementNode(
    std::shared_ptr<WhileStatementNode> whileStatementNode) {
  extractFollows(whileStatementNode->getStatementNodes());
  visitStatementNodeList(whileStatementNode->getStatementNodes());
}

void FollowsExtractor::visitArithmeticExpressionNode(
    std::shared_ptr<ExpressionNode> arithmeticExpressionNode) {}

void FollowsExtractor::visitConditionalExpressionNode(
    std::shared_ptr<ExpressionNode> conditionalExpressionNode) {}

void FollowsExtractor::visitRelationalExpressionNode(
    std::shared_ptr<ExpressionNode> relationalExpressionNode) {}

void FollowsExtractor::extractFollows(
    std::vector<std::shared_ptr<StatementNode>> statementNodes) {
  if (statementNodes.size() <= 1)
    return;

  for (size_t i = 0; i < statementNodes.size() - 1; i++) {
    std::string stmtNum1 =
        std::to_string(statementNodes[i]->getStatementNumber());
    std::string stmtNum2 =
        std::to_string(statementNodes[i + 1]->getStatementNumber());
    getPKBWriteFacade().addFollows(stmtNum1, stmtNum2);
  }
}

void FollowsExtractor::visitProgramNode(
    std::shared_ptr<ProgramNode> programNode) {}