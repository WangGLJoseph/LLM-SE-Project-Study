//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ExpressionNode.h"

class ArithmeticExpressionNode : public ExpressionNode {

public:
  ArithmeticExpressionNode(
      std::vector<std::shared_ptr<VariableNode>> variables,
      std::vector<std::shared_ptr<ConstantNode>> constants);
  ~ArithmeticExpressionNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
};