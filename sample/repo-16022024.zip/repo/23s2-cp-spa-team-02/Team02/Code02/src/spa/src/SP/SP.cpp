//
// Created by yeemi on 2/6/2024.
//

#include "SP.h"
#include "Tokenizer/Tokens.h"

void SP::parseSourceProgram(std::istream &sourceProgram,
                            PKBWriteFacade &pkbWriteFacade) {
  // Tokenize
  auto tokenizer = Tokenizer(sourceProgram);
  Tokens tokens = tokenizer.tokenize();

  // Build AST
  ProgramNode AST = Parser::parseTokens(tokens);

  // Extract
  DesignExtractorManager designExtractor =
      DesignExtractorManager(AST, pkbWriteFacade);
  designExtractor.extractData();
}
