//
// Created by yeemi on 2/10/2024.
//

#include "ConstantNode.h"

#include <utility>

ConstantNode::ConstantNode(std::string name) : _name(std::move(name)) {}

ConstantNode::~ConstantNode() = default;

void ConstantNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitConstantNode(std::make_shared<ConstantNode>(*this));
}
std::string ConstantNode::getName() { return _name; }
