//
// Created by yeemi on 2/8/2024.
//

#include "ModifiesExtractor.h"

ModifiesExtractor::ModifiesExtractor(PKBWriteFacade &pkbWriteFacade)
    : BaseExtractor(pkbWriteFacade) {}
ModifiesExtractor::~ModifiesExtractor() = default;

void ModifiesExtractor::visitProgramNode(
    std::shared_ptr<ProgramNode> programNode) {}