//
// Created by yeemi on 2/8/2024.
//

#include "DesignExtractorManager.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"

#include <utility>

DesignExtractorManager::DesignExtractorManager(const ProgramNode &AST,
                                               PKBWriteFacade &pkbWriteFacade)
    : _ast(AST), _pkbWriteFacade(pkbWriteFacade) {}

DesignExtractorManager::~DesignExtractorManager() = default;

void DesignExtractorManager::extractData() {
  // extract entities
  EntityExtractor entityExtractor = EntityExtractor(getPKBWriteFacade());
  getAST().accept(&entityExtractor);

  // follows entities
  FollowsExtractor followsExtractor = FollowsExtractor(getPKBWriteFacade());
  getAST().accept(&followsExtractor);

  // parent entities
//  ParentExtractor parentExtractor = ParentExtractor(getPKBWriteFacade());
//  getAST().accept(&parentExtractor);
//
//  // extract entities
//  ModifiesExtractor modifiesExtractor = ModifiesExtractor(getPKBWriteFacade());
//  getAST().accept(&modifiesExtractor);
//
//  // extract entities
//  UsesExtractor usesExtractor = UsesExtractor(getPKBWriteFacade());
//  getAST().accept(&usesExtractor);
}

ProgramNode DesignExtractorManager::getAST() { return _ast; }
PKBWriteFacade &DesignExtractorManager::getPKBWriteFacade() {
  return _pkbWriteFacade;
}
