//
// Created by yeemi on 2/10/2024.
//

#include "RelationalExpressionNode.h"
void RelationalExpressionNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitRelationalExpressionNode(
      std::make_shared<RelationalExpressionNode>(*this));
}