//
// Created by yeemi on 2/6/2024.
//

#pragma once

#include "DesignExtractor/BaseExtractor.h"
#include "DesignExtractor/DesignExtractorManager.h"
#include "Parser/Parser.h"
#include "Tokenizer/Tokenizer.h"
#include "Tokenizer/Tokens.h"
#include <string>

class SP {
public:
  void parseSourceProgram(std::istream &sourceProgram,
                          PKBWriteFacade &pkbWriteFacade);
};
