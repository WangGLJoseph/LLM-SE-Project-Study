//
// Created by yeemi on 2/10/2024.
//

#include "AssignStatementNode.h"

#include <utility>
AssignStatementNode::AssignStatementNode(
    int statementNumber, std::shared_ptr<VariableNode> variableNode,
    std::shared_ptr<ExpressionNode> arithmeticExpressionNode)
    : StatementNode(statementNumber, "assign"),
      _variableNode(std::move(variableNode)),
      _arithmeticExpressionNode(std::move(arithmeticExpressionNode)) {}

AssignStatementNode::~AssignStatementNode() = default;

void AssignStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitAssignStatementNode(
      std::make_shared<AssignStatementNode>(*this));
}

std::shared_ptr<VariableNode> AssignStatementNode::getVariableNode() {
  return _variableNode;
}

std::shared_ptr<ExpressionNode>
AssignStatementNode::getArithmeticExpressionNode() {
  return _arithmeticExpressionNode;
}
