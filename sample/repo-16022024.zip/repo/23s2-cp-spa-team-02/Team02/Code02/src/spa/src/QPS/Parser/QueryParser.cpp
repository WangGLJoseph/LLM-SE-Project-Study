#include "QueryParser.h"

std::string QueryParser::removeWhitespaces(const std::string &query) {
  return std::regex_replace(query, std::regex("\\s+"), " ");
}

std::pair<std::string, std::string>
QueryParser::getClauseArgs(const std::vector<Token> &tokens, size_t &index) {
  std::pair<std::string, std::string> args;
  // TODO: syntax and semantic validation
  //  if (tokens[index].getType() != TokenType::PAREN_OPEN) return args;
  bool hasFirstArg = false;
  while (index < tokens.size()) {
    if (tokens[index].getType() == TokenType::PAREN_CLOSE) {
      break;
    }
    if (tokens[index].getType() != TokenType::PAREN_OPEN &&
        tokens[index].getType() != TokenType::PAREN_CLOSE &&
        tokens[index].getValue() != ",") {
      if (!hasFirstArg) {
        args.first = tokens[index].getValue();
        hasFirstArg = true;
      } else {
        args.second = tokens[index].getValue();
      }
    }
    ++index;
  }
  return args;
}

Query QueryParser::parseQuery(const std::string &query) {
  tokenizer.tokenize(removeWhitespaces(query));
//  for (size_t i = 0; i < tokenizer.tokens.size(); ++i) {
//    std::cout << tokenizer.tokens[i].getValue() << std::endl;
//  }

  /*
   * Extract "Select" synonym,
   * suchthat-cl relationship and args,
   * pattern-cl syn-assign and args
   * TODO: map from TokenType to EntityType
   */
  std::string selectedSynonym;
  std::unordered_map<std::string, EntityType> synonymMap;
  std::vector<StClause> stClauses;
  std::vector<PatternClause> patternClauses;

  // TODO: validation
  for (size_t i = 0; i < tokenizer.tokens.size(); ++i) {
    if (tokenizer.tokens[i].getType() == TokenType::SELECT) {
      // Assuming immediate next token is synonym
      selectedSynonym = tokenizer.tokens[++i].getValue();
    } else if (tokenizer.tokens[i].getType() == TokenType::SUCH_THAT) {
      // Process suchthat-cl
      std::string rel = tokenizer.tokens[++i].getValue();
      std::pair<std::string, std::string> relArgs =
          getClauseArgs(tokenizer.tokens, ++i);
      StClause stClause(tokenValToRelRef.at(rel), relArgs.first,
                        relArgs.second);
      stClauses.push_back(stClause);
    } else if (tokenizer.tokens[i].getType() == TokenType::PATTERN) {
      // Process pattern-cl
      std::string patSynonym = tokenizer.tokens[++i].getValue();
      std::pair<std::string, std::string> patArgs =
          getClauseArgs(tokenizer.tokens, ++i);
      PatternClause patternClause(patSynonym, patArgs.first, patArgs.second);
      patternClauses.push_back(patternClause);
    } else if (tokenizer.tokens[i].getType() == TokenType::SYMBOL) {
      std::string synonym = tokenizer.tokens[i - 1].getValue();
      std::string entityType = tokenizer.tokens[i - 2].getValue();
      // TODO: mapping;
      synonymMap[synonym] = tokenValToEntityType.at(entityType);
    }
  }
  Query queryRep(selectedSynonym, synonymMap, stClauses, patternClauses);
  return queryRep;
}
