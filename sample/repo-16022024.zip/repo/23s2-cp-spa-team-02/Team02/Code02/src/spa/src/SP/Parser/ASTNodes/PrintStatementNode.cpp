//
// Created by yeemi on 2/10/2024.
//

#include "PrintStatementNode.h"

#include <utility>

PrintStatementNode::PrintStatementNode(
    int statementNumber, std::shared_ptr<VariableNode> variableNode)
    : StatementNode(statementNumber, "print"),
      _variableNode(std::move(variableNode)) {}

PrintStatementNode::~PrintStatementNode() = default;

void PrintStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitPrintStatementNode(
      std::make_shared<PrintStatementNode>(*this));
}

std::shared_ptr<VariableNode> PrintStatementNode::getVariableNode() {
  return _variableNode;
}
