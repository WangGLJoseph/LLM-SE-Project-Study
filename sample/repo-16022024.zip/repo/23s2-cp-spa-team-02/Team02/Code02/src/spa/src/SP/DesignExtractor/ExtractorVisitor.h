//
// Created by yeemi on 2/6/2024.
//

#pragma once

#include <memory>

class ProgramNode;
class ProcedureNode;

class ConstantNode;
class VariableNode;

class ExpressionNode;
class ArithmeticExpressionNode;
class ConditionalExpressionNode;
class RelationalExpressionNode;

class StatementNode;
class AssignStatementNode;
class CallStatementNode;
class IfStatementNode;
class PrintStatementNode;
class ReadStatementNode;
class WhileStatementNode;

class ExtractorVisitor {
public:
  virtual void
  visitConstantNode(std::shared_ptr<ConstantNode> constantNode) = 0;
  virtual void
  visitVariableNode(std::shared_ptr<VariableNode> variableNode) = 0;
  virtual void visitArithmeticExpressionNode(
      std::shared_ptr<ExpressionNode> arithmeticExpressionNode) = 0;
  virtual void visitConditionalExpressionNode(
      std::shared_ptr<ExpressionNode> conditionalExpressionNode) = 0;
  virtual void visitRelationalExpressionNode(
      std::shared_ptr<ExpressionNode> relationalExpressionNode) = 0;
  virtual void visitAssignStatementNode(
      std::shared_ptr<AssignStatementNode> assignStatementNode) = 0;
  virtual void visitCallStatementNode(
      std::shared_ptr<CallStatementNode> callStatementNode) = 0;
  virtual void
  visitIfStatementNode(std::shared_ptr<IfStatementNode> ifStatementNode) = 0;
  virtual void visitPrintStatementNode(
      std::shared_ptr<PrintStatementNode> printStatementNode) = 0;
  virtual void visitReadStatementNode(
      std::shared_ptr<ReadStatementNode> readStatementNode) = 0;
  virtual void visitWhileStatementNode(
      std::shared_ptr<WhileStatementNode> whileStatementNode) = 0;
  virtual void visitProgramNode(std::shared_ptr<ProgramNode> programNode) = 0;
  virtual void
  visitProcedureNode(std::shared_ptr<ProcedureNode> procedureNode) = 0;
};