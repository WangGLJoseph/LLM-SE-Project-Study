//
// Created by yeemi on 2/10/2024.
//

#include "ArithmeticExpressionNode.h"

#include <utility>

ArithmeticExpressionNode::ArithmeticExpressionNode(
    std::vector<std::shared_ptr<VariableNode>> variables,
    std::vector<std::shared_ptr<ConstantNode>> constants)
    : ExpressionNode(std::move(variables), std::move(constants)) {}

ArithmeticExpressionNode::~ArithmeticExpressionNode() = default;

void ArithmeticExpressionNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitArithmeticExpressionNode(
      std::make_shared<ArithmeticExpressionNode>(*this));
}
