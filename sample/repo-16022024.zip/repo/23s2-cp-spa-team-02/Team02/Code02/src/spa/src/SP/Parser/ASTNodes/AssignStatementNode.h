//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "ArithmeticExpressionNode.h"
#include "StatementNode.h"
#include "VariableNode.h"
#include <vector>

class AssignStatementNode : public StatementNode {
private:
  std::shared_ptr<VariableNode> _variableNode;
  std::shared_ptr<ExpressionNode> _arithmeticExpressionNode;

public:
  explicit AssignStatementNode(
      int statementNumber, std::shared_ptr<VariableNode> variableNode,
      std::shared_ptr<ExpressionNode> arithmeticExpressionNode);
  ~AssignStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::shared_ptr<VariableNode> getVariableNode();
  std::shared_ptr<ExpressionNode> getArithmeticExpressionNode();
};