//
// Created by yeemi on 2/10/2024.
//

#include "ArithmeticExpressionNodeFactory.h"
#include "NodeFactory.h"

ArithmeticExpressionNodeFactory::ArithmeticExpressionNodeFactory() = default;

ArithmeticExpressionNodeFactory::~ArithmeticExpressionNodeFactory() = default;

std::shared_ptr<ExpressionNode>
ArithmeticExpressionNodeFactory::createExpressionNode(Tokens &tokens) {
  int semicolonIndex = tokens.getSemicolonIndex();
  std::vector<std::shared_ptr<VariableNode>> variableNodes;
  std::vector<std::shared_ptr<ConstantNode>> constantNodes;
  while (tokens.getIndex() < semicolonIndex) {
    TokenTypeSP type = tokens.peekHead();
    switch (type) {
    case TokenTypeSP::NAME:
      variableNodes.push_back(NodeFactory::createVariableNode(tokens));
      break;
    case TokenTypeSP::INTEGER:
      constantNodes.push_back(NodeFactory::createConstantNode(tokens));
      break;
    default:
      // Skip non-variable and non-constants
      tokens.increaseIndex(1);
      break;
    }
  }

  // Skip the ";" semicolon
  tokens.increaseIndex(1);

  return std::make_shared<ArithmeticExpressionNode>(variableNodes,
                                                    constantNodes);
}
