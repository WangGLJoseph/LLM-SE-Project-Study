//
// Created by Clement Kong on 6/2/24.
//
#pragma once
#include "PKB/PKB.h"

class PKBWriteFacade {
private:
  PKB &pkb_;

public:
  explicit PKBWriteFacade(PKB &pkb);

  ~PKBWriteFacade();

  void addProcedure(const std::string &procName);

  void addVariable(const std::string &varName);

  void addConstant(const std::string &constName);

  void addFollows(const std::string &statement1, const std::string &statement2);

  void addStatementWithType(const std::string &stmtNumber,
                            const std::string &stmtType);

  void addStatementMetadata(const std::string &stmtNumber,
                          std::unordered_set<std::string> &metadata);

  //    void addFollowsStar(const std::string& statement1, const std::string&
  //    statement2);
};
