//
// Created by Evan Chng on 6/2/24.
//

#include "TokenFactory.h"
#include "TokenSP.h"
#include <iostream>

bool TokenFactory::isIntegerToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::INTEGER;
}

bool TokenFactory::isRelationalToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::LESS_THAN ||
         tokenType == TokenTypeSP::LESS_THAN_OR_EQUALS ||
         tokenType == TokenTypeSP::GREATER_THAN ||
         tokenType == TokenTypeSP::GREATER_THAN_OR_EQUALS ||
         tokenType == TokenTypeSP::DOUBLE_EQUALS ||
         tokenType == TokenTypeSP::NOT_EQUALS;
}

bool TokenFactory::isArithmeticOperatorToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::PLUS || tokenType == TokenTypeSP::MINUS ||
         tokenType == TokenTypeSP::TIMES || tokenType == TokenTypeSP::DIVIDE ||
         tokenType == TokenTypeSP::MODULO;
}

bool TokenFactory::isConditionalOperatorToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::NOT || tokenType == TokenTypeSP::AND ||
         tokenType == TokenTypeSP::OR;
}

bool TokenFactory::isPunctuationToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::LEFT_PARENTHESIS ||
         tokenType == TokenTypeSP::RIGHT_PARENTHESIS ||
         tokenType == TokenTypeSP::LEFT_CURLY_BRACKET ||
         tokenType == TokenTypeSP::RIGHT_CURLY_BRACKET ||
         tokenType == TokenTypeSP::SEMICOLON;
}

bool TokenFactory::isIdentifierToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::NAME || tokenType == TokenTypeSP::PRINT ||
         tokenType == TokenTypeSP::PROCEDURE || tokenType == TokenTypeSP::WHILE ||
         tokenType == TokenTypeSP::READ || tokenType == TokenTypeSP::IF;
}

bool TokenFactory::isAssignToken(TokenTypeSP tokenType) {
  return tokenType == TokenTypeSP::ASSIGN;
}

TokenSP TokenFactory::createToken(TokenTypeSP tokenType, const std::string &value) {
  return {tokenType, value};
}
