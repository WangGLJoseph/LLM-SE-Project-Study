//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/CallStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class CallStatementNodeFactory : public StatementNodeFactory {
public:
  CallStatementNodeFactory();
  ~CallStatementNodeFactory();

  std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens) override;
};
