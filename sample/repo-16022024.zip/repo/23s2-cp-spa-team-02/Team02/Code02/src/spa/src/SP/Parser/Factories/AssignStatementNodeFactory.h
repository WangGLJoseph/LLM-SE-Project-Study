//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/AssignStatementNode.h"
#include "SP/Parser/Factories/StatementNodeFactory.h"
#include <memory>

class AssignStatementNodeFactory : public StatementNodeFactory {
public:
  AssignStatementNodeFactory();
  ~AssignStatementNodeFactory();

  std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens) override;
};