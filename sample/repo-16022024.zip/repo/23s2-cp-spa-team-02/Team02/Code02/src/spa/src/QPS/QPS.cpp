#include "QPS.h"

std::unordered_set<std::string> QPS::processQuery(const std::string& query) {

  Query queryFromParser = parser.parseQuery(query);
  Result result{};

  if (queryFromParser.stClauses_.empty()) {
    auto set = pkb_.getStatements();
    return set;
  }

  for (auto& clause: queryFromParser.stClauses_) {
    result = evaluator_.dispatchClause(clause);
  }

  return result.getSynonym(queryFromParser.selectedSynonym_);
}