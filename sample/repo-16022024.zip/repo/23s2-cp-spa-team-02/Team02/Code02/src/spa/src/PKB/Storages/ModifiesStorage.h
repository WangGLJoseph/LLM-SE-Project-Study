//
// Created by Clement Kong on 7/2/24.
//
#pragma once
#include <string>
#include <unordered_set>

class ModifiesStorage {
public:
  ModifiesStorage();
  ~ModifiesStorage();

private:
};
