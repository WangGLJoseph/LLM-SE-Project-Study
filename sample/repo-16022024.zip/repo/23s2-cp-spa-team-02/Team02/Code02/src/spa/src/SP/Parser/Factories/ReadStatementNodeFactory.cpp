//
// Created by yeemi on 2/10/2024.
//

#include "ReadStatementNodeFactory.h"
#include "NodeFactory.h"

ReadStatementNodeFactory::ReadStatementNodeFactory() = default;

ReadStatementNodeFactory::~ReadStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
ReadStatementNodeFactory::createStatementNode(Tokens &tokens) {
  // Skip the read keyword
  tokens.increaseIndex(1);

  std::shared_ptr<VariableNode> variableNode =
      NodeFactory::createVariableNode(tokens);

  // Skip the ";" semicolon
  tokens.increaseIndex(1);
  return std::make_shared<ReadStatementNode>(NodeFactory::getStatementNumber(),
                                             variableNode);
}
