//
// Created by yeemi on 2/8/2024.
//

#pragma once

#include "../../PKB/API/PKBWriteFacade.h"
#include "AbstractionExtractor/FollowsExtractor.h"
//#include "AbstractionExtractor/ModifiesExtractor.h"
//#include "AbstractionExtractor/ParentExtractor.h"
//#include "AbstractionExtractor/UsesExtractor.h"
#include "EntityExtractor.h"
#include "SP/Parser/ASTNodes/ProgramNode.h"

class DesignExtractorManager {
private:
  PKBWriteFacade &_pkbWriteFacade;
  ProgramNode _ast;

public:
  explicit DesignExtractorManager(const ProgramNode &AST,
                                  PKBWriteFacade &pkbWriteFacade);
  ~DesignExtractorManager();

  void extractData();
  ProgramNode getAST();
  PKBWriteFacade &getPKBWriteFacade();
};
