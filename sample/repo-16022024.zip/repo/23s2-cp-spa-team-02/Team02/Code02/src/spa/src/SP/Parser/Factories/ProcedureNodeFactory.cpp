//
// Created by yeemi on 2/10/2024.
//

#include "ProcedureNodeFactory.h"
#include "NodeFactory.h"

ProcedureNodeFactory::ProcedureNodeFactory() = default;

ProcedureNodeFactory::~ProcedureNodeFactory() = default;

std::shared_ptr<ProcedureNode>
ProcedureNodeFactory::createProcedureNode(Tokens &tokens) {
  // Skip procedure keyword
  tokens.increaseIndex(1);
  std::string procedureName = tokens.getNextToken().getValue();
  // Skip "{"
  tokens.increaseIndex(1);
  std::vector<std::shared_ptr<StatementNode>> statementNodes;
  while (!tokens.isEmpty()) {
    std::shared_ptr<StatementNode> statementNode =
        NodeFactory::createStatementNode(tokens);
    statementNodes.push_back(statementNode);
  }
  std::shared_ptr<ProcedureNode> procedureNode =
      std::make_shared<ProcedureNode>(statementNodes, procedureName);
  return procedureNode;
}
