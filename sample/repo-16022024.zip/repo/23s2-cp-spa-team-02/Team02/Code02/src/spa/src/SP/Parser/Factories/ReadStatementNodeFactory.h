//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ReadStatementNode.h"
#include "StatementNodeFactory.h"
#include <memory>

class ReadStatementNodeFactory : public StatementNodeFactory {
public:
  ReadStatementNodeFactory();
  ~ReadStatementNodeFactory();

  std::shared_ptr<StatementNode> createStatementNode(Tokens &tokens) override;
};