//
// Created by yeemi on 2/10/2024.
//

#include "CallStatementNode.h"

#include <utility>

CallStatementNode::CallStatementNode(int statementNumber,
                                     std::string procedureName)
    : StatementNode(statementNumber, "call"),
      _procedureName(std::move(procedureName)) {}

CallStatementNode::~CallStatementNode() = default;

void CallStatementNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitCallStatementNode(
      std::make_shared<CallStatementNode>(*this));
}

std::string CallStatementNode::getProcedureName() { return _procedureName; }
