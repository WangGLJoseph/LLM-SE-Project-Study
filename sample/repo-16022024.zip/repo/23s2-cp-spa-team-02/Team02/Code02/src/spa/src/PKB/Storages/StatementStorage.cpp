//
// Created by Clement Kong on 7/2/24.
//
#include "StatementStorage.h"

StatementStorage::StatementStorage() = default;
StatementStorage::~StatementStorage() = default;

// Add stmtNum to allStatementStorage_
// Add stmtType into allStatementTypes_ if type not added yet
// CALL THIS FOR ALL STATEMENTS ADDED
void StatementStorage::addStatementWithType(const std::string &stmtNumber,
                                            const std::string &stmtType) {
  this->statementTypes_[stmtType].insert(stmtNumber);
  allStatementStorage_.insert(stmtNumber);
  allStatementTypes_.insert(stmtType);
}

// Add statement meta - <stmtNum, metadata> into statementItems_
// & vice versa for the itemsReverseMap
// CALL THIS IF THERE ARE STATEMENT FIELDS TO ADD (all variables left or right
// should be in metadata)
void StatementStorage::addStatementMetadata(
    const std::string &stmtNumber,
    std::unordered_set<std::string> &metadata) {
  this->statementItems_.insert({stmtNumber, metadata});
  for (auto &it : metadata) {
    itemsReverseMap_[it].insert(stmtNumber);
  }
}

const std::unordered_set<std::string> &StatementStorage::getStatements() {
  return this->allStatementStorage_;
}

const std::unordered_set<std::string> &
StatementStorage::getStatementsWithType(const std::string &stmtType) {
  return this->statementTypes_[stmtType];
}

const std::unordered_set<std::string> &
StatementStorage::getStatementsWithMetadata(const std::string &metadata) {
  return this->itemsReverseMap_[metadata];
}