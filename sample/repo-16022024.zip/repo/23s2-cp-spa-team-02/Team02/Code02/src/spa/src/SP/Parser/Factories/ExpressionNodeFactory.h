//
// Created by yeemi on 2/12/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ExpressionNode.h"
#include "SP/Parser/ASTNodes/ExpressionTypes.h"
#include "SP/Tokenizer/TokenType.h"
#include "SP/Tokenizer/Tokens.h"
#include <memory>

class ExpressionNodeFactory {
public:
  ExpressionNodeFactory();
  ~ExpressionNodeFactory();

  virtual std::shared_ptr<ExpressionNode>
  createExpressionNode(Tokens &tokens) = 0;
};
