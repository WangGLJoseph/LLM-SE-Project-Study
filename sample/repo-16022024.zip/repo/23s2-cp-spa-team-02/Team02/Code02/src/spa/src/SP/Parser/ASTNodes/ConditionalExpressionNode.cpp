//
// Created by yeemi on 2/10/2024.
//

#include "ConditionalExpressionNode.h"

#include <utility>
void ConditionalExpressionNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitConditionalExpressionNode(
      std::make_shared<ConditionalExpressionNode>(*this));
}
ConditionalExpressionNode::ConditionalExpressionNode(
    std::vector<std::shared_ptr<VariableNode>> variableNodes,
    std::vector<std::shared_ptr<ConstantNode>> constantNodes)
    : ExpressionNode(std::move(variableNodes), std::move(constantNodes)) {}
ConditionalExpressionNode::~ConditionalExpressionNode() = default;
