#pragma once

class QueryValidator {};

