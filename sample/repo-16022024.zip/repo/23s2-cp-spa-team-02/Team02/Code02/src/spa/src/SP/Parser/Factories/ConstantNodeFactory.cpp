//
// Created by yeemi on 2/12/2024.
//

#include "ConstantNodeFactory.h"

ConstantNodeFactory::ConstantNodeFactory() = default;

ConstantNodeFactory::~ConstantNodeFactory() = default;

std::shared_ptr<ConstantNode>
ConstantNodeFactory::createConstantNode(Tokens &tokens) {
  TokenSP constant = tokens.getNextToken();
  return std::make_shared<ConstantNode>(constant.getValue());
}