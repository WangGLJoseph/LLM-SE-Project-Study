//
// Created by yeemi on 2/10/2024.
//

#include "WhileStatementNodeFactory.h"
#include "NodeFactory.h"

WhileStatementNodeFactory::WhileStatementNodeFactory() = default;

WhileStatementNodeFactory::~WhileStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
WhileStatementNodeFactory::createStatementNode(Tokens &tokens) {
  int statementNumber = NodeFactory::getStatementNumber();

  // Skip "While" and "("
  tokens.increaseIndex(2);
  std::shared_ptr<ExpressionNode> conditionalExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::CONDITIONAL);
  std::vector<std::shared_ptr<StatementNode>> statementNodes;
  // Skip "{"
  tokens.increaseIndex(1);
  int rightCurlyBracketIndex = tokens.getRightCurlyBracketIndex();
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    std::shared_ptr<StatementNode> statementNode =
        NodeFactory::createStatementNode(tokens);
    statementNodes.push_back(statementNode);
  }

  // Skip "}"
  tokens.increaseIndex(1);
  WhileStatementNode whileStatementNode = WhileStatementNode(
      statementNumber, conditionalExpressionNode, statementNodes);
  return std::make_shared<WhileStatementNode>(whileStatementNode);
}
