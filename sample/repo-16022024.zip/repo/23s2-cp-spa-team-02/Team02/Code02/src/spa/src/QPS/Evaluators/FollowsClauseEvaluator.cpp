#include "FollowsClauseEvaluator.h"

Result FollowsClauseEvaluator::evaluate(const StClause& stClause) {

  // Supports Follows(constant, synonym)

  Result result{{stClause.getArg2()}};

  auto& following = pkb_.getStatementFollowing(stClause.getArg1());

  if (!following.empty()) {
    result.populateSynonym(stClause.getArg2(), {following});
  }


  return result;
}