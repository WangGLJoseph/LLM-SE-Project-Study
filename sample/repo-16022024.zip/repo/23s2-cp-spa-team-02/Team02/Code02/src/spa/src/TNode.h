class TNode
{
public:

};