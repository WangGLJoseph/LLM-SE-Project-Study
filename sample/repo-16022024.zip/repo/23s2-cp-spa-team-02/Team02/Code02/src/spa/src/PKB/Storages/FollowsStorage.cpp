//
// Created by Clement Kong on 7/2/24.
//
#include "FollowsStorage.h"

FollowsStorage::FollowsStorage() = default;

FollowsStorage::~FollowsStorage() = default;

void FollowsStorage::addFollows(const std::string &statement1,
                                const std::string &statement2) {
  this->follows_.insert({statement1, statement2});
}

bool FollowsStorage::hasFollows() { return !this->follows_.empty(); }

// Wrong implementation now. Need to change to a recursion based algo.
// TODO: Recursion to get follows* rs instead
void FollowsStorage::addFollowsStar(const std::string &statement1,
                                    const std::string &statement2) {
  this->followsStar_[statement1].insert(statement2);
}

const std::string &
FollowsStorage::getStatementFollowing(const std::string &statement) {
  if (this->follows_.find(statement) != this->follows_.end())
    return this->follows_[statement];
  return "";
}
//
// const std::optional<const std::string&>
// FollowsStorage::getStatementFollowing(const std::string &statement) {
//    if (this->follows_.find(statement) != this->follows_.end()) return
//    this->follows_[statement]; return std::optional<const std::string&>();
//}
//
// const std::optional<const std::string&>
// FollowsStorage::getStatementFollowing(const std::string &statement) {
//    auto it = this->follows_.find(statement);
//    if (it != this->follows_.end()) {
//        return this->follows_[statement];
//    }
//
//    return std::optional<const std::string&>();
//}
