//
// Created by yeemi on 2/6/2024.
//

#include <utility>

#include "TokenSP.h"

TokenSP::TokenSP(TokenTypeSP type, std::string value)
    : _value(std::move(value)), _type(type) {}

TokenTypeSP TokenSP::getType() { return _type; }

std::string TokenSP::getValue() { return _value; }

bool TokenSP::equals(TokenSP &other) {
  return (getType() == other.getType()) && (getValue() == other.getValue());
}