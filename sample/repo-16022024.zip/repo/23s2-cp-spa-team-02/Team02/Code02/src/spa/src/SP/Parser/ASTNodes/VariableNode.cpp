//
// Created by yeemi on 2/10/2024.
//

#include "VariableNode.h"

VariableNode::VariableNode(std::string name) : _name(std::move(name)) {}

VariableNode::~VariableNode() = default;

void VariableNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitVariableNode(std::make_shared<VariableNode>(*this));
}

std::string VariableNode::getName() { return _name; }
