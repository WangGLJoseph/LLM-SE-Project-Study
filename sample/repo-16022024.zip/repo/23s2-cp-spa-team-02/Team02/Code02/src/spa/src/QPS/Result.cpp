#include "Result.h"

Result::Result(std::initializer_list<std::string> synonyms) {
  for (const auto& synonym : synonyms) {
    // Initialises entry
    table_[synonym];
  }
}

std::unordered_set<std::string> Result::getSynonym(const std::string& synonym) {

    std::vector<std::string>& synonymValues = table_[synonym];

    return {synonymValues.begin(), synonymValues.end()};
}

bool Result::isEmpty() {

  return table_.empty() || table_.begin()->second.empty();
}

void Result::populateSynonym(const std::string &synonym, const std::vector<std::string> &values) {
  table_[synonym] = values;
}