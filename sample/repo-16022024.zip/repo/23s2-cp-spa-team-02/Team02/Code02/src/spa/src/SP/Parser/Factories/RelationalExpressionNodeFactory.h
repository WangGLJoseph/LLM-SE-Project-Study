//
// Created by yeemi on 2/12/2024.
//
#pragma once

#include "../ASTNodes/RelationalExpressionNode.h"
#include "ExpressionNodeFactory.h"

class RelationalExpressionNodeFactory : public ExpressionNodeFactory {
public:
  RelationalExpressionNodeFactory();
  ~RelationalExpressionNodeFactory();

  std::shared_ptr<ExpressionNode> createExpressionNode(Tokens &tokens) override;
};