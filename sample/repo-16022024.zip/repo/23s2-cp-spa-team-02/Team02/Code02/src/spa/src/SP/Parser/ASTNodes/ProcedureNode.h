//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include "StatementNode.h"
#include <string>
#include <vector>

class ProcedureNode : public Node {
private:
  std::vector<std::shared_ptr<StatementNode>> _statementNodes;
  std::string _name;

public:
  explicit ProcedureNode(
      std::vector<std::shared_ptr<StatementNode>> &statementNodes,
      std::string name);
  ~ProcedureNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::vector<std::shared_ptr<StatementNode>> getStatementNodes();
  std::string getName();
};
