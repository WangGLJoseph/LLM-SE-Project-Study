//
// Created by yeemi on 2/6/2024.
//

#include "Parser.h"

Parser::Parser() = default;

Parser::~Parser() = default;

ProgramNode Parser::parseTokens(Tokens &tokens) {
  NodeFactory::initializeFactory();
  ProgramNode programNode = NodeFactory::createAST(tokens);
  return programNode;
}