#pragma once

#include "QPS/Query.h"
#include "Token.h"
#include <regex>

class QueryTokenizer {
private:
  TokenType determineTokenType(const std::smatch &match);

public:
  std::vector<Token> tokens;
  void tokenize(const std::string &query);
};
