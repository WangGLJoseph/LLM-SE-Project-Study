//
// Created by yeemi on 2/10/2024.
//

#include "ProcedureNode.h"

#include <utility>

ProcedureNode::ProcedureNode(
    std::vector<std::shared_ptr<StatementNode>> &statementNodes,
    std::string name)
    : _statementNodes(statementNodes), _name(std::move(name)) {}

ProcedureNode::~ProcedureNode() = default;

void ProcedureNode::accept(ExtractorVisitor *extractorVisitor) {
  extractorVisitor->visitProcedureNode(std::make_shared<ProcedureNode>(*this));
}
std::vector<std::shared_ptr<StatementNode>> ProcedureNode::getStatementNodes() {
  return _statementNodes;
}
std::string ProcedureNode::getName() { return _name; }
