//
// Created by yeemi on 2/12/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ConstantNode.h"
#include "SP/Tokenizer/Tokens.h"

class ConstantNodeFactory {
public:
  ConstantNodeFactory();
  ~ConstantNodeFactory();

  std::shared_ptr<ConstantNode> createConstantNode(Tokens &tokens);
};
