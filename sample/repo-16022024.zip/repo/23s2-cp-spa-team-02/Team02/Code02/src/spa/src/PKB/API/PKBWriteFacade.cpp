//
// Created by Clement Kong on 6/2/24.
//
#include "PKBWriteFacade.h"
#include "PKB/PKB.h"

PKBWriteFacade::PKBWriteFacade(PKB &pkb) : pkb_(pkb) {}

PKBWriteFacade::~PKBWriteFacade() = default;

void PKBWriteFacade::addProcedure(const std::string &procName) {
  this->pkb_.entityStorage_.addProcedure(procName);
}

void PKBWriteFacade::addVariable(const std::string &varName) {
  this->pkb_.entityStorage_.addVariable(varName);
}

void PKBWriteFacade::addConstant(const std::string &constVal) {
  this->pkb_.entityStorage_.addConstant(constVal);
}

void PKBWriteFacade::addFollows(const std::string &statement1,
                                const std::string &statement2) {
  this->pkb_.followsStorage_.addFollows(statement1, statement2);
}

void PKBWriteFacade::addStatementWithType(const std::string &stmtNumber,
                                          const std::string &stmtType) {
  this->pkb_.statementStorage_.addStatementWithType(stmtNumber, stmtType);
}

void PKBWriteFacade::addStatementMetadata(
    const std::string &stmtNumber,
    std::unordered_set<std::string> &metadata) {
  this->pkb_.statementStorage_.addStatementMetadata(stmtNumber, metadata);
}

// TODO: Modify the function to iteratively find follows* relationships instead
// of SP supplying us
// void PKBWriteFacade::addFollowsStar(const std::string& statement1, const
// std::string& statement2) {
//    this->pkb.addFollowsStar(statement1, statement2);
//}
