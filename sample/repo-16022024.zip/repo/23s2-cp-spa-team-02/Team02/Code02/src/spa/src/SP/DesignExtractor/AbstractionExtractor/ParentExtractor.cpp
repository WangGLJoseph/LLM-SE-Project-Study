//
// Created by yeemi on 2/8/2024.
//

#include "ParentExtractor.h"

ParentExtractor::ParentExtractor(PKBWriteFacade &pkbWriteFacade)
    : BaseExtractor(pkbWriteFacade) {}
ParentExtractor::~ParentExtractor() = default;

void ParentExtractor::visitProgramNode(
    std::shared_ptr<ProgramNode> programNode) {}