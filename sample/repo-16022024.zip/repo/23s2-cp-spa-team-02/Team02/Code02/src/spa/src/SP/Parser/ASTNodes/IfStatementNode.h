//
// Created by yeemi on 2/10/2024.
//

#pragma once
#include "ExpressionNode.h"
#include "StatementNode.h"
#include <vector>

class IfStatementNode : public StatementNode {
private:
  std::shared_ptr<ExpressionNode> _conditionalExpressionNode;
  std::vector<std::shared_ptr<StatementNode>> _thenStatementNodes;
  std::vector<std::shared_ptr<StatementNode>> _elseStatementNodes;

public:
  explicit IfStatementNode(
      int statementNumber,
      std::shared_ptr<ExpressionNode> conditionalExpressionNode,
      std::vector<std::shared_ptr<StatementNode>> thenStatementNodes,
      std::vector<std::shared_ptr<StatementNode>> elseStatementNodes);
  ~IfStatementNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::shared_ptr<ExpressionNode> getConditionalExpressionNode();
  std::vector<std::shared_ptr<StatementNode>> getThenStatementNodes();
  std::vector<std::shared_ptr<StatementNode>> getElseStatementNodes();
};