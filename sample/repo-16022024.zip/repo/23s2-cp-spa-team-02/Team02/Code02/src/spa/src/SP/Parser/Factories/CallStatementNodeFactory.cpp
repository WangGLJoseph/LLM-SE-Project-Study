//
// Created by yeemi on 2/10/2024.
//

#include "CallStatementNodeFactory.h"
#include "NodeFactory.h"

CallStatementNodeFactory::CallStatementNodeFactory() = default;

CallStatementNodeFactory::~CallStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
CallStatementNodeFactory::createStatementNode(Tokens &tokens) {
  // Skip the call keyword
  tokens.increaseIndex(1);

  std::string procedureName = tokens.getNextToken().getValue();

  // Skip the ";" semicolon
  tokens.increaseIndex(1);
  return std::make_shared<CallStatementNode>(NodeFactory::getStatementNumber(),
                                             procedureName);
}
