//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "SP/Parser/ASTNodes/ProcedureNode.h"
#include "SP/Tokenizer/TokenSP.h"
#include "SP/Tokenizer/Tokens.h"
#include "StatementNodeFactory.h"
#include <memory>

class ProcedureNodeFactory {

public:
  ProcedureNodeFactory();
  ~ProcedureNodeFactory();

  static std::shared_ptr<ProcedureNode> createProcedureNode(Tokens &tokens);
};
