#pragma once

enum class TokenType {
  // TODO: add all entity types, differentiate between syntax and semantic tokens
  IDENTIFIER,
  SELECT,
  SUCH_THAT,
  PATTERN,
  ASSIGN,
  VARIABLE,
  SYMBOL,
  UNKNOWN,
  WHITESPACE,
  PAREN_OPEN,
  PAREN_CLOSE
};
