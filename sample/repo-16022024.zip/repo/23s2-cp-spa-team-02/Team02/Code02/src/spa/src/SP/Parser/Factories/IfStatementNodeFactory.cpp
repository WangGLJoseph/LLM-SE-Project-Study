//
// Created by yeemi on 2/10/2024.
//

#include "IfStatementNodeFactory.h"
#include "NodeFactory.h"
IfStatementNodeFactory::IfStatementNodeFactory() = default;

IfStatementNodeFactory::~IfStatementNodeFactory() = default;

std::shared_ptr<StatementNode>
IfStatementNodeFactory::createStatementNode(Tokens &tokens) {
  int statementNumber = NodeFactory::getStatementNumber();

  // Skip "if" and "("
  tokens.increaseIndex(2);
  std::shared_ptr<ExpressionNode> conditionalExpressionNode =
      NodeFactory::createExpressionNode(tokens, ExpressionType::CONDITIONAL);

  std::vector<std::shared_ptr<StatementNode>> thenStatementNodes;
  // Skip "{"
  tokens.increaseIndex(1);
  int rightCurlyBracketIndex = tokens.getRightCurlyBracketIndex();
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    std::shared_ptr<StatementNode> statementNode =
        NodeFactory::createStatementNode(tokens);
    thenStatementNodes.push_back(statementNode);
  }

  std::vector<std::shared_ptr<StatementNode>> elseStatementNodes;
  // Skip "} else {"
  tokens.increaseIndex(3);
  rightCurlyBracketIndex = tokens.getRightCurlyBracketIndex();
  while (tokens.getIndex() < rightCurlyBracketIndex) {
    std::shared_ptr<StatementNode> statementNode =
        NodeFactory::createStatementNode(tokens);
    elseStatementNodes.push_back(statementNode);
  }

  // Skip "}"
  tokens.increaseIndex(1);

  IfStatementNode ifStatementNode =
      IfStatementNode(statementNumber, conditionalExpressionNode,
                      thenStatementNodes, elseStatementNodes);
  return std::make_shared<IfStatementNode>(ifStatementNode);
}
