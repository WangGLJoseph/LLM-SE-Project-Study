//
// Created by Evan Chng on 11/2/24.
//

#include "Tokens.h"

#include <utility>

Tokens::Tokens(std::vector<TokenSP> tokens)
    : _tokens(std::move(tokens)), _index(0) {
  _length = (int)_tokens.size();
}

Tokens::~Tokens() = default;

int Tokens::getIndex() const { return _index; }

int Tokens::getLength() const { return _length; }

bool Tokens::isEmpty() { return getIndex() >= getLength() - 1; }

std::vector<TokenSP> Tokens::getTokens() { return _tokens; }

TokenSP Tokens::at(int idx) { return getTokens().at(idx); }

TokenTypeSP Tokens::peekHead() { return at(getIndex()).getType(); }

void Tokens::increaseIndex(int numberOfTokens) { _index += numberOfTokens; }

int Tokens::getRightParenthesisIndex() {
  int count = 0;
  int curr = getIndex();
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();

    switch (type) {
    case TokenTypeSP::LEFT_PARENTHESIS:
      ++count;
      break;
    case TokenTypeSP::RIGHT_PARENTHESIS:
      --count;
      if (count < 0) {
        return curr;
      }
    default:
      break;
    }
    ++curr;
  }
  // TODO: Throw error?
  return -1;
}

int Tokens::getRightCurlyBracketIndex() {
  int count = 0;
  int curr = getIndex();
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();

    switch (type) {
    case TokenTypeSP::LEFT_CURLY_BRACKET:
      ++count;
      break;
    case TokenTypeSP::RIGHT_CURLY_BRACKET:
      --count;
      if (count < 0) {
        return curr;
      }
    default:
      break;
    }
    ++curr;
  }
  // TODO: Throw error?
  return -1;
}

TokenSP Tokens::getNextToken() {
  increaseIndex(1);
  return at(getIndex() - 1);
}

int Tokens::getSemicolonIndex() {
  int curr = getIndex();
  int end = getLength();

  while (curr < end) {
    TokenTypeSP type = Tokens::at(curr).getType();
    if (type == TokenTypeSP::SEMICOLON)
      return curr;
    curr++;
  }
  return curr;
}
