//
// Created by yeemi on 2/10/2024.
//

#pragma once

#include "Node.h"
#include <vector>

class ProgramNode : public Node {
private:
  std::vector<std::shared_ptr<ProcedureNode>> _procedureNodes;

public:
  explicit ProgramNode(
      std::vector<std::shared_ptr<ProcedureNode>> &procedureNodes);
  ~ProgramNode();

  void accept(ExtractorVisitor *extractorVisitor) override;
  std::vector<std::shared_ptr<ProcedureNode>> getProcedureNodes();
};
