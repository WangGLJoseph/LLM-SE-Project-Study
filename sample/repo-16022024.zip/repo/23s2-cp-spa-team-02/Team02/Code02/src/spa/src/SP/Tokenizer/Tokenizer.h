//
// Created by Evan Chng on 5/2/24.
//
#pragma once

#include <unordered_map>
#include <vector>

#include "Exceptions/SyntaxErrorException.h"
#include "TokenFactory.h"
#include "TokenSP.h"
#include "TokenType.h"
#include "Tokens.h"
#include "Util/Strings.h"

class Tokenizer {
public:
  explicit Tokenizer(std::istream &input) : input(input) {}

  ~Tokenizer() = default;

  TokenSP nextToken();

  Tokens tokenize();

private:
  std::istream &input;
  int _position = 0;
  int _readPosition = 0;
  char _ch = '\0';

  char peekChar();

  void readCharAndAdvance();

  std::string readLiteral();

  void skipWhitespace();

  TokenTypeSP handleSingleCharTokens(char c);

  TokenTypeSP handleDoubleCharTokens(char c1, char c2);
};

const std::unordered_map<std::string, TokenTypeSP> keywords = {
    {"procedure", TokenTypeSP::PROCEDURE}, {"while", TokenTypeSP::WHILE},
    {"read", TokenTypeSP::READ},           {"print", TokenTypeSP::PRINT},
    {"call", TokenTypeSP::CALL},           {"if", TokenTypeSP::IF},
    {"then", TokenTypeSP::THEN},           {"else", TokenTypeSP::ELSE},
};

const std::unordered_map<std::string, TokenTypeSP> singleCharTokens = {
    {"(", TokenTypeSP::LEFT_PARENTHESIS},
    {")", TokenTypeSP::RIGHT_PARENTHESIS},
    {"{", TokenTypeSP::LEFT_CURLY_BRACKET},
    {"}", TokenTypeSP::RIGHT_CURLY_BRACKET},
    {";", TokenTypeSP::SEMICOLON},
    {"=", TokenTypeSP::ASSIGN},
    {"+", TokenTypeSP::PLUS},
    {"-", TokenTypeSP::MINUS},
    {"*", TokenTypeSP::TIMES},
    {"/", TokenTypeSP::DIVIDE},
    {"%", TokenTypeSP::MODULO},
    {"<", TokenTypeSP::LESS_THAN},
    {">", TokenTypeSP::GREATER_THAN},
    {"!", TokenTypeSP::NOT},

};

const std::unordered_map<std::string, TokenTypeSP> doubleCharTokens = {
    {"<=", TokenTypeSP::LESS_THAN_OR_EQUALS},
    {">=", TokenTypeSP::GREATER_THAN_OR_EQUALS},
    {"==", TokenTypeSP::DOUBLE_EQUALS},
    {"!=", TokenTypeSP::NOT_EQUALS},
    {"&&", TokenTypeSP::AND},
    {"||", TokenTypeSP::OR},
};