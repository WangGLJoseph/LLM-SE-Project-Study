#include <iostream>
#include <sstream>

#include "PKB/API/PKBReadFacade.h"
#include "PKB/API/PKBWriteFacade.h"
#include "SP/DesignExtractor/DesignExtractorManager.h"
#include "SP/Parser/Parser.h"
#include "SP/Tokenizer/Tokenizer.h"
#include "SP/Tokenizer/Tokens.h"
#include "catch.hpp"

TEST_CASE("Extract from procedure with single assign statement") {
  std::string input = "procedure test { x = 5; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  EntityExtractor entityExtractor = EntityExtractor(pkbWriteFacade);
  programNode.accept(&entityExtractor);

  PKBReadFacade pkbReadFacade(pkb);
  const std::unordered_set<std::string> &procedures =
      pkbReadFacade.getProcedures();
  REQUIRE(procedures.size() == 1);

  const std::unordered_set<std::string> &variables =
      pkbReadFacade.getVariables();
  REQUIRE(variables.size() == 1);

  const std::unordered_set<std::string> &constants =
      pkbReadFacade.getVariables();
  REQUIRE(constants.size() == 1);
}

TEST_CASE("Extract from procedure with multiple distinct statements") {
  std::string input = "procedure test { if (x = 5) { call procName; while ( x "
                      "!= 5 ) { read varName; } print varName; } }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  EntityExtractor entityExtractor = EntityExtractor(pkbWriteFacade);
  programNode.accept(&entityExtractor);

  PKBReadFacade pkbReadFacade(pkb);

  const std::unordered_set<std::string> &assignStatements =
      pkbReadFacade.getStatementsWithType("assign");
  REQUIRE(assignStatements.empty());

  const std::unordered_set<std::string> &callStatements =
      pkbReadFacade.getStatementsWithType("call");
  REQUIRE(callStatements.size() == 1);

  const std::unordered_set<std::string> &printStatements =
      pkbReadFacade.getStatementsWithType("print");
  REQUIRE(printStatements.size() == 1);

  const std::unordered_set<std::string> &readStatements =
      pkbReadFacade.getStatementsWithType("read");
  REQUIRE(readStatements.size() == 1);

  const std::unordered_set<std::string> &ifStatements =
      pkbReadFacade.getStatementsWithType("if");
  REQUIRE(ifStatements.size() == 1);

  const std::unordered_set<std::string> &whileStatements =
      pkbReadFacade.getStatementsWithType("while");
  REQUIRE(whileStatements.size() == 1);
}

TEST_CASE("Extract from procedure with multiple same statements") {
  std::string input = "procedure test { call procName; call procName; call "
                      "procName; call procName; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  EntityExtractor entityExtractor = EntityExtractor(pkbWriteFacade);
  programNode.accept(&entityExtractor);

  PKBReadFacade pkbReadFacade(pkb);

  const std::unordered_set<std::string> &assignStatements =
      pkbReadFacade.getStatementsWithType("assign");
  REQUIRE(assignStatements.empty());

  const std::unordered_set<std::string> &callStatements =
      pkbReadFacade.getStatementsWithType("call");
  REQUIRE(callStatements.size() == 4);

  const std::unordered_set<std::string> &printStatements =
      pkbReadFacade.getStatementsWithType("print");
  REQUIRE(printStatements.empty());

  const std::unordered_set<std::string> &readStatements =
      pkbReadFacade.getStatementsWithType("read");
  REQUIRE(readStatements.empty());
}