#include "QPS/Parser/QueryParser.h"
#include "QPS/Tokenizer/QueryTokenizer.h"
#include "catch.hpp"

//TEST_CASE("Test tokenize") {
//  QueryTokenizer tokenizer;
//
//  REQUIRE(tokenizer.trimWhitespace("  ") == "");
//  REQUIRE(tokenizer.trimWhitespace(
//              "   assign  a;  while w;     Select a Follows (a, w) ") ==
//          "assign a; while w; Select a Follows (a, w)");
////  REQUIRE(tokenizer.trimWhitespace("assign  a  ;  variable  v  ;  Select   a   such   that   Follows    (a, 1)    pattern   (v, \"x\")") ==
////          "assign a; variable v; Select a such that Follows (a, 1) pattern (v, \"x\")");
//}