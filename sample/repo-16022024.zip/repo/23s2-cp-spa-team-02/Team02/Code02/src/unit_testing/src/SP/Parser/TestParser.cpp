//
// Created by Evan Chng on 9/2/24.
//

#include <iostream>
#include <sstream>

#include "SP/Parser/Parser.h"
#include "SP/Tokenizer/TokenFactory.h"
#include "SP/Tokenizer/Tokenizer.h"
#include "SP/Tokenizer/Tokens.h"
#include "catch.hpp"

TEST_CASE("Parse empty procedure") {
  std::cout << "Processing test: Parse empty procedure" << std::endl;
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  REQUIRE(tokens.getLength() == 4);
  ProgramNode programNode = Parser::parseTokens(tokens);
  std::cout << "Number of procedure nodes: "
            << programNode.getProcedureNodes().size() << std::endl;
  REQUIRE(programNode.getProcedureNodes()[0]->getName() == "test");
}

TEST_CASE("Parse procedure with read statement") {
  std::cout << "Processing test: Parse procedure with read statement"
            << std::endl;
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::READ, "read"),
      TokenFactory::createToken(TokenTypeSP::NAME, "varName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  std::cout << "Number of procedure nodes: "
            << programNode.getProcedureNodes().size() << std::endl;

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::cout << "Number of statement nodes: "
            << procedureNode.getStatementNodes().size() << std::endl;

  std::shared_ptr<ReadStatementNode> readStatementNode =
      std::dynamic_pointer_cast<ReadStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(readStatementNode->getStatementNumber() == 1);
  REQUIRE(readStatementNode->getVariableNode()->getName() == "varName");
}

TEST_CASE("Parse procedure with print statement") {
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::PRINT, "print"),
      TokenFactory::createToken(TokenTypeSP::NAME, "varName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<PrintStatementNode> printStatementNode =
      std::dynamic_pointer_cast<PrintStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(printStatementNode->getStatementNumber() == 1);
  REQUIRE(printStatementNode->getVariableNode()->getName() == "varName");
}

TEST_CASE("Parse procedure with assign statement") {
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::NAME, "x"),
      TokenFactory::createToken(TokenTypeSP::ASSIGN, "="),
      TokenFactory::createToken(TokenTypeSP::INTEGER, "5"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<AssignStatementNode> assignStatementNode =
      std::dynamic_pointer_cast<AssignStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(assignStatementNode->getStatementNumber() == 1);
  REQUIRE(assignStatementNode->getVariableNode()->getName() == "x");

  REQUIRE(assignStatementNode->getArithmeticExpressionNode()
              ->getConstantNodes()[0]
              ->getName() == "5");
}

TEST_CASE("Parse procedure with call statement") {
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::CALL, "call"),
      TokenFactory::createToken(TokenTypeSP::NAME, "procName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<CallStatementNode> callStatementNode =
      std::dynamic_pointer_cast<CallStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(callStatementNode->getStatementNumber() == 1);
  REQUIRE(callStatementNode->getProcedureName() == "procName");
}

TEST_CASE("Parse procedure with if statement") {
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::IF, "if"),
      TokenFactory::createToken(TokenTypeSP::LEFT_PARENTHESIS, "("),
      TokenFactory::createToken(TokenTypeSP::NAME, "x"),
      TokenFactory::createToken(TokenTypeSP::NOT_EQUALS, "!="),
      TokenFactory::createToken(TokenTypeSP::INTEGER, "5"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_PARENTHESIS, ")"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::CALL, "call"),
      TokenFactory::createToken(TokenTypeSP::NAME, "procName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
      TokenFactory::createToken(TokenTypeSP::ELSE, "else"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::CALL, "call"),
      TokenFactory::createToken(TokenTypeSP::NAME, "procName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<IfStatementNode> ifStatementNode =
      std::dynamic_pointer_cast<IfStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(ifStatementNode->getStatementNumber() == 1);
  REQUIRE(ifStatementNode->getElseStatementNodes().size() == 1);
  REQUIRE(ifStatementNode->getThenStatementNodes().size() == 1);

  std::shared_ptr<ConditionalExpressionNode> conditionalExpressionNode =
      std::dynamic_pointer_cast<ConditionalExpressionNode>(
          ifStatementNode->getConditionalExpressionNode());
  REQUIRE(conditionalExpressionNode->getVariableNodes()[0]->getName() == "x");
  REQUIRE(conditionalExpressionNode->getConstantNodes()[0]->getName() == "5");

  std::vector<std::shared_ptr<StatementNode>> thenStatementNodes =
      ifStatementNode->getThenStatementNodes();
  std::vector<std::shared_ptr<StatementNode>> elseStatementNodes =
      ifStatementNode->getElseStatementNodes();

  REQUIRE(thenStatementNodes.size() == 1);
  REQUIRE(elseStatementNodes.size() == 1);
}

TEST_CASE("Parse procedure with while statement") {
  Tokens tokens = Tokens({

      TokenFactory::createToken(TokenTypeSP::PROCEDURE, "procedure"),
      TokenFactory::createToken(TokenTypeSP::NAME, "test"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::WHILE, "while"),
      TokenFactory::createToken(TokenTypeSP::LEFT_PARENTHESIS, "("),
      TokenFactory::createToken(TokenTypeSP::NAME, "x"),
      TokenFactory::createToken(TokenTypeSP::NOT_EQUALS, "!="),
      TokenFactory::createToken(TokenTypeSP::INTEGER, "5"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_PARENTHESIS, ")"),
      TokenFactory::createToken(TokenTypeSP::LEFT_CURLY_BRACKET, "{"),
      TokenFactory::createToken(TokenTypeSP::CALL, "call"),
      TokenFactory::createToken(TokenTypeSP::NAME, "procName"),
      TokenFactory::createToken(TokenTypeSP::SEMICOLON, ";"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
      TokenFactory::createToken(TokenTypeSP::RIGHT_CURLY_BRACKET, "}"),
  });
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<WhileStatementNode> whileStatementNode =
      std::dynamic_pointer_cast<WhileStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(whileStatementNode->getStatementNumber() == 1);
  REQUIRE(whileStatementNode->getStatementNodes().size() == 1);

  std::shared_ptr<ConditionalExpressionNode> conditionalExpressionNode =
      std::dynamic_pointer_cast<ConditionalExpressionNode>(
          whileStatementNode->getConditionalExpressionNode());
  REQUIRE(conditionalExpressionNode->getVariableNodes()[0]->getName() == "x");
  REQUIRE(conditionalExpressionNode->getConstantNodes()[0]->getName() == "5");

  std::vector<std::shared_ptr<StatementNode>> statementNodes =
      whileStatementNode->getStatementNodes();
  REQUIRE(statementNodes.size() == 1);
}

TEST_CASE("Parse basic procedure") {
  std::string input =
      "procedure test { if (x = 5) { call procName; while ( x != 5 ) { read "
      "varName; } print varName; } else { x = x + 1; } }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  REQUIRE(programNode.getProcedureNodes().size() == 1);

  ProcedureNode procedureNode = *programNode.getProcedureNodes()[0];
  REQUIRE(procedureNode.getName() == "test");
  REQUIRE(procedureNode.getStatementNodes().size() == 1);

  std::shared_ptr<IfStatementNode> ifStatementNode =
      std::dynamic_pointer_cast<IfStatementNode>(
          procedureNode.getStatementNodes()[0]);
  REQUIRE(ifStatementNode->getStatementNumber() == 1);
  REQUIRE(ifStatementNode->getThenStatementNodes().size() == 3);
  REQUIRE(ifStatementNode->getElseStatementNodes().size() == 1);

  std::shared_ptr<ConditionalExpressionNode> conditionalExpressionNode =
      std::dynamic_pointer_cast<ConditionalExpressionNode>(
          ifStatementNode->getConditionalExpressionNode());
  REQUIRE(conditionalExpressionNode->getVariableNodes()[0]->getName() == "x");
  REQUIRE(conditionalExpressionNode->getConstantNodes()[0]->getName() == "5");
}