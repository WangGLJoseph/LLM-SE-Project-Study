//
// Created by Evan Chng on 5/2/24.
//

#include "SP/Tokenizer/Tokenizer.h"
#include <sstream>

#include "Exceptions/SyntaxErrorException.h"
#include "SP/Tokenizer/TokenFactory.h"
#include "catch.hpp"

TEST_CASE("Tokenize single integer") {
  std::string input = "4";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 1);
  REQUIRE(tokens.at(0).getType() == INTEGER);
  REQUIRE(tokens.at(0).getValue() == "4");
}

TEST_CASE("Tokenize multi character integer") {
  std::string input = "44";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 1);

  REQUIRE(tokens.at(0).getType() == INTEGER);
  REQUIRE(tokens.at(0).getValue() == "44");
}

TEST_CASE("Tokenize integer input") {
  std::string input = "1 22 333 4444";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 4);

  REQUIRE(tokens.at(0).getType() == INTEGER);
  REQUIRE(tokens.at(0).getValue() == "1");

  REQUIRE(tokens.at(1).getType() == INTEGER);
  REQUIRE(tokens.at(1).getValue() == "22");

  REQUIRE(tokens.at(2).getType() == INTEGER);
  REQUIRE(tokens.at(2).getValue() == "333");

  REQUIRE(tokens.at(3).getType() == INTEGER);
  REQUIRE(tokens.at(3).getValue() == "4444");
}

TEST_CASE("Tokenize arithmetic symbol input") {
  std::string input = "+ - * / %";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 5);

  REQUIRE(tokens.at(0).getType() == PLUS);
  REQUIRE(tokens.at(0).getValue() == "+");

  REQUIRE(tokens.at(1).getType() == MINUS);
  REQUIRE(tokens.at(1).getValue() == "-");

  REQUIRE(tokens.at(2).getType() == TIMES);
  REQUIRE(tokens.at(2).getValue() == "*");

  REQUIRE(tokens.at(3).getType() == DIVIDE);
  REQUIRE(tokens.at(3).getValue() == "/");

  REQUIRE(tokens.at(4).getType() == MODULO);
  REQUIRE(tokens.at(4).getValue() == "%");
}

TEST_CASE("Tokenize math expression") {
  std::string input = "20 + 1234;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 4);

  REQUIRE(tokens.at(0).getType() == INTEGER);
  REQUIRE(tokens.at(0).getValue() == "20");

  REQUIRE(tokens.at(1).getType() == PLUS);
  REQUIRE(tokens.at(1).getValue() == "+");

  REQUIRE(tokens.at(2).getType() == INTEGER);
  REQUIRE(tokens.at(2).getValue() == "1234");

  REQUIRE(tokens.at(3).getType() == SEMICOLON);
  REQUIRE(tokens.at(3).getValue() == ";");
}

TEST_CASE("Tokenize bracket input") {
  std::string input = "(){}";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 4);

  REQUIRE(tokens.at(0).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(0).getValue() == "(");

  REQUIRE(tokens.at(1).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(1).getValue() == ")");

  REQUIRE(tokens.at(2).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(2).getValue() == "{");

  REQUIRE(tokens.at(3).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(3).getValue() == "}");
}

TEST_CASE("Tokenize assignment with whitespace") {
  std::string input = "Name = x + y;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 6);

  REQUIRE(tokens.at(0).getType() == NAME);
  REQUIRE(tokens.at(0).getValue() == "Name");

  REQUIRE(tokens.at(1).getType() == ASSIGN);
  REQUIRE(tokens.at(1).getValue() == "=");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "x");

  REQUIRE(tokens.at(3).getType() == PLUS);
  REQUIRE(tokens.at(3).getValue() == "+");

  REQUIRE(tokens.at(4).getType() == NAME);
  REQUIRE(tokens.at(4).getValue() == "y");

  REQUIRE(tokens.at(5).getType() == SEMICOLON);
  REQUIRE(tokens.at(5).getValue() == ";");
}

TEST_CASE("Tokenize assignment without whitespace") {
  std::string input = "Name=x+y;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 6);

  REQUIRE(tokens.at(0).getType() == NAME);
  REQUIRE(tokens.at(0).getValue() == "Name");

  REQUIRE(tokens.at(1).getType() == ASSIGN);
  REQUIRE(tokens.at(1).getValue() == "=");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "x");

  REQUIRE(tokens.at(3).getType() == PLUS);
  REQUIRE(tokens.at(3).getValue() == "+");

  REQUIRE(tokens.at(4).getType() == NAME);
  REQUIRE(tokens.at(4).getValue() == "y");

  REQUIRE(tokens.at(5).getType() == SEMICOLON);
  REQUIRE(tokens.at(5).getValue() == ";");
}

TEST_CASE("Tokenize two character symbols") {
  std::string input = "x==y\n  a != b <= >=";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 8);
  REQUIRE(tokens.at(0).getType() == NAME);
  REQUIRE(tokens.at(0).getValue() == "x");

  REQUIRE(tokens.at(1).getType() == DOUBLE_EQUALS);
  REQUIRE(tokens.at(1).getValue() == "==");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "y");

  REQUIRE(tokens.at(3).getType() == NAME);
  REQUIRE(tokens.at(3).getValue() == "a");

  REQUIRE(tokens.at(4).getType() == NOT_EQUALS);
  REQUIRE(tokens.at(4).getValue() == "!=");

  REQUIRE(tokens.at(5).getType() == NAME);
  REQUIRE(tokens.at(5).getValue() == "b");

  REQUIRE(tokens.at(6).getType() == LESS_THAN_OR_EQUALS);
  REQUIRE(tokens.at(6).getValue() == "<=");

  REQUIRE(tokens.at(7).getType() == GREATER_THAN_OR_EQUALS);
  REQUIRE(tokens.at(7).getValue() == ">=");
}

TEST_CASE("Tokenize name with number") {
  std::string input = "name1 name2 name3 a1b2c3";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();
  REQUIRE(tokens.at(0).getType() == NAME);
  REQUIRE(tokens.at(0).getValue() == "name1");

  REQUIRE(tokens.at(1).getType() == NAME);
  REQUIRE(tokens.at(1).getValue() == "name2");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "name3");

  REQUIRE(tokens.at(3).getType() == NAME);
  REQUIRE(tokens.at(3).getValue() == "a1b2c3");
}

// tokenize invalid name 1bac
TEST_CASE("Tokenize invalid name leading number") {
  std::string input = "1bac;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  REQUIRE_THROWS_AS(tokenizer.tokenize(), SyntaxErrorException);
}

TEST_CASE("Tokenize keywords") {
  std::string input = "procedure while read print call if then else";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();
  REQUIRE(tokens.at(0).getType() == PROCEDURE);
  REQUIRE(tokens.at(0).getValue() == "procedure");
  REQUIRE(tokens.at(1).getType() == WHILE);
  REQUIRE(tokens.at(1).getValue() == "while");
  REQUIRE(tokens.at(2).getType() == READ);
  REQUIRE(tokens.at(2).getValue() == "read");
  REQUIRE(tokens.at(3).getType() == PRINT);
  REQUIRE(tokens.at(3).getValue() == "print");
  REQUIRE(tokens.at(4).getType() == CALL);
  REQUIRE(tokens.at(4).getValue() == "call");
  REQUIRE(tokens.at(5).getType() == IF);
  REQUIRE(tokens.at(5).getValue() == "if");
  REQUIRE(tokens.at(6).getType() == THEN);
  REQUIRE(tokens.at(6).getValue() == "then");
  REQUIRE(tokens.at(7).getType() == ELSE);
  REQUIRE(tokens.at(7).getValue() == "else");
}

TEST_CASE("Tokenize integer with leading zero") {
  std::string input = "0002;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);

  REQUIRE_THROWS_AS(tokenizer.tokenize(), SyntaxErrorException);
}

// ai-gen start(gpt, 1, e)
// prompt:
// https://platform.openai.com/playground?assistant=asst_bB5WL2lLMsCHPP9OedD9H5kM&thread=thread_GWNyhjQk9MCMNoiUH2R6yz0B
// test && and ||
TEST_CASE("Tokenize logical operators") {
  std::string input = "&& ||";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 2);

  REQUIRE(tokens.at(0).getType() == AND);
  REQUIRE(tokens.at(0).getValue() == "&&");

  REQUIRE(tokens.at(1).getType() == OR);
  REQUIRE(tokens.at(1).getValue() == "||");
}

TEST_CASE("Tokenize complex arithmetic expression") {
  std::string input = "(a + b) * (c - d) / (e % f)";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 17);

  REQUIRE(tokens.at(0).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(0).getValue() == "(");

  REQUIRE(tokens.at(1).getType() == NAME);
  REQUIRE(tokens.at(1).getValue() == "a");

  REQUIRE(tokens.at(2).getType() == PLUS);
  REQUIRE(tokens.at(2).getValue() == "+");

  REQUIRE(tokens.at(3).getType() == NAME);
  REQUIRE(tokens.at(3).getValue() == "b");

  REQUIRE(tokens.at(4).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(4).getValue() == ")");

  REQUIRE(tokens.at(5).getType() == TIMES);
  REQUIRE(tokens.at(5).getValue() == "*");

  REQUIRE(tokens.at(6).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(6).getValue() == "(");

  REQUIRE(tokens.at(7).getType() == NAME);
  REQUIRE(tokens.at(7).getValue() == "c");

  REQUIRE(tokens.at(8).getType() == MINUS);
  REQUIRE(tokens.at(8).getValue() == "-");

  REQUIRE(tokens.at(9).getType() == NAME);
  REQUIRE(tokens.at(9).getValue() == "d");

  REQUIRE(tokens.at(10).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(10).getValue() == ")");

  REQUIRE(tokens.at(11).getType() == DIVIDE);
  REQUIRE(tokens.at(11).getValue() == "/");

  REQUIRE(tokens.at(12).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(12).getValue() == "(");

  REQUIRE(tokens.at(13).getType() == NAME);
  REQUIRE(tokens.at(13).getValue() == "e");

  REQUIRE(tokens.at(14).getType() == MODULO);
  REQUIRE(tokens.at(14).getValue() == "%");

  REQUIRE(tokens.at(15).getType() == NAME);
  REQUIRE(tokens.at(15).getValue() == "f");

  REQUIRE(tokens.at(16).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(16).getValue() == ")");
}

TEST_CASE("Tokenize program with multiple procedures") {
  std::string input = R"(
        procedure Proc1 {
            x = 10 + y;
        }

        procedure Proc2 {
            if (z > 0) {
                print z;
            }
        }
    )";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();
  REQUIRE(tokens.getLength() == 25);

  REQUIRE(tokens.getLength() == 25);

  REQUIRE(tokens.at(0).getType() == PROCEDURE);
  REQUIRE(tokens.at(0).getValue() == "procedure");

  REQUIRE(tokens.at(1).getType() == NAME);
  REQUIRE(tokens.at(1).getValue() == "Proc1");

  REQUIRE(tokens.at(2).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(2).getValue() == "{");

  REQUIRE(tokens.at(3).getType() == NAME);
  REQUIRE(tokens.at(3).getValue() == "x");

  REQUIRE(tokens.at(4).getType() == ASSIGN);
  REQUIRE(tokens.at(4).getValue() == "=");

  REQUIRE(tokens.at(5).getType() == INTEGER);
  REQUIRE(tokens.at(5).getValue() == "10");

  REQUIRE(tokens.at(6).getType() == PLUS);
  REQUIRE(tokens.at(6).getValue() == "+");

  REQUIRE(tokens.at(7).getType() == NAME);
  REQUIRE(tokens.at(7).getValue() == "y");

  REQUIRE(tokens.at(8).getType() == SEMICOLON);
  REQUIRE(tokens.at(8).getValue() == ";");

  REQUIRE(tokens.at(9).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(9).getValue() == "}");

  REQUIRE(tokens.at(10).getType() == PROCEDURE);
  REQUIRE(tokens.at(10).getValue() == "procedure");

  REQUIRE(tokens.at(11).getType() == NAME);
  REQUIRE(tokens.at(11).getValue() == "Proc2");

  REQUIRE(tokens.at(12).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(12).getValue() == "{");

  REQUIRE(tokens.at(13).getType() == IF);
  REQUIRE(tokens.at(13).getValue() == "if");

  REQUIRE(tokens.at(14).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(14).getValue() == "(");

  REQUIRE(tokens.at(15).getType() == NAME);
  REQUIRE(tokens.at(15).getValue() == "z");

  REQUIRE(tokens.at(16).getType() == GREATER_THAN);
  REQUIRE(tokens.at(16).getValue() == ">");

  REQUIRE(tokens.at(17).getType() == INTEGER);
  REQUIRE(tokens.at(17).getValue() == "0");

  REQUIRE(tokens.at(18).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(18).getValue() == ")");

  REQUIRE(tokens.at(19).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(19).getValue() == "{");

  REQUIRE(tokens.at(20).getType() == PRINT);
  REQUIRE(tokens.at(20).getValue() == "print");

  REQUIRE(tokens.at(21).getType() == NAME);
  REQUIRE(tokens.at(21).getValue() == "z");

  REQUIRE(tokens.at(22).getType() == SEMICOLON);
  REQUIRE(tokens.at(22).getValue() == ";");

  REQUIRE(tokens.at(23).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(23).getValue() == "}");

  REQUIRE(tokens.at(24).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(24).getValue() == "}");
}

TEST_CASE("Tokenize program with invalid character") {
  std::string input = "procedure Invalid { $ = x + y; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);

  REQUIRE_THROWS_AS(tokenizer.tokenize(), SyntaxErrorException);
}

TEST_CASE("Tokenize program with invalid keyword") {
  std::string input = "procedure Invalid { if (x &&& y) { print z; } }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);

  REQUIRE_THROWS_AS(tokenizer.tokenize(), SyntaxErrorException);
}

TEST_CASE("Tokenize program with invalid number format") {
  std::string input = "procedure Invalid { num = 123.45; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);

  REQUIRE_THROWS_AS(tokenizer.tokenize(), SyntaxErrorException);
}

// Testing if-else condition
TEST_CASE("Tokenize if-else statements") {
  std::string input = "if (a == b) { call x; } else { call y; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();
  REQUIRE(tokens.getLength() == 17);

  REQUIRE(tokens.at(0).getType() == IF);
  REQUIRE(tokens.at(0).getValue() == "if");

  REQUIRE(tokens.at(1).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(1).getValue() == "(");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "a");

  REQUIRE(tokens.at(3).getType() == DOUBLE_EQUALS);
  REQUIRE(tokens.at(3).getValue() == "==");

  REQUIRE(tokens.at(4).getType() == NAME);
  REQUIRE(tokens.at(4).getValue() == "b");

  REQUIRE(tokens.at(5).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(5).getValue() == ")");

  REQUIRE(tokens.at(6).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(6).getValue() == "{");

  REQUIRE(tokens.at(7).getType() == CALL);
  REQUIRE(tokens.at(7).getValue() == "call");

  REQUIRE(tokens.at(8).getType() == NAME);
  REQUIRE(tokens.at(8).getValue() == "x");

  REQUIRE(tokens.at(9).getType() == SEMICOLON);
  REQUIRE(tokens.at(9).getValue() == ";");

  REQUIRE(tokens.at(10).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(10).getValue() == "}");

  REQUIRE(tokens.at(11).getType() == ELSE);
  REQUIRE(tokens.at(11).getValue() == "else");

  REQUIRE(tokens.at(12).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(12).getValue() == "{");

  REQUIRE(tokens.at(13).getType() == CALL);
  REQUIRE(tokens.at(13).getValue() == "call");

  REQUIRE(tokens.at(14).getType() == NAME);
  REQUIRE(tokens.at(14).getValue() == "y");

  REQUIRE(tokens.at(15).getType() == SEMICOLON);
  REQUIRE(tokens.at(15).getValue() == ";");

  REQUIRE(tokens.at(16).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(16).getValue() == "}");
}

TEST_CASE("Tokenize maths expressions with whitespace") {
  std::string input = "a =   1+ 2   - 3    *4;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 10);

  REQUIRE(tokens.at(0).getType() == NAME);
  REQUIRE(tokens.at(0).getValue() == "a");

  REQUIRE(tokens.at(1).getType() == ASSIGN);
  REQUIRE(tokens.at(1).getValue() == "=");

  REQUIRE(tokens.at(2).getType() == INTEGER);
  REQUIRE(tokens.at(2).getValue() == "1");

  REQUIRE(tokens.at(3).getType() == PLUS);
  REQUIRE(tokens.at(3).getValue() == "+");

  REQUIRE(tokens.at(4).getType() == INTEGER);
  REQUIRE(tokens.at(4).getValue() == "2");

  REQUIRE(tokens.at(5).getType() == MINUS);
  REQUIRE(tokens.at(5).getValue() == "-");

  REQUIRE(tokens.at(6).getType() == INTEGER);
  REQUIRE(tokens.at(6).getValue() == "3");

  REQUIRE(tokens.at(7).getType() == TIMES);
  REQUIRE(tokens.at(7).getValue() == "*");

  REQUIRE(tokens.at(8).getType() == INTEGER);
  REQUIRE(tokens.at(8).getValue() == "4");

  REQUIRE(tokens.at(9).getType() == SEMICOLON);
  REQUIRE(tokens.at(9).getValue() == ";");
}

TEST_CASE("Tokenize function call with whitespace") {
  std::string input = "call   functionName   ;";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 3);

  REQUIRE(tokens.at(0).getType() == CALL);
  REQUIRE(tokens.at(0).getValue() == "call");

  REQUIRE(tokens.at(1).getType() == NAME);
  REQUIRE(tokens.at(1).getValue() == "functionName");

  REQUIRE(tokens.at(2).getType() == SEMICOLON);
  REQUIRE(tokens.at(2).getValue() == ";");
}

TEST_CASE("Tokenize if-else statements with whitespace") {
  std::string input =
      "if    ( a  == b     )   { call   x ;  }   else   { call y   ; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 17);

  REQUIRE(tokens.at(0).getType() == IF);
  REQUIRE(tokens.at(0).getValue() == "if");

  REQUIRE(tokens.at(1).getType() == LEFT_PARENTHESIS);
  REQUIRE(tokens.at(1).getValue() == "(");

  REQUIRE(tokens.at(2).getType() == NAME);
  REQUIRE(tokens.at(2).getValue() == "a");

  REQUIRE(tokens.at(3).getType() == DOUBLE_EQUALS);
  REQUIRE(tokens.at(3).getValue() == "==");

  REQUIRE(tokens.at(4).getType() == NAME);
  REQUIRE(tokens.at(4).getValue() == "b");

  REQUIRE(tokens.at(5).getType() == RIGHT_PARENTHESIS);
  REQUIRE(tokens.at(5).getValue() == ")");

  REQUIRE(tokens.at(6).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(6).getValue() == "{");

  REQUIRE(tokens.at(7).getType() == CALL);
  REQUIRE(tokens.at(7).getValue() == "call");

  REQUIRE(tokens.at(8).getType() == NAME);
  REQUIRE(tokens.at(8).getValue() == "x");

  REQUIRE(tokens.at(9).getType() == SEMICOLON);
  REQUIRE(tokens.at(9).getValue() == ";");

  REQUIRE(tokens.at(10).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(10).getValue() == "}");

  REQUIRE(tokens.at(11).getType() == ELSE);
  REQUIRE(tokens.at(11).getValue() == "else");

  REQUIRE(tokens.at(12).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(12).getValue() == "{");

  REQUIRE(tokens.at(13).getType() == CALL);
  REQUIRE(tokens.at(13).getValue() == "call");

  REQUIRE(tokens.at(14).getType() == NAME);
  REQUIRE(tokens.at(14).getValue() == "y");

  REQUIRE(tokens.at(15).getType() == SEMICOLON);
  REQUIRE(tokens.at(15).getValue() == ";");

  REQUIRE(tokens.at(16).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(16).getValue() == "}");
}

TEST_CASE("Tokenize procedures with whitespace") {
  std::string input = "procedure   procName  { a  =    1 ;    }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  auto tokens = tokenizer.tokenize();

  REQUIRE(tokens.getLength() == 8);

  REQUIRE(tokens.at(0).getType() == PROCEDURE);
  REQUIRE(tokens.at(0).getValue() == "procedure");

  REQUIRE(tokens.at(1).getType() == NAME);
  REQUIRE(tokens.at(1).getValue() == "procName");

  REQUIRE(tokens.at(2).getType() == LEFT_CURLY_BRACKET);
  REQUIRE(tokens.at(2).getValue() == "{");

  REQUIRE(tokens.at(3).getType() == NAME);
  REQUIRE(tokens.at(3).getValue() == "a");

  REQUIRE(tokens.at(4).getType() == ASSIGN);
  REQUIRE(tokens.at(4).getValue() == "=");

  REQUIRE(tokens.at(5).getType() == INTEGER);
  REQUIRE(tokens.at(5).getValue() == "1");

  REQUIRE(tokens.at(6).getType() == SEMICOLON);
  REQUIRE(tokens.at(6).getValue() == ";");

  REQUIRE(tokens.at(7).getType() == RIGHT_CURLY_BRACKET);
  REQUIRE(tokens.at(7).getValue() == "}");
}
// ai-gen end