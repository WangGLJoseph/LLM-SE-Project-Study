//
// Created by Max Ang Yue Jun on 8/2/24.
//
#include "PKB/Storages/EntityStorage.h"
#include "catch.hpp"

#include <string>
#include <unordered_set>

TEST_CASE("Unit Tests for EntityStorage") {

  SECTION("No Variables in EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};

    REQUIRE(entityStorage.getVariables() ==
            std::unordered_set<std::string>({}));
  }

  SECTION("Add Single Variable into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addVariable("abc");

    REQUIRE(entityStorage.getVariables() ==
            std::unordered_set<std::string>({"abc"}));
  }

  SECTION("Add Variables into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addVariable("abc");
    entityStorage.addVariable("def");
    entityStorage.addVariable("ghi");
    entityStorage.addVariable("jkl");

    REQUIRE(entityStorage.getVariables() ==
            std::unordered_set<std::string>({"abc", "def", "ghi", "jkl"}));
  }

  SECTION("No Constants in EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};

    REQUIRE(entityStorage.getConstants() ==
            std::unordered_set<std::string>({}));
  }

  SECTION("Add Single Constant into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addConstant("12345");

    REQUIRE(entityStorage.getConstants() ==
            std::unordered_set<std::string>({"12345"}));
  }

  SECTION("Add Constants into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addConstant("123");
    entityStorage.addConstant("456");
    entityStorage.addConstant("789");
    entityStorage.addConstant("10");

    REQUIRE(entityStorage.getConstants() ==
            std::unordered_set<std::string>({"123", "456", "789", "10"}));
  }

  SECTION("No Procedure in EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};

    REQUIRE(entityStorage.getProcedures() ==
            std::unordered_set<std::string>({}));
  }

  SECTION("Add Single Procedure into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addProcedure("main");

    REQUIRE(entityStorage.getProcedures() ==
            std::unordered_set<std::string>({"main"}));
  }

  SECTION("Add Procedures into EntityStorage") {
    EntityStorage entityStorage{EntityStorage()};
    entityStorage.addProcedure("main");
    entityStorage.addProcedure("run");
    entityStorage.addProcedure("walk");
    entityStorage.addProcedure("jump");

    REQUIRE(entityStorage.getProcedures() ==
            std::unordered_set<std::string>({"main", "run", "walk", "jump"}));
  }
}
