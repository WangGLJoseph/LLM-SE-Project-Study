#include "QPS/Query.h"
#include "catch.hpp"

TEST_CASE("Query Constructor works") {
  std::string selectedSynonym = "a";
  std::unordered_map<std::string, EntityType> synonymMap{{"a", EntityType::ASSIGNMENT},
                                                         {"w", EntityType::WHILE},
                                                          {"v", EntityType::VARIABLE}};
  std::vector<StClause> stClauses {StClause(RelRef::FOLLOWS, "a", "w")};
  std::vector<PatternClause> patternClauses {PatternClause("x", "_", "_")};
  Query queryRep(selectedSynonym, synonymMap, stClauses, patternClauses);
  REQUIRE(queryRep.selectedSynonym_ == "a");
}