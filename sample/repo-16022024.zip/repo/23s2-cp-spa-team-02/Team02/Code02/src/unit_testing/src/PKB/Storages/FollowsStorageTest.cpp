//
// Created by Max Ang Yue Jun on 8/2/24.
//
#include "PKB/Storages/FollowsStorage.h"
#include "catch.hpp"

#include <string>
#include <unordered_set>

TEST_CASE("Unit Tests for FollowsStorage") {

  SECTION("No Follows in FollowsStorage") {
    FollowsStorage followsStorage{FollowsStorage()};

    REQUIRE(followsStorage.hasFollows() == false);
  }

  SECTION("Single Follows in FollowsStorage") {
    FollowsStorage followsStorage{FollowsStorage()};

    followsStorage.addFollows("statement1", "statement2");
    REQUIRE(followsStorage.hasFollows() == true);
    REQUIRE(followsStorage.getStatementFollowing("statement1") == "statement2");
    REQUIRE(followsStorage.getStatementFollowing("statement2").empty());
  }
}