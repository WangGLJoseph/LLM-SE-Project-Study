//
// Created by Max Ang Yue Jun on 10/2/24.
//
#include "PKB/Storages/StatementStorage.h"
#include "catch.hpp"

#include <string>
#include <unordered_set>

// Simple test case to test functionality of StatementStorage
TEST_CASE("Unit Tests for StatementStorage") {
  StatementStorage statementStorage{StatementStorage()};

  std::unordered_set<std::string> stmtFields1 = {"x", "y", "z"};
  std::unordered_set<std::string> stmtFields2 = {"a", "b", "c"};
  statementStorage.addStatementWithType("1", "assign");
  statementStorage.addStatementMetadata("1", stmtFields1);

  statementStorage.addStatementWithType("2", "while");
  statementStorage.addStatementMetadata("2", stmtFields2);

  std::unordered_set<std::string> correctStmts = {"1", "2"};
  REQUIRE(statementStorage.getStatements() == correctStmts);

  std::unordered_set<std::string> stmtsWithX = {"1"};
  std::unordered_set<std::string> stmtsWithoutX = {"2"};
  REQUIRE(statementStorage.getStatementsWithMetadata("x") == stmtsWithX);
  REQUIRE(statementStorage.getStatementsWithMetadata("x") != stmtsWithoutX);

  std::unordered_set<std::string> &stmtsOfAssignType = {stmtsWithX};
  REQUIRE(statementStorage.getStatementsWithType("assign") == stmtsOfAssignType);
}
