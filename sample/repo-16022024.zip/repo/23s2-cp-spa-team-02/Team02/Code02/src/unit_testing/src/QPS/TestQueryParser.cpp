#include "QPS/Parser/QueryParser.h"
#include "catch.hpp"
#include <iostream>

TEST_CASE("parseQuery returns Correct Query Representation") {
  QueryParser parser;

  SECTION("Test with no clauses") {
    std::string query = "variable v; Select v";
    Query q = parser.parseQuery(query);
    REQUIRE(q.selectedSynonym_ == "v");
    REQUIRE(q.synonymMap_.at("v") == EntityType::VARIABLE);
    REQUIRE(q.stClauses_.size() == 0);
    REQUIRE(q.patternClauses_.empty());
  }

  SECTION("Test with suchthat-cl") {
    std::string query = "assign a; while w; Select a such that Follows (a, w)";
    Query q = parser.parseQuery(query);
    REQUIRE(q.selectedSynonym_ == "a");
    REQUIRE(q.synonymMap_.at("a") == EntityType::ASSIGNMENT);
    REQUIRE(q.synonymMap_.at("w") == EntityType::WHILE);
    REQUIRE(q.stClauses_[0].getRelationship() == RelRef::FOLLOWS);
    REQUIRE(q.stClauses_[0].getArg1() == "a");
    REQUIRE(q.stClauses_[0].getArg2() == "w");
    REQUIRE(q.patternClauses_.empty());
  }

  SECTION("Test with suchthat-cl with statement number") {
    std::string query = "assign a; Select a such that Follows (a, 1)";
    Query q = parser.parseQuery(query);
    REQUIRE(q.selectedSynonym_ == "a");
    REQUIRE(q.synonymMap_.at("a") == EntityType::ASSIGNMENT);
    REQUIRE(q.stClauses_[0].getRelationship() == RelRef::FOLLOWS);
    REQUIRE(q.stClauses_[0].getArg1() == "a");
    REQUIRE(q.stClauses_[0].getArg2() == "1");
    REQUIRE(q.patternClauses_.empty());
  }

  SECTION("Test with pattern-cl") {
    std::string query = "assign a; variable v; Select v pattern a (_, \"x\")";
    Query q = parser.parseQuery(query);
    REQUIRE(q.selectedSynonym_ == "v");
    REQUIRE(q.synonymMap_.at("v") == EntityType::VARIABLE);
    REQUIRE(q.stClauses_.size() == 0);
    REQUIRE(q.patternClauses_[0].getassignSyn() == "a");
    REQUIRE(q.patternClauses_[0].getArg1() == "_");
    REQUIRE(q.patternClauses_[0].getArg2() == "x");
  }

  SECTION("Test with multiple declarations, 1 suchthat-cl and 1 pattern-cl") {
    std::string query = "assign a; variable v;  while w;  Select a such that "
                        "Follows (a, w) pattern a (v, v)";
    Query q = parser.parseQuery(query);
    REQUIRE(q.selectedSynonym_ == "a");
    REQUIRE(q.synonymMap_.at("a") == EntityType::ASSIGNMENT);
    REQUIRE(q.synonymMap_.at("v") == EntityType::VARIABLE);
    REQUIRE(q.synonymMap_.at("w") == EntityType::WHILE);
    REQUIRE(q.stClauses_[0].getRelationship() == RelRef::FOLLOWS);
    REQUIRE(q.stClauses_[0].getArg1() == "a");
    REQUIRE(q.stClauses_[0].getArg2() == "w");
    REQUIRE(q.patternClauses_[0].getassignSyn() == "a");
    REQUIRE(q.patternClauses_[0].getArg1() == "v");
    REQUIRE(q.patternClauses_[0].getArg2() == "v");
  }
}
