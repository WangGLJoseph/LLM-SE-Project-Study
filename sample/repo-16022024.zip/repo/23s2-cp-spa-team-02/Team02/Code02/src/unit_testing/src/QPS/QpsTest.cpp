//
// Created by Richard Li Defa on 12/2/24.
//
#include "catch.hpp"
#include "QPS/QPS.h"
#include "PKB/API/PKBReadFacade.h"
#include "PKB/API/PKBWriteFacade.h"

TEST_CASE("DUMMY_QPS_TEST") {
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  PKBReadFacade pkbReadFacade(pkb);
  pkbWriteFacade.addStatementWithType("1", "dummy");
  pkbWriteFacade.addStatementWithType("2", "dummy");
  pkbWriteFacade.addStatementWithType("3", "dummy");
  pkbWriteFacade.addFollows("1", "2");
  pkbWriteFacade.addFollows("2", "3");

  QPS qps(pkbReadFacade);
  std::string query1 = "stmt s; Select s such that Follows (1,s)";
  std::unordered_set<std::string> result = qps.processQuery(query1);

  REQUIRE(result == std::unordered_set<std::string>{"2"});

  std::string query2 = "stmt t; Select t such that Follows (2,t)";
  result = qps.processQuery(query2);

  REQUIRE(result == std::unordered_set<std::string>{"3"});

  std::string query3 = "stmt t; Select t such that Follows (3,t)";
  result = qps.processQuery(query3);

  REQUIRE(result == std::unordered_set<std::string>{});

  std::string query4 = "stmt g; Select g";
  result = qps.processQuery(query4);

  REQUIRE(result == std::unordered_set<std::string>{"1", "2", "3"});
}
