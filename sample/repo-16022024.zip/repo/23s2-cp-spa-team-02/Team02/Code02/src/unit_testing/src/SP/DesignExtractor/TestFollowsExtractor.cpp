//
// Created by yeemi on 2/13/2024.
//
#include <sstream>

#include "PKB/API/PKBReadFacade.h"
#include "PKB/API/PKBWriteFacade.h"
#include "SP/DesignExtractor/DesignExtractorManager.h"
#include "SP/Parser/Parser.h"
#include "SP/Tokenizer/Tokenizer.h"
#include "SP/Tokenizer/Tokens.h"
#include "catch.hpp"

TEST_CASE("Extract follows single depth") {
  std::string input = "procedure test { call procName; call procName; call "
                      "procName; call procName; }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  FollowsExtractor followsExtractor = FollowsExtractor(pkbWriteFacade);
  programNode.accept(&followsExtractor);

  PKBReadFacade pkbReadFacade(pkb);

  const std::string statementFollowing1 =
      pkbReadFacade.getStatementFollowing("1");
  REQUIRE(statementFollowing1 == "2");

  const std::string statementFollowing2 =
      pkbReadFacade.getStatementFollowing("2");
  REQUIRE(statementFollowing2 == "3");

  const std::string statementFollowing3 =
      pkbReadFacade.getStatementFollowing("3");
  REQUIRE(statementFollowing3 == "4");
}

TEST_CASE("Extract follows multiple depth") {
  std::string input =
      "procedure test { if (x = 5) { call procName; while ( x != 5 ) { read "
      "varName; } print varName; } else { x = x + 1; } }";
  std::istringstream iss(input);
  Tokenizer tokenizer(iss);
  Tokens tokens = tokenizer.tokenize();
  ProgramNode programNode = Parser::parseTokens(tokens);
  PKB pkb;
  PKBWriteFacade pkbWriteFacade(pkb);
  FollowsExtractor followsExtractor = FollowsExtractor(pkbWriteFacade);
  programNode.accept(&followsExtractor);

  PKBReadFacade pkbReadFacade(pkb);

  const std::string statementFollowing1 =
      pkbReadFacade.getStatementFollowing("2");
  REQUIRE(statementFollowing1 == "3");

  const std::string statementFollowing2 =
      pkbReadFacade.getStatementFollowing("3");
  REQUIRE(statementFollowing2 == "5");
}