//
// Created by Clement Kong on 5/2/24.
//
#include "PKB/API/PKBReadFacade.h"
#include "PKB/API/PKBWriteFacade.h"
#include "PKB/PKB.h"
#include "catch.hpp"

void setupTestVars(PKBWriteFacade pkbWriteFacade) {
  pkbWriteFacade.addVariable("east");
  pkbWriteFacade.addVariable("west");
  pkbWriteFacade.addVariable("north");
}

TEST_CASE("PKBReadFacade - getVariables returns the correct vars") {
  PKB pkb;

  PKBWriteFacade pkbWriteFacade(pkb);
  pkbWriteFacade.addVariable("east");
  pkbWriteFacade.addVariable("west");
  pkbWriteFacade.addVariable("north");

  PKBReadFacade pkbReadFacade(pkb);

  const std::unordered_set<std::string> &vars =
      pkbReadFacade.getVariables(); // did  std::cout << &pkb
  REQUIRE(vars.size() == 3);
  REQUIRE(vars.find("east") != vars.end());
  REQUIRE(vars.find("west") != vars.end());
  REQUIRE(vars.find("south") == vars.end());
}

TEST_CASE("PKBReadFacade - getStatements returns the correct stmts") {
  PKB pkb;

  PKBWriteFacade pkbWriteFacade(pkb);

  std::unordered_set<std::string> stmtFields1 = {"x", "y", "z"};
  std::unordered_set<std::string> stmtFields2 = {"a", "b", "c"};

  pkbWriteFacade.addStatementWithType("1", "assign");
  pkbWriteFacade.addStatementMetadata("1", stmtFields1);
  pkbWriteFacade.addStatementWithType("2", "while");
  pkbWriteFacade.addStatementMetadata("2", stmtFields2);

  PKBReadFacade pkbReadFacade(pkb);

  std::unordered_set<std::string> correctStmts = {"1", "2"};
  REQUIRE(pkbReadFacade.getStatements() == correctStmts);

  std::unordered_set<std::string> stmtsWithX = {"1"};
  std::unordered_set<std::string> stmtsWithoutX = {"2"};
  REQUIRE(pkbReadFacade.getStatementsWithMetadata("x") == stmtsWithX);
  REQUIRE(pkbReadFacade.getStatementsWithMetadata("x") != stmtsWithoutX);

  std::unordered_set<std::string> &stmtsOfAssignType = {stmtsWithX};
  REQUIRE(pkbReadFacade.getStatementsWithType("assign") == stmtsOfAssignType);
}

