#include "catch.hpp"
#include "QPS/Result.h"

TEST_CASE("RESULT_CONSTRUCTOR_TEST") {

    Table table;
    table["x"].emplace_back("1");
    table["y"].emplace_back("one");
    table["x"].emplace_back("2");
    table["y"].emplace_back("two");

    Result result(table);

    std::unordered_set<std::string> expectedX{"2", "1"};

    REQUIRE(expectedX == result.getSynonym("x"));

    std::unordered_set<std::string> expectedY{"one", "two"};

    REQUIRE(expectedY == result.getSynonym("y"));
}

TEST_CASE("RESULT_GET_SYNONYM_TEST") {

    Table table;
    table["x"].emplace_back("1");
    table["x"].emplace_back("2");
    table["x"].emplace_back("3");
    table["x"].emplace_back("2");

    Result result(table);

    std::unordered_set<std::string> allXs = result.getSynonym("x");

    REQUIRE(allXs.size() == 3);

    std::unordered_set<std::string> expectedX{"2", "1", "3"};

    REQUIRE(allXs == expectedX);

    // Make sure the table is a deep copy
    table["x"][0] = "4";

    allXs = result.getSynonym("x");
    REQUIRE(allXs == expectedX);
    REQUIRE_FALSE(allXs == std::unordered_set<std::string>{table["x"].begin(), table["x"].end()});
}

TEST_CASE("RESULT_IS_EMPTY_TEST") {
  Table emptyTable;

  Table nonEmptyTable{{"x", {"Grass"}},
                      {"y", {"Cement"}}};
  Table noEntriesTable{{"x", {}},
                       {"y", {}}};

  Result emptyResult(emptyTable);
  REQUIRE(emptyResult.isEmpty());

  Result nonEmptyResult(nonEmptyTable);
  REQUIRE_FALSE(nonEmptyResult.isEmpty());

  Result noEntriesResult(noEntriesTable);
  REQUIRE(noEntriesResult.isEmpty());
}