//
// Created by tohzh on 7/2/2024.
//

#include "QueryObject.h"

std::shared_ptr<Returnable> QueryObject::getReturnType() {
    return returnType;
}

void QueryObject::setReturnType(std::shared_ptr<Returnable> ptr) {
    returnType = std::move(ptr);
}

std::vector<std::shared_ptr<Constraint>> QueryObject::getConstraints() {
    return constraints;
}

void QueryObject::addConstraint(std::shared_ptr<Constraint> c) {
    constraints.push_back(c);
}

std::vector<std::shared_ptr<Entity>> QueryObject::getDeclarations() {
    return declarations;
}

void QueryObject::addDeclaration(const std::shared_ptr<Entity>& d) {
    declarations.push_back(d);
}

