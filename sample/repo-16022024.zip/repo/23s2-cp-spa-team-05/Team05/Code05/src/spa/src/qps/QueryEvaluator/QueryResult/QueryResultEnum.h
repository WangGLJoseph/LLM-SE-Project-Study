//
// Created by Alex on 11/2/2024.
//

#ifndef SPA_QUERYRESULTENUM_H
#define SPA_QUERYRESULTENUM_H

enum QueryResultEnum {
    INTEGER,
    STRING
};

#endif //SPA_QUERYRESULTENUM_H
