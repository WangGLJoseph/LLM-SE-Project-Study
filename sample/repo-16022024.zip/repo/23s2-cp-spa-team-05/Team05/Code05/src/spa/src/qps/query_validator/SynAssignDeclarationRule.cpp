//
// Created by tohzh on 10/2/2024.
//

#include "SynAssignDeclarationRule.h"

std::string SynAssignDeclarationRule::validate(QueryObject& qo) {
    bool followsRule = followsSynAssignDeclaration(qo);
    if (followsRule) {
        return "";
    } else {
        return VALIDATION_RULE_SYN_ASSIGN_DECLARATION;
    }
}

//to be implemented in next sprint
bool SynAssignDeclarationRule::followsSynAssignDeclaration(QueryObject& qo) {
    return true;
}