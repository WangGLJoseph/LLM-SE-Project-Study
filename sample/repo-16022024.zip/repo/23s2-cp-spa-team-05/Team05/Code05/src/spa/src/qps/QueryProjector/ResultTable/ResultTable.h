//
// Created by Alex on 7/2/2024.
//

#ifndef SPA_RESULTTABLE_H
#define SPA_RESULTTABLE_H


class ResultTable {

};


#endif //SPA_RESULTTABLE_H
