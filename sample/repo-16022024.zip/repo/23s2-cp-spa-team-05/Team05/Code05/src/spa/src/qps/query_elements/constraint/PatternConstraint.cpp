//
// Created by tohzh on 10/2/2024.
//

#include "PatternConstraint.h"


std::string PatternConstrain::getConstraintClass() {
    return CONSTRAINT_CLASS_PATTERN;
}
