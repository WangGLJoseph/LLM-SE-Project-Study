// include "qps/yourClass.h"
// include "qps/yourClass.cpp"

#include "catch.hpp"
using namespace std;

// Unit Tests for QPS
TEST_CASE("[TestQPS] Replace with your unit tests") {
    SECTION("Test a single aspect of the features") {
        REQUIRE(1 == 1);
    }
}
