// include "pkb/yourClass.h"
// include "pkb/yourClass.cpp"

#include "catch.hpp"
using namespace std;

// Integration Tests for QPS
TEST_CASE("[IntegTestQPS] Replace with your Integration tests") {
    // TODO: Initialize Stub for PKB

    SECTION("Use Stub to test a feature") {
        REQUIRE(1 == 1);
    }
}
