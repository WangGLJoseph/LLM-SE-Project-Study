//
// Created by ZHENGTAO JIANG on 8/2/24.
//

#ifndef SPA_STRATEGYFACTORY_H
#define SPA_STRATEGYFACTORY_H



class StrategyFactory {

};



#endif //SPA_STRATEGYFACTORY_H
