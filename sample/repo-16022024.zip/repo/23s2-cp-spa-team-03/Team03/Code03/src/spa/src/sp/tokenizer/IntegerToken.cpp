#include "IntegerToken.h"

IntegerToken::IntegerToken(std::string value) : Token(TokenType::INTEGER, value) {};