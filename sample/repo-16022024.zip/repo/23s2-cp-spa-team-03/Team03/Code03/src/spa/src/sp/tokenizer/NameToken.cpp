#include "NameToken.h"

NameToken::NameToken(std::string value) : Token(TokenType::NAME, value) {};