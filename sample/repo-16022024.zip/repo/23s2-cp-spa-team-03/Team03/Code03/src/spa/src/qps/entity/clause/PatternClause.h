//
// Created by ZHENGTAO JIANG on 8/2/24.
//

#ifndef SPA_PATTERNCLAUSE_H
#define SPA_PATTERNCLAUSE_H


class PatternClause {

};


#endif //SPA_PATTERNCLAUSE_H
