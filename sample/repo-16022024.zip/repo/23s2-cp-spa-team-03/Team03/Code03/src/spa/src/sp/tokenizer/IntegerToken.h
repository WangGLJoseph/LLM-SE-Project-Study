#pragma once

#include "Token.h"

class IntegerToken : public Token {
public:
	IntegerToken(std::string value);
};