#include "SpaException.h"

SpaException::SpaException(std::string_view message) : message(message) {}