//
// Created by ZHENGTAO JIANG on 8/2/24.
//

#ifndef SPA_CLAUSE_H
#define SPA_CLAUSE_H


class Clause {

};


#endif //SPA_CLAUSE_H
