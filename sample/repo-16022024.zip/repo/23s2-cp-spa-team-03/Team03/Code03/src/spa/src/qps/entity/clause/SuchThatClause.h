//
// Created by ZHENGTAO JIANG on 8/2/24.
//

#ifndef SPA_SUCHTHATCLAUSE_H
#define SPA_SUCHTHATCLAUSE_H



class SuchThatClause {

};



#endif //SPA_SUCHTHATCLAUSE_H
