#include "StatementParser.h"

string StatementParser::getProcedureName() {
	return procedureName;
}

void StatementParser::setProcedureName(string procName) {
	procedureName = procName;
}
